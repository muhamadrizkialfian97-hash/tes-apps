/**
 * ==============================================================================
 * GOOGLE APPS SCRIPT: REAL-TIME FIRESTORE SYNC, EMAIL OTP & WA GROUP NOTIFIER
 * ==============================================================================
 * 
 * SPREADSHEET: https://docs.google.com/spreadsheets/d/1BlzO5TeCmOeRqTrg-M0AmrxRs89ohM9vBhtmVMAofkE/edit
 * DATABASE ID: ai-studio-remixremixpancar-e5d36007-18cd-4f4e-8eec-a93a35f15981
 * PROJECT ID: gen-lang-client-0387361643
 *
 * FITUR UTAMA DALAM SCRIPT INI:
 * ------------------------------------------------------------------------------
 * 1. 📊 SINKRONISASI REAL-TIME: Salin seluruh database Firestore ke Google Sheets (Assets, Bids, Admins).
 * 2. ✉️ KIRIM EMAIL OTP ASLI: Kirim email verifikasi pendaftaran pengguna via Gmail/MailApp.
 * 3. 📱 NOTIFIKASI WA GRUP REAL-TIME: Teruskan semua notifikasi web (Bid baru, NPL, Pemenang lelang, dll.)
 *       langsung masuk ke GRUP WHATSAPP Anda secara otomatis!
 *
 * CARA MENGATASI ERROR 403 (REQUEST HAD INSUFFICIENT AUTHENTICATION SCOPES):
 * ------------------------------------------------------------------------------
 * 1. Di menu sebelah kiri editor Google Apps Script, klik ikon Roda Gigi ⚙️ (Setelan Proyek / Project Settings).
 * 2. Centang pilihan "Tampilkan file manifes 'appsscript.json' di editor".
 * 3. Kembali ke editor kode (< >). Buka file "appsscript.json", ganti isinya dengan:
 * 
 * {
 *   "timeZone": "Asia/Jakarta",
 *   "dependencies": {},
 *   "exceptionLogging": "STACKDRIVER",
 *   "runtimeVersion": "V8",
 *   "oauthScopes": [
 *     "https://www.googleapis.com/auth/spreadsheets",
 *     "https://www.googleapis.com/auth/script.external_request",
 *     "https://www.googleapis.com/auth/cloud-platform",
 *     "https://www.googleapis.com/auth/datastore",
 *     "https://www.googleapis.com/auth/script.send_mail"
 *   ]
 * }
 * 
 * 4. Simpan file (Ctrl+S).
 * 
 * CARA MENGHUBUNGKAN NOTIFIKASI KE GRUP WHATSAPP:
 * ------------------------------------------------------------------------------
 * Anda bisa menggunakan WhatsApp Gateway Provider favorit Anda (seperti Fonnte, Wablas, Whacenter, Starsender, dll).
 * 1. Isi token / API key Anda pada variabel `WA_API_KEY` di bawah.
 * 2. Masukkan ID Grup WhatsApp Anda pada variabel `WA_GROUP_ID` (misal: "120363xxxxxx@g.us" atau nama/ID grup).
 * 3. Terapkan (Deploy) Apps Script sebagai Web App:
 *    - Akses: Siapa saja (Anyone)
 *    - Jalankan sebagai: Saya (Me)
 */

// ==================== CONFIGURATION ====================
var SPREADSHEET_ID = "1BlzO5TeCmOeRqTrg-M0AmrxRs89ohM9vBhtmVMAofkE";
var PROJECT_ID = "gen-lang-client-0387361643";
var DATABASE_ID = "ai-studio-remixremixpancar-e5d36007-18cd-4f4e-8eec-a93a35f15981";

// KONFIGURASI NOTIFIKASI WHATSAPP GRUP
// Ganti provider sesuai layanan WA Gateway yang Anda pakai (misal: "fonnte", "wablas", "starsender", "whacenter", "custom")
var WA_PROVIDER = "fonnte"; // Pilihan: "fonnte" | "wablas" | "starsender" | "whacenter" | "custom"

// Masukkan API Token / Key dari penyedia WA Gateway Anda:
var WA_API_KEY = "YOUR_WA_GATEWAY_API_KEY"; 

// Masukkan WhatsApp Group Target ID (Contoh: "120363028392817281@g.us" atau format provider Anda):
var WA_GROUP_ID = "YOUR_WA_GROUP_ID@g.us"; 

// URL Endpoint jika memilih WA_PROVIDER = "custom"
var WA_CUSTOM_GATEWAY_URL = "https://api.wagateway.com/v1/send-message";
// =======================================================

/**
 * Endpoint POST yang akan dipanggil oleh React Web App secara instan (real-time)
 * ketika terjadi aksi database, notifikasi baru, atau OTP email.
 */
function doPost(e) {
  try {
    Logger.log("Menerima webhook...");
    
    // Parse data post jika ada
    var postData = null;
    if (e && e.postData && e.postData.contents) {
      try {
        postData = JSON.parse(e.postData.contents);
      } catch (parseErr) {
        Logger.log("Gagal parse postData: " + parseErr.toString());
      }
    }

    // 1. Aksi: Kirim Notifikasi ke Grup WhatsApp
    if (postData && postData.action === "send_wa_notification") {
      var notifTitle = postData.title || "Notifikasi Baru Pancaran Lelang";
      var notifMsg = postData.message || "";
      var notifType = postData.type || "info";
      var assetId = postData.assetId || "";
      
      var waResult = sendWhatsAppNotificationToGroup(notifTitle, notifMsg, notifType, assetId);
      
      return ContentService.createTextOutput(JSON.stringify({ 
        status: waResult ? "success" : "skipped_or_failed", 
        message: "Notifikasi WA diproses" 
      })).setMimeType(ContentService.MimeType.JSON);
    }

    // 2. Aksi: Kirim OTP Email Verifikasi Asli
    if (postData && postData.action === "send_otp") {
      var email = postData.email;
      var code = postData.code;
      var name = postData.name || "User";
      
      MailApp.sendEmail({
        to: email,
        subject: "Kode Verifikasi OTP - Pancaran Lelang",
        htmlBody: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 16px; background-color: #ffffff; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);">
            <div style="background-color: #1e3a8a; padding: 20px; text-align: center; border-radius: 12px 12px 0 0;">
              <h2 style="color: #ffffff; margin: 0; font-size: 22px; font-weight: bold;">PANCARAN LELANG</h2>
              <p style="color: #93c5fd; margin: 5px 0 0 0; font-size: 12px; letter-spacing: 1px; font-weight: bold;">PORTAL LELANG OTOMOTIF & LOGISTIK</p>
            </div>
            <div style="padding: 25px; color: #334155; line-height: 1.6;">
              <p style="font-size: 15px; margin-top: 0;">Halo <strong style="color: #1e3a8a;">${name}</strong>,</p>
              <p style="font-size: 14px;">Terima kasih telah mendaftar di <strong>Pancaran Lelang</strong>. Untuk mengaktifkan akun Anda dan memverifikasi keaslian kepemilikan email, silakan gunakan kode verifikasi OTP berikut:</p>
              
              <div style="text-align: center; margin: 30px 0;">
                <span style="font-size: 32px; font-weight: bold; letter-spacing: 6px; color: #1e3a8a; background-color: #f1f5f9; padding: 15px 30px; border-radius: 10px; border: 1px solid #cbd5e1; font-family: monospace; display: inline-block;">${code}</span>
              </div>
              
              <p style="font-size: 13px; color: #64748b; margin-bottom: 0;">
                Masukkan kode di atas pada formulir verifikasi di halaman web. Kode ini berlaku selama 15 menit. Jika Anda tidak melakukan pendaftaran ini, Anda dapat mengabaikan email ini dengan aman.
              </p>
            </div>
            <div style="border-top: 1px solid #e2e8f0; padding-top: 15px; text-align: center; font-size: 11px; color: #94a3b8; margin-top: 20px;">
              Email ini dikirim secara otomatis oleh sistem keamanan Pancaran Lelang.<br>
              &copy; 2026 PT Pancaran Darma Herindo (Pancaran Logistics). Hak Cipta Dilindungi.
            </div>
          </div>
        `
      });
      
      return ContentService.createTextOutput(JSON.stringify({ 
        status: "success", 
        message: "Kode OTP berhasil dikirim ke email asli Anda!" 
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    // 3. Aksi: Sinkronisasi Utama ke Spreadsheet
    syncFirestoreToSpreadsheet();
    
    return ContentService.createTextOutput(JSON.stringify({ 
      status: "success", 
      message: "Spreadsheet berhasil diperbarui secara instan!" 
    })).setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    Logger.log("Gagal memproses webhook: " + error.toString());
    return ContentService.createTextOutput(JSON.stringify({ 
      status: "error", 
      message: error.toString() 
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Endpoint GET untuk pengujian manual lewat browser jika dibutuhkan
 */
function doGet(e) {
  try {
    syncFirestoreToSpreadsheet();
    return ContentService.createTextOutput("Sinkronisasi Berhasil! Data Firestore Pancaran telah disalin ke Google Sheets.").setMimeType(ContentService.MimeType.TEXT);
  } catch (error) {
    return ContentService.createTextOutput("Gagal: " + error.toString()).setMimeType(ContentService.MimeType.TEXT);
  }
}

/**
 * Mengirim pesan format rapi ke Grup WhatsApp via WhatsApp Gateway API
 */
function sendWhatsAppNotificationToGroup(title, message, type, assetId) {
  if (!WA_API_KEY || WA_API_KEY === "YOUR_WA_GATEWAY_API_KEY" || !WA_GROUP_ID || WA_GROUP_ID === "YOUR_WA_GROUP_ID@g.us") {
    Logger.log("Konfigurasi WhatsApp Gateway belum diisi lengkap (WA_API_KEY atau WA_GROUP_ID). Notifikasi WA dilewati.");
    return false;
  }

  // Pilih icon badge berdasarkan tipe notifikasi
  var badge = "🔔";
  if (type === "success") badge = "✅";
  else if (type === "warning") badge = "⚠️";
  else if (type === "bid") badge = "💰";
  else if (type === "winner") badge = "🏆";
  else if (type === "npl") badge = "💵";

  var nowStr = formatDateString(new Date().toISOString());

  // Format pesan WhatsApp yang rapi dan profesional
  var textMessage = badge + " *NOTIFIKASI PLATINUM LELANG*\n" +
    "━━━━━━━━━━━━━━━━━━━━\n" +
    "📌 *" + title + "*\n\n" +
    message + "\n\n" +
    (assetId ? "🆔 *Unit ID:* `" + assetId + "`\n" : "") +
    "⏱ *Waktu:* " + nowStr + "\n" +
    "━━━━━━━━━━━━━━━━━━━━\n" +
    "🌐 _Portal Lelang Pancaran Logistics_\n" +
    "https://pancaran-platinum.vercel.app/";

  try {
    var url = "";
    var payload = {};
    var headers = {};

    if (WA_PROVIDER === "fonnte") {
      url = "https://api.fonnte.com/send";
      headers = { "Authorization": WA_API_KEY };
      payload = {
        "target": WA_GROUP_ID,
        "message": textMessage
      };
    } else if (WA_PROVIDER === "wablas") {
      url = "https://kudus.wablas.com/api/send-message";
      headers = { "Authorization": WA_API_KEY, "Content-Type": "application/json" };
      payload = {
        "phone": WA_GROUP_ID,
        "message": textMessage,
        "isGroup": "true"
      };
    } else if (WA_PROVIDER === "starsender") {
      url = "https://starsender.online/api/sendText?messageType=text";
      headers = { "apikey": WA_API_KEY, "Content-Type": "application/json" };
      payload = {
        "tujuan": WA_GROUP_ID,
        "message": textMessage
      };
    } else if (WA_PROVIDER === "whacenter") {
      url = "https://app.whacenter.com/api/send";
      headers = { "Content-Type": "application/json" };
      payload = {
        "device_id": WA_API_KEY,
        "number": WA_GROUP_ID,
        "message": textMessage
      };
    } else {
      // Custom endpoint
      url = WA_CUSTOM_GATEWAY_URL;
      headers = { "Authorization": "Bearer " + WA_API_KEY, "Content-Type": "application/json" };
      payload = {
        "target": WA_GROUP_ID,
        "message": textMessage
      };
    }

    var options = {
      "method": "post",
      "headers": headers,
      "payload": (headers["Content-Type"] === "application/json") ? JSON.stringify(payload) : payload,
      "muteHttpExceptions": true
    };

    var resp = UrlFetchApp.fetch(url, options);
    Logger.log("WA Group Dispatch Response (" + resp.getResponseCode() + "): " + resp.getContentText());
    return resp.getResponseCode() === 200;
  } catch (err) {
    Logger.log("Error mengirim notifikasi WA ke grup: " + err.toString());
    return false;
  }
}

/**
 * Fungsi Utama untuk mengambil seluruh data dari Firestore REST API
 * dan menuliskannya secara rapi ke Spreadsheet.
 */
function syncFirestoreToSpreadsheet() {
  Logger.log("Memulai sinkronisasi dari Firestore...");
  
  var ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  
  // Ambil dan Sinkronisasikan Data Assets & Bids
  var assets = fetchFirestoreCollection("assets");
  Logger.log("Berhasil mengambil " + assets.length + " assets.");
  writeAssetsAndBidsToSheet(ss, assets);
  
  // Ambil dan Sinkronisasikan Data Admins
  var admins = fetchFirestoreCollection("admins");
  Logger.log("Berhasil mengambil " + admins.length + " admins.");
  writeAdminsToSheet(ss, admins);
  
  Logger.log("Sinkronisasi selesai dengan sukses!");
}

/**
 * Mengambil dokumen dari koleksi Firestore menggunakan OAuth2 Token Internal Google
 */
function fetchFirestoreCollection(collectionName) {
  // Parameter ?pageSize=300 agar data tidak terpotong maksimal 20 item
  var url = "https://firestore.googleapis.com/v1/projects/" + PROJECT_ID + 
            "/databases/" + DATABASE_ID + "/documents/" + collectionName + "?pageSize=300";
  
  try {
    var token = ScriptApp.getOAuthToken();
    
    var options = {
      "method": "get",
      "headers": {
        "Authorization": "Bearer " + token
      },
      "muteHttpExceptions": true
    };
    
    var response = UrlFetchApp.fetch(url, options);
    var responseCode = response.getResponseCode();
    
    if (responseCode !== 200) {
      Logger.log("Error mengambil koleksi " + collectionName + " (Code: " + responseCode + "): " + response.getContentText());
      return [];
    }
    
    var data = JSON.parse(response.getContentText());
    var rawDocuments = data.documents || [];
    
    // Parse dokumen-dokumen Firestore ke objek JavaScript standar yang bersih
    return rawDocuments.map(function(doc) {
      return parseFirestoreDocument(doc);
    });
  } catch (error) {
    Logger.log("Gagal melakukan fetch " + collectionName + ": " + error.toString());
    return [];
  }
}

/**
 * Memformat dan menulis data Assets dan Bids ke sheet masing-masing
 */
function writeAssetsAndBidsToSheet(ss, assets) {
  // ------------------ 1. SINKRONISASI SHEET "ASSETS" ------------------
  var assetsSheet = getOrCreateSheet(ss, "Assets");
  assetsSheet.clear(); // Bersihkan sheet agar selalu up-to-date
  
  var assetsHeader = [
    "Asset ID", "Nama Unit", "Merek (Brand)", "Kategori", "Tahun", 
    "Nomor Polisi", "Kondisi", "Lokasi", "Harga Awal (IDR)", 
    "Penawaran Tertinggi (IDR)", "Status Unit", "URL Gambar", 
    "Total Penawaran (Bids)", "Deskripsi Lengkap"
  ];
  
  var assetsRows = [assetsHeader];
  var bidsRows = [[
    "Asset ID", "Nama Unit", "Nama Penawar (Bidder)", "Email Penawar", 
    "Kontak (WA/Telp)", "Harga Bid (IDR)", "Waktu Bid", 
    "Request Survei?", "Tanggal Survei", "Sesi Survei", "Status Bid"
  ]];
  
  assets.forEach(function(asset) {
    var totalBids = 0;
    if (asset.bids && Array.isArray(asset.bids)) {
      totalBids = asset.bids.length;
    }
    
    // Baris Asset
    assetsRows.push([
      asset.id || "",
      asset.name || "",
      asset.brand || "",
      asset.category || "",
      asset.modelYear !== undefined ? asset.modelYear : "",
      asset.plateNumber || "",
      asset.condition || "",
      asset.location || "",
      asset.startingPrice !== undefined ? asset.startingPrice : 0,
      asset.highestBid !== undefined ? asset.highestBid : (asset.startingPrice || 0),
      asset.status || "Open",
      asset.imageUrl || "",
      totalBids,
      asset.description || ""
    ]);
    
    // Ekstrak bids bersarang untuk dicatat ke Sheet "Bids"
    if (asset.bids && Array.isArray(asset.bids)) {
      asset.bids.forEach(function(bid) {
        bidsRows.push([
          asset.id || "",
          asset.name || "",
          bid.name || "",
          bid.email || "",
          bid.contact || "",
          bid.price !== undefined ? bid.price : 0,
          bid.timestamp ? formatDateString(bid.timestamp) : "",
          bid.requestSurvey ? "Ya" : "Tidak",
          bid.surveyDate || "-",
          bid.surveySession || "-",
          bid.status || "pending"
        ]);
      });
    }
  });
  
  // Tulis data ke sheet Assets
  if (assetsRows.length > 1) {
    assetsSheet.getRange(1, 1, assetsRows.length, assetsHeader.length).setValues(assetsRows);
  } else {
    assetsSheet.getRange(1, 1, 1, assetsHeader.length).setValues([assetsHeader]);
  }
  formatHeaderRow(assetsSheet, assetsHeader.length);
  
  // ------------------ 2. SINKRONISASI SHEET "BIDS" ------------------
  var bidsSheet = getOrCreateSheet(ss, "Bids");
  bidsSheet.clear();
  
  var bidsHeader = bidsRows[0];
  if (bidsRows.length > 1) {
    bidsSheet.getRange(1, 1, bidsRows.length, bidsHeader.length).setValues(bidsRows);
  } else {
    bidsSheet.getRange(1, 1, 1, bidsHeader.length).setValues([bidsHeader]);
  }
  formatHeaderRow(bidsSheet, bidsHeader.length);
}

/**
 * Memformat dan menulis data Admins ke sheet "Admins"
 */
function writeAdminsToSheet(ss, admins) {
  var adminsSheet = getOrCreateSheet(ss, "Admins");
  adminsSheet.clear();
  
  var adminsHeader = ["Email Admin", "Nama", "Peran (Role)", "Tanggal Dibuat"];
  var adminsRows = [adminsHeader];
  
  admins.forEach(function(admin) {
    adminsRows.push([
      admin.email || "",
      admin.name || "",
      admin.role || "",
      admin.createdAt || ""
    ]);
  });
  
  if (adminsRows.length > 1) {
    adminsSheet.getRange(1, 1, adminsRows.length, adminsHeader.length).setValues(adminsRows);
  } else {
    adminsSheet.getRange(1, 1, 1, adminsHeader.length).setValues([adminsHeader]);
  }
  formatHeaderRow(adminsSheet, adminsHeader.length);
}

/**
 * Mengambil sheet dengan nama tertentu, atau membuatnya jika belum ada
 */
function getOrCreateSheet(ss, name) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
  }
  return sheet;
}

/**
 * Menghias baris header sheet agar tampil profesional dan elegan
 */
function formatHeaderRow(sheet, columnCount) {
  if (columnCount <= 0) return;
  
  var headerRange = sheet.getRange(1, 1, 1, columnCount);
  headerRange.setBackground("#1E3A8A")
             .setFontColor("#FFFFFF")
             .setFontWeight("bold")
             .setHorizontalAlignment("center")
             .setVerticalAlignment("middle");
  
  sheet.setFrozenRows(1);
  sheet.setRowHeight(1, 28);
  
  for (var col = 1; col <= columnCount; col++) {
    sheet.autoResizeColumn(col);
    var currentWidth = sheet.getColumnWidth(col);
    if (currentWidth < 100) {
      sheet.setColumnWidth(col, 120);
    } else {
      sheet.setColumnWidth(col, currentWidth + 15);
    }
  }
}

/**
 * Helper untuk menyederhanakan parsing tipe data Firestore REST API yang kompleks
 */
function parseFirestoreValue(value) {
  if (!value) return null;
  if ('stringValue' in value) return value.stringValue;
  if ('integerValue' in value) return parseInt(value.integerValue, 10);
  if ('doubleValue' in value) return parseFloat(value.doubleValue);
  if ('booleanValue' in value) return value.booleanValue;
  if ('timestampValue' in value) return value.timestampValue;
  if ('arrayValue' in value) {
    var values = value.arrayValue.values || [];
    return values.map(function(item) {
      return parseFirestoreValue(item);
    });
  }
  if ('mapValue' in value) {
    var fields = value.mapValue.fields || {};
    var obj = {};
    for (var key in fields) {
      obj[key] = parseFirestoreValue(fields[key]);
    }
    return obj;
  }
  return null;
}

/**
 * Mem-parsing dokumen Firestore mentah menjadi objek JavaScript murni
 */
function parseFirestoreDocument(doc) {
  var fields = doc.fields || {};
  var result = {};
  
  var nameParts = doc.name.split('/');
  result.id = nameParts[nameParts.length - 1];
  
  for (var key in fields) {
    result[key] = parseFirestoreValue(fields[key]);
  }
  return result;
}

/**
 * Memformat string tanggal ISO menjadi format terbaca sederhana WIB/Local
 */
function formatDateString(isoString) {
  try {
    var date = new Date(isoString);
    if (isNaN(date.getTime())) return isoString;
    
    var year = date.getFullYear();
    var month = ("0" + (date.getMonth() + 1)).slice(-2);
    var day = ("0" + date.getDate()).slice(-2);
    var hours = ("0" + date.getHours()).slice(-2);
    var minutes = ("0" + date.getMinutes()).slice(-2);
    var seconds = ("0" + date.getSeconds()).slice(-2);
    
    return year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds + " WIB";
  } catch (err) {
    return isoString;
  }
}
