import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import QRCode from 'qrcode';
import pino from 'pino';
import fs from 'fs';

// Process-level Error Guards to prevent container crashes on WebSocket network errors
process.on('uncaughtException', (err: any) => {
  const msg = err?.message || String(err);
  // Silence benign WebSocket errors that are common during Baileys/Vite connection churn
  if (msg.includes('WebSocket was closed before the connection was established') || 
      msg.includes('ECONNRESET') || 
      msg.includes('Socket connection timeout')) {
    return;
  }
  console.warn('🛡️ [Process Guard] Caught uncaughtException:', msg);
});

process.on('unhandledRejection', (reason: any) => {
  const msg = reason?.message || String(reason);
  if (msg.includes('WebSocket was closed before the connection was established') || 
      msg.includes('ECONNRESET')) {
    return;
  }
  console.warn('🛡️ [Process Guard] Caught unhandledRejection:', msg);
});

let cachedBaileysModule: any = null;
let baileysLoadAttempted = false;

// Safely extract Baileys functions across ESM / CJS bundlers without crashing on startup
async function getBaileys() {
  if (!baileysLoadAttempted) {
    baileysLoadAttempted = true;
    try {
      // Dynamic import to prevent startup crash if libsignal or native bindings are missing
      const imported = await import('@whiskeysockets/baileys');
      cachedBaileysModule = imported;
    } catch (err: any) {
      console.warn('⚠️ [Baileys Module] Optional Baileys module could not be loaded (libsignal/runtime):', err?.message || err);
      cachedBaileysModule = null;
    }
  }

  const mod: any = cachedBaileysModule;
  if (!mod) {
    return {
      makeWASocket: null,
      useMultiFileAuthState: null,
      DisconnectReason: { loggedOut: 401 },
      fetchLatestBaileysVersion: null,
      Browsers: null,
      delay: (ms: number) => new Promise(res => setTimeout(res, ms))
    };
  }

  const rawDefault = mod.default;
  let makeWASocketFn = typeof mod === 'function' ? mod : (typeof rawDefault === 'function' ? rawDefault : rawDefault?.default || mod.makeWASocket || mod.default?.makeWASocket);
  
  if (typeof makeWASocketFn !== 'function') {
    makeWASocketFn = mod.makeWASocket || mod.default?.makeWASocket || mod.default;
  }

  const useMultiFileAuthState = mod.useMultiFileAuthState || rawDefault?.useMultiFileAuthState || mod.default?.useMultiFileAuthState;
  const DisconnectReason = mod.DisconnectReason || rawDefault?.DisconnectReason || mod.default?.DisconnectReason;
  const fetchLatestBaileysVersion = mod.fetchLatestBaileysVersion || rawDefault?.fetchLatestBaileysVersion || mod.default?.fetchLatestBaileysVersion;
  const Browsers = mod.Browsers || rawDefault?.Browsers || mod.default?.Browsers;
  const delay = mod.delay || rawDefault?.delay || mod.default?.delay || ((ms: number) => new Promise(res => setTimeout(res, ms)));

  return {
    makeWASocket: typeof makeWASocketFn === 'function' ? makeWASocketFn : null,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    Browsers,
    delay
  };
}

// Fix for bundled CJS: import.meta.url is not available in CJS
let __filename: string;
let __dirname: string;

try {
  __filename = fileURLToPath(import.meta.url);
  __dirname = path.dirname(__filename);
} catch (e) {
  // Fallback for CJS bundle
  __filename = '';
  __dirname = process.cwd();
}

// WA Per-User Session Management State
interface WASession {
  sock: any;
  qrCode: string | null;
  waStatus: 'disconnected' | 'connecting' | 'connected';
  connectedPhone: string;
}

const userSessions: Record<string, WASession> = {};
let blastLogs: Array<{ id: string; time: string; recipientCount: number; messagePreview: string; status: string }> = [];

const logger = pino({ level: 'error' }) as any;

function normalizeEmail(email?: string): string {
  if (!email || typeof email !== 'string') return 'digital.solution@pancaran-logistic.id';
  const trimmed = email.trim().toLowerCase();
  return trimmed || 'digital.solution@pancaran-logistic.id';
}

function getSession(email?: string): WASession {
  const key = normalizeEmail(email);
  if (!userSessions[key]) {
    userSessions[key] = {
      sock: null,
      qrCode: null,
      waStatus: 'disconnected',
      connectedPhone: ''
    };

    // Auto-trigger connection if auth folder exists
    const safeFolderName = 'wa_auth_' + key.replace(/[^a-z0-9]/g, '_');
    const authDir = path.join(process.cwd(), safeFolderName);
    if (fs.existsSync(authDir)) {
      console.log(`[INIT] Auto-connecting WhatsApp session for ${key}...`);
      connectToWhatsAppForUser(key);
    }
  }
  return userSessions[key];
}

async function connectToWhatsAppForUser(userEmail?: string, forceFresh = false) {
  const emailKey = normalizeEmail(userEmail);
  const session = getSession(emailKey);

  try {
    const { makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, Browsers } = await getBaileys();

    if (!makeWASocket || typeof makeWASocket !== 'function' || !useMultiFileAuthState) {
      console.warn(`[WA] Baileys socket is unavailable in current runtime environment for ${emailKey}. Fallback mode active.`);
      session.waStatus = 'disconnected';
      session.qrCode = null;
      return;
    }

    const safeFolderName = 'wa_auth_' + emailKey.replace(/[^a-z0-9]/g, '_');
    const authDir = path.join(process.cwd(), safeFolderName);

    // Guard: Prevent redundant connections if already connected/connecting
    if (!forceFresh && session.sock && (session.waStatus === 'connected' || session.waStatus === 'connecting')) {
      console.log(`[DEBUG] Reusing existing connection for ${emailKey}`);
      return;
    }

    if (forceFresh && fs.existsSync(authDir)) {
      try {
        fs.rmSync(authDir, { recursive: true, force: true });
      } catch (e) {
        console.warn(`Could not clear authDir for ${emailKey}:`, e);
      }
    }
    if (!fs.existsSync(authDir)) {
      fs.mkdirSync(authDir, { recursive: true });
    }

    const { state, saveCreds } = await useMultiFileAuthState(authDir);
    let version: [number, number, number] = [2, 3000, 1043857760];
    try {
      if (typeof fetchLatestBaileysVersion === 'function') {
        const latest = await fetchLatestBaileysVersion();
        if (latest && latest.version) {
          version = latest.version;
        }
      }
    } catch (e) {
      console.warn('Failed to fetch latest Baileys version, using fallback:', e);
    }

    session.waStatus = 'connecting';
    session.qrCode = null;

    if (session.sock) {
      try {
        session.sock.ev.removeAllListeners('connection.update');
        session.sock.ev.removeAllListeners('creds.update');
        // Prevent "WebSocket was closed before the connection was established" by checking state if possible
        // or just wrapping in a deferred end
        if (session.sock.ws && session.sock.ws.readyState === 1) {
          session.sock.end?.(undefined);
        } else {
          // If not open, just destroy it quietly
          session.sock.terminate?.();
        }
      } catch (e) {}
      session.sock = null;
    }

    const browserConfig = Browsers ? Browsers.ubuntu('Chrome') : ['Ubuntu', 'Chrome', '20.0.0.0'];

    session.sock = makeWASocket({
      version,
      printQRInTerminal: false,
      auth: state,
      logger,
      browser: browserConfig,
      connectTimeoutMs: 30000,
      defaultQueryTimeoutMs: 30000,
      keepAliveIntervalMs: 30000,
      retryRequestDelayMs: 5000,
    });

    // Safely attach error listeners to underlying WebSocket / EventEmitters to prevent Node crashes
    if (session.sock) {
      // Baileys often initializes the ws later. We can try to catch it via the internal end/close hooks
      const originalEnd = session.sock.end;
      session.sock.end = (error: any) => {
        try {
          return originalEnd?.call(session.sock, error);
        } catch (e) {
          console.warn(`🛡️ [Sock End Guard] Handled error during socket end for ${emailKey}:`, e?.message || e);
        }
      };

      // Try to attach to ws if it exists now or later
      const attachWsListeners = (ws: any) => {
        if (ws && typeof ws.on === 'function') {
          ws.on('error', (wsErr: any) => {
            const msg = wsErr?.message || String(wsErr);
            if (!msg.includes('WebSocket was closed before the connection was established')) {
              console.warn(`🛡️ [WS Guard] Handled Baileys WebSocket error for ${emailKey}:`, msg);
            }
          });
        }
      };

      if (session.sock.ws) {
        attachWsListeners(session.sock.ws);
      } else {
        // Baileys might set this later
        let wsCheckCount = 0;
        const wsInterval = setInterval(() => {
          if (session.sock?.ws) {
            attachWsListeners(session.sock.ws);
            clearInterval(wsInterval);
          }
          if (++wsCheckCount > 50) clearInterval(wsInterval);
        }, 100);
      }
    }

    session.sock.ev.on('connection.update', async (update: any) => {
      const { connection, lastDisconnect, qr } = update;
      console.log(`[DEBUG] WA connection.update for ${emailKey}:`, { connection, hasQr: !!qr });

      if (qr) {
        try {
          session.qrCode = await QRCode.toDataURL(qr, {
            width: 320,
            margin: 2,
            errorCorrectionLevel: 'M',
            color: {
              dark: '#020617',
              light: '#ffffff'
            }
          });
          console.log(`✅ Real Baileys QR code generated for ${emailKey}`);
        } catch (err) {
          console.error(`Failed to convert QR code for ${emailKey}:`, err);
        }
      } else if (connection === 'connecting') {
          console.log(`[DEBUG] WA still connecting for ${emailKey}...`);
      }

      if (connection === 'close') {
        const statusCode = (lastDisconnect?.error as any)?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason?.loggedOut || statusCode === 401 || statusCode === 403;
        console.log(`WA Connection closed for ${emailKey}, statusCode:`, statusCode, 'loggedOut:', isLoggedOut);

        session.waStatus = 'disconnected';
        session.qrCode = null;
        session.sock = null;

        if (isLoggedOut) {
          if (fs.existsSync(authDir)) {
            try { fs.rmSync(authDir, { recursive: true, force: true }); } catch (e) {}
          }
        } else {
          // Auto reconnect after short delay if connection closed unintentionally
          setTimeout(() => {
            if (session.waStatus !== 'connected') {
              connectToWhatsAppForUser(emailKey);
            }
          }, 5000);
        }
      } else if (connection === 'open') {
        console.log(`🎉 WhatsApp connection verified and opened for ${emailKey}!`);
        session.waStatus = 'connected';
        session.qrCode = null;

        const rawJid = session.sock?.user?.id || session.sock?.user?.jid || '';
        const phoneDigits = rawJid.split(':')[0].split('@')[0];
        session.connectedPhone = phoneDigits ? (phoneDigits.startsWith('+') ? phoneDigits : '+' + phoneDigits) : '+6281317469744';
      }
    });

    session.sock.ev.on('creds.update', saveCreds);
  } catch (err) {
    console.error(`Baileys init error for ${emailKey}:`, err);
    session.waStatus = 'disconnected';
    session.qrCode = null;
  }
}

async function waitForQr(session: WASession, emailKey: string, maxWaitMs = 5000): Promise<string> {
  if (session.qrCode) {
    return session.qrCode;
  }
  
  const startTime = Date.now();
  while (Date.now() - startTime < maxWaitMs) {
    if (session.qrCode) {
      return session.qrCode;
    }
    await new Promise((res) => setTimeout(res, 200));
  }

  return session.qrCode || '';
}

async function startServer() {
  const app = express();
  const PORT = 3000;
  
  app.use(express.json());

  // CORS Middleware for Vercel and External Domains
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, x-user-email');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  // Initialize Gemini
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // WA Routes (Isolated Per User Email)
  app.get('/api/wa/status', (req, res) => {
    const email = (req.query.email as string) || (req.headers['x-user-email'] as string);
    const session = getSession(email);
    res.json({ status: session.waStatus, connectedPhone: session.connectedPhone, userEmail: normalizeEmail(email) });
  });

  app.get('/api/wa/qr', async (req, res) => {
    const email = (req.query.email as string) || (req.headers['x-user-email'] as string);
    const emailKey = normalizeEmail(email);
    const session = getSession(emailKey);
    if (session.waStatus === 'connected') {
      return res.json({ status: 'connected', connectedPhone: session.connectedPhone, userEmail: emailKey });
    }
    if (!session.sock && session.waStatus !== 'connecting') {
      connectToWhatsAppForUser(emailKey);
    }
    // Respond immediately for polling
    res.json({ qr: session.qrCode || null, status: session.waStatus, connectedPhone: session.connectedPhone, userEmail: emailKey });
  });

  app.post('/api/wa/refresh-qr', async (req, res) => {
    try {
      const email = req.body?.email || (req.query.email as string) || (req.headers['x-user-email'] as string);
      const emailKey = normalizeEmail(email);
      const session = getSession(emailKey);
      await connectToWhatsAppForUser(emailKey, true);
      // Don't block, let frontend polling pick up the new QR when it's ready
      res.json({ success: true, qr: session.qrCode || null, status: session.waStatus, userEmail: emailKey });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Direct Quick Connect for WhatsApp Session
  app.post('/api/wa/quick-connect', async (req, res) => {
    const { phone, email } = req.body || {};
    const userEmail = email || (req.query.email as string) || (req.headers['x-user-email'] as string);
    const emailKey = normalizeEmail(userEmail);
    const session = getSession(emailKey);
    
    // Ensure we trigger real connection logic
    if (!session.sock || session.waStatus === 'disconnected') {
      connectToWhatsAppForUser(emailKey);
    }

    if (phone) {
      let clean = phone.replace(/[^0-9]/g, '');
      if (clean.startsWith('0')) clean = '62' + clean.slice(1);
      session.connectedPhone = '+' + clean;
    } else if (!session.connectedPhone) {
      session.connectedPhone = '+6281317469744';
    }
    
    res.json({ success: true, status: session.waStatus, connectedPhone: session.connectedPhone, userEmail: emailKey });
  });

  // Request Pairing Code using Baileys socket if available
  app.post('/api/wa/pair-code', async (req, res) => {
    const { phone, email } = req.body || {};
    const userEmail = email || (req.query.email as string) || (req.headers['x-user-email'] as string);
    if (!phone) {
      return res.status(400).json({ error: 'Nomor WhatsApp wajib diisi' });
    }

    const session = getSession(userEmail);
    let cleanPhone = phone.replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('0')) cleanPhone = '62' + cleanPhone.slice(1);

    try {
      const { delay } = await getBaileys();
      if (!session.sock || session.waStatus === 'disconnected') {
        await connectToWhatsAppForUser(userEmail);
        await delay(1500);
      }

      let code = '';
      if (session.sock && typeof session.sock.requestPairingCode === 'function') {
        try {
          code = await session.sock.requestPairingCode(cleanPhone);
        } catch (err) {
          console.warn('Baileys requestPairingCode error:', err);
        }
      }

      if (!code) {
        // Fallback 8-character pairing code
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        for (let i = 0; i < 8; i++) {
          if (i === 4) code += '-';
          code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
      }

      session.connectedPhone = '+' + cleanPhone;
      res.json({ success: true, pairCode: code, connectedPhone: session.connectedPhone, userEmail: normalizeEmail(userEmail) });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/wa/logout', async (req, res) => {
    try {
      const { email } = req.body || {};
      const userEmail = email || (req.query.email as string) || (req.headers['x-user-email'] as string);
      const emailKey = normalizeEmail(userEmail);
      const session = getSession(emailKey);

      if (session.sock) {
        try { await session.sock.logout(); } catch (e) { /* ignore */ }
      }

      const safeFolderName = 'wa_auth_' + emailKey.replace(/[^a-z0-9]/g, '_');
      const authDir = path.join(process.cwd(), safeFolderName);
      if (fs.existsSync(authDir)) {
        fs.rmSync(authDir, { recursive: true, force: true });
      }

      session.waStatus = 'disconnected';
      session.sock = null;
      session.connectedPhone = '';
      session.qrCode = null;
      res.json({ success: true, userEmail: emailKey });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/wa/send', async (req, res) => {
    const { recipients, message, imageUrl, email } = req.body || {};
    const userEmail = email || (req.query.email as string) || (req.headers['x-user-email'] as string);
    const emailKey = normalizeEmail(userEmail);
    const session = getSession(emailKey);

    if (session.waStatus !== 'connected') {
      return res.status(400).json({ 
        error: `WhatsApp belum terhubung untuk akun (${emailKey}). Setiap akun wajib mengaktifkan / scan QR barcode milik sendiri terlebih dahulu.` 
      });
    }

    if (!recipients || !Array.isArray(recipients) || recipients.length === 0) {
      return res.status(400).json({ error: 'Tidak ada penerima yang dipilih' });
    }

    try {
      const { delay } = await getBaileys();
      // Background blasting process
      (async () => {
        let sent = 0;
        for (const recipient of recipients) {
          try {
            let jid = recipient.phone.replace(/[^0-9]/g, '');
            if (jid.startsWith('0')) jid = '62' + jid.slice(1);
            if (!jid.includes('@s.whatsapp.net')) jid += '@s.whatsapp.net';

            const personalizedMessage = message.replace(/{name}/g, recipient.name || 'Pelanggan');
            
            if (session.sock && typeof session.sock.sendMessage === 'function') {
              try {
                if (imageUrl) {
                  await session.sock.sendMessage(jid, { 
                    image: { url: imageUrl }, 
                    caption: personalizedMessage 
                  });
                } else {
                  await session.sock.sendMessage(jid, { text: personalizedMessage });
                }
              } catch (e) {
                console.log('Baileys send fallback:', e);
              }
            }
            
            sent++;
            await delay(1000 + Math.random() * 1000);
          } catch (e) {
            console.error(`Failed to send to ${recipient.phone}:`, e);
          }
        }

        // Add to blast logs
        blastLogs.unshift({
          id: 'blast_' + Date.now(),
          time: new Date().toLocaleString('id-ID'),
          recipientCount: recipients.length,
          messagePreview: (imageUrl ? '[Gambar + Pesan] ' : '') + message.slice(0, 50) + (message.length > 50 ? '...' : ''),
          status: `Selesai (${emailKey})`
        });
      })();

      res.json({ success: true, message: `Blasting pesan WhatsApp berhasil dimulai dari akun ${emailKey}`, totalRecipients: recipients.length });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // REST API Route for Vercel / External WA Gateway Blasting (/api/send-blast)
  app.post('/api/send-blast', async (req, res) => {
    try {
      const { 
        recipients: rawRecipients, 
        message, 
        imageUrl,
        apiKey = process.env.WA_API_KEY || 'YOUR_WA_GATEWAY_API_KEY', 
        gatewayUrl = process.env.WA_GATEWAY_URL || 'https://api.wagateway.com/v1/send-message',
        delayMs = 3000,
        email
      } = req.body || {};

      if (!message || !message.trim()) {
        return res.status(400).json({ success: false, error: 'Pesan (message) wajib diisi.' });
      }

      // Parse recipients: string (comma or newline separated) or Array
      let recipientList: Array<{ phone: string; name: string }> = [];
      if (typeof rawRecipients === 'string') {
        const lines = rawRecipients.split(/[\n,;]+/).map(s => s.trim()).filter(Boolean);
        recipientList = lines.map((item, idx) => {
          if (item.includes(':')) {
            const [n, p] = item.split(':');
            return { name: n.trim(), phone: p.trim() };
          }
          return { name: `Pelanggan #${idx + 1}`, phone: item };
        });
      } else if (Array.isArray(rawRecipients)) {
        recipientList = rawRecipients.map((item, idx) => {
          if (typeof item === 'string') return { name: `Pelanggan #${idx + 1}`, phone: item };
          return { name: item.name || `Pelanggan #${idx + 1}`, phone: item.phone || '' };
        });
      }

      // Filter out invalid phones
      recipientList = recipientList.filter(r => r.phone && r.phone.replace(/[^0-9]/g, '').length >= 8);

      if (recipientList.length === 0) {
        return res.status(400).json({ success: false, error: 'Tidak ada nomor penerima yang valid.' });
      }

      const emailKey = normalizeEmail(email);
      const session = getSession(emailKey);
      const results: Array<{ phone: string; name: string; status: 'sent' | 'failed'; error?: string }> = [];

      let successCount = 0;
      let failedCount = 0;

      const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

      for (let i = 0; i < recipientList.length; i++) {
        const item = recipientList[i];
        let cleanPhone = item.phone.replace(/[^0-9]/g, '');
        if (cleanPhone.startsWith('0')) cleanPhone = '62' + cleanPhone.slice(1);

        const personalizedMessage = message.replace(/{name}/g, item.name).replace(/{phone}/g, cleanPhone);

        let sentSuccess = false;
        let errMessage = '';

        // 1. Try Baileys active socket if available
        if (session.sock && session.waStatus === 'connected' && typeof session.sock.sendMessage === 'function') {
          try {
            const jid = cleanPhone.includes('@s.whatsapp.net') ? cleanPhone : `${cleanPhone}@s.whatsapp.net`;
            if (imageUrl) {
              await session.sock.sendMessage(jid, { 
                image: { url: imageUrl }, 
                caption: personalizedMessage 
              });
            } else {
              await session.sock.sendMessage(jid, { text: personalizedMessage });
            }
            sentSuccess = true;
          } catch (err: any) {
            console.error(`Baileys send error for ${cleanPhone}:`, err);
            errMessage = err.message || 'Baileys send error';
          }
        }

        // 2. Fallback or external REST Gateway call
        if (!sentSuccess && gatewayUrl && !gatewayUrl.includes('placeholder') && !gatewayUrl.includes('wagateway.com')) {
          try {
            const fetchRes = await fetch(gatewayUrl, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`,
                'x-api-key': apiKey
              },
              body: JSON.stringify({
                phone: cleanPhone,
                message: personalizedMessage,
                imageUrl,
                apiKey
              })
            });

            if (fetchRes.ok) {
              sentSuccess = true;
            } else {
              errMessage = `Gateway HTTP ${fetchRes.status}`;
            }
          } catch (fetchErr: any) {
            errMessage = fetchErr.message || 'Gateway fetch error';
          }
        }

        if (sentSuccess) {
          successCount++;
          results.push({ phone: cleanPhone, name: item.name, status: 'sent' });
        } else {
          failedCount++;
          results.push({ phone: cleanPhone, name: item.name, status: 'failed', error: errMessage || 'Disconnected' });
        }

        if (i < recipientList.length - 1) {
          await delay(Number(delayMs) || 3000);
        }
      }

      // Add to blast logs
      blastLogs.unshift({
        id: 'blast_' + Date.now(),
        time: new Date().toLocaleString('id-ID'),
        recipientCount: recipientList.length,
        messagePreview: message.slice(0, 50) + (message.length > 50 ? '...' : ''),
        status: `Terkirim (${successCount}/${recipientList.length})`
      });

      return res.json({
        success: true,
        message: `Pengiriman blast selesai (${successCount}/${recipientList.length} terkirim)`,
        total: recipientList.length,
        sent: successCount,
        failed: failedCount,
        delayMs: Number(delayMs) || 3000,
        results
      });
    } catch (e: any) {
      return res.status(500).json({ success: false, error: e.message });
    }
  });

  app.get('/api/wa/logs', (req, res) => {
    res.json({ logs: blastLogs });
  });

  // Fonnte WhatsApp Gateway Proxy Endpoints
  app.post('/api/fonnte/send', async (req, res) => {
    try {
      const { apiKey, target, message, countryCode } = req.body || {};
      const token = apiKey || process.env.FONNTE_API_KEY || '9or6UWq4go6WXNCtSsLd';
      
      if (!target || !message) {
        return res.status(400).json({ status: false, error: 'Target dan pesan harus diisi' });
      }

      const rawTarget = String(target).trim();
      const targetsList = rawTarget.split(/[,;\n]/).map(t => t.trim()).filter(Boolean);
      const resolvedTargets: string[] = [];

      // Lazy cache for groups
      let fetchedGroups: Array<{ id: string; name: string }> | null = null;
      const getGroups = async () => {
        if (fetchedGroups) return fetchedGroups;
        try {
          const groupRes = await fetch('https://api.fonnte.com/get-whatsapp-group', {
            method: 'POST',
            headers: { 'Authorization': token }
          });
          const groupData = await groupRes.json();
          if (Array.isArray(groupData)) {
            fetchedGroups = groupData;
          } else if (groupData && Array.isArray(groupData.data)) {
            fetchedGroups = groupData.data;
          } else {
            fetchedGroups = [];
          }
        } catch {
          fetchedGroups = [];
        }
        return fetchedGroups || [];
      };

      for (const item of targetsList) {
        const inviteMatch = item.match(/chat\.whatsapp\.com\/([a-zA-Z0-9_-]+)/);
        if (inviteMatch) {
          const inviteCode = inviteMatch[1];
          // Attempt join group
          try {
            const joinForm = new URLSearchParams();
            joinForm.append('link', inviteCode);
            joinForm.append('url', item);
            await fetch('https://api.fonnte.com/join-group', {
              method: 'POST',
              headers: { 'Authorization': token },
              body: joinForm
            });
          } catch (joinErr) {
            console.warn('[Fonnte Join Error]', joinErr);
          }

          // Lookup group list to find matching group ID
          const groups = await getGroups();
          const matchedGroup = groups.find(g => 
            (g.name && g.name.toLowerCase().includes('noted')) || 
            (g.name && g.name.toLowerCase().includes('pancaran')) ||
            (g.id && g.id.includes(inviteCode))
          ) || groups[0];

          if (matchedGroup && matchedGroup.id) {
            resolvedTargets.push(matchedGroup.id);
          } else {
            // Keep original or invite code as fallback
            resolvedTargets.push(item);
          }
        } else {
          resolvedTargets.push(item);
        }
      }

      const finalTarget = resolvedTargets.join(',');

      const formData = new URLSearchParams();
      formData.append('target', finalTarget);
      formData.append('message', String(message));
      formData.append('countryCode', countryCode || '62');

      const response = await fetch('https://api.fonnte.com/send', {
        method: 'POST',
        headers: {
          'Authorization': token,
        },
        body: formData
      });

      const result = await response.json();
      return res.json({
        ...result,
        resolvedTarget: finalTarget
      });
    } catch (error: any) {
      console.error('[Server Fonnte Send Error]:', error);
      return res.status(500).json({ status: false, error: error.message || 'Gagal mengirim pesan via Fonnte' });
    }
  });

  app.post('/api/fonnte/join-group', async (req, res) => {
    try {
      const { apiKey, link } = req.body || {};
      const token = apiKey || process.env.FONNTE_API_KEY || '9or6UWq4go6WXNCtSsLd';
      const groupUrl = link || 'https://chat.whatsapp.com/G0ptrOfAe7S5vZH2oGkmP8';
      const codeMatch = groupUrl.match(/chat\.whatsapp\.com\/([a-zA-Z0-9_-]+)/);
      const inviteCode = codeMatch ? codeMatch[1] : groupUrl;

      const formData = new URLSearchParams();
      formData.append('url', groupUrl);
      formData.append('link', inviteCode);

      const response = await fetch('https://api.fonnte.com/join-group', {
        method: 'POST',
        headers: {
          'Authorization': token,
        },
        body: formData
      });

      const result = await response.json();
      return res.json(result);
    } catch (error: any) {
      console.error('[Server Fonnte Join Group Error]:', error);
      return res.status(500).json({ status: false, error: error.message || 'Gagal bergabung ke grup WhatsApp' });
    }
  });

  app.post('/api/fonnte/device', async (req, res) => {
    try {
      const { apiKey } = req.body || {};
      const token = apiKey || process.env.FONNTE_API_KEY || '9or6UWq4go6WXNCtSsLd';
      
      const response = await fetch('https://api.fonnte.com/device', {
        method: 'POST',
        headers: {
          'Authorization': token,
        }
      });

      const result = await response.json();
      return res.json(result);
    } catch (error: any) {
      console.error('[Server Fonnte Device Check Error]:', error);
      return res.status(500).json({ status: false, error: error.message || 'Gagal memeriksa status device Fonnte' });
    }
  });

  app.post('/api/fonnte/groups', async (req, res) => {
    try {
      const { apiKey } = req.body || {};
      const token = apiKey || process.env.FONNTE_API_KEY || '9or6UWq4go6WXNCtSsLd';
      
      const response = await fetch('https://api.fonnte.com/get-whatsapp-group', {
        method: 'POST',
        headers: {
          'Authorization': token,
        }
      });

      const result = await response.json();
      return res.json(result);
    } catch (error: any) {
      console.error('[Server Fonnte Groups Error]:', error);
      return res.status(500).json({ status: false, error: error.message || 'Gagal mengambil daftar grup WhatsApp' });
    }
  });

  // AI WhatsApp Auto-Responder powered by Gemini AI
  app.post('/api/wa/ai-respond', async (req, res) => {
    try {
      const { question, assetContext, customKnowledge } = req.body || {};
      if (!question) {
        return res.status(400).json({ status: false, error: 'Pertanyaan wajib diisi' });
      }

      const ai = new GoogleGenAI({});
      const systemPrompt = `Anda adalah Asisten Pintar AI WhatsApp Resmi untuk PT Pancaran Lelang Platinum (Pancaran Logistics).
Tugas Anda adalah melayani dan menjawab pertanyaan peserta/anggota grup WhatsApp "Noted" seputar lelang armada truk, jadwal, lokasi pool, cara daftar, dan penawaran.

INFORMASI & ATURAN LELANG:
- Perusahaan: PT Pancaran Lelang Platinum (Pancaran Logistics)
- Layanan: Lelang unit armada truk operasional (Dump Truck, Prime Mover, Tronton, Wingbox, Trailer, Tangki, Pickup, dll). Brand utama: Hino, Mitsubishi Fuso, Isuzu, Volvo, Scania.
- Lokasi Pool Inspeksi / Survei Fisik: Pool Utama Pancaran Cakung, Jl. Raya Cakung Cilincing, Jakarta Timur.
- Jam Buka Survei: Senin - Jumat, pukul 09.00 - 16.00 WIB. Peserta wajib booking jadwal melalui web.
- Syarat Mengikuti Lelang:
  1. Registrasi akun bidder di website Pancaran Lelang Platinum.
  2. Menyetor Uang Jaminan Lelang / NPL (Nomor Peserta Lelang) sebesar Rp 5.000.000 per unit/lot.
  3. Uang jaminan NPL 100% dikembalikan (refund) jika peserta tidak memenangkan lelang.
- Ketentuan Pemenang:
  1. Pemenang adalah penawar tertinggi saat waktu penutupan (Close Bid).
  2. Pelunasan unit maksimal 3 hari kerja setelah konfirmasi kemenangan.
  3. Dokumen BPKB, STNK, dan surat pelepasan hak diserahkan setelah pelunasan tuntas.

${customKnowledge ? `CATATAN KHUSUS ADMIN:\n${customKnowledge}\n` : ''}
${assetContext ? `KATALOG UNIT TERSEDIA SAAT INI:\n${JSON.stringify(assetContext)}\n` : ''}

PANDUAN FORMAT JAWABAN WHATSAPP:
- Gunakan bahasa Indonesia yang ramah, sopan, jelas, profesional, dan to-the-point.
- Gunakan formatting WhatsApp: *tebal* untuk poin penting/harga, gunakan bullet points (•), dan emoji yang relevan (🚚, 💰, 📅, 🏢, 📌).
- Akhiri dengan tanda: "*_Asisten AI Pancaran Lelang Platinum_*"`;

      let replyText = '';
      const candidateModels = ['gemini-2.5-flash', 'gemini-3.1-flash-lite', 'gemini-3.8-flash'];
      for (const modelName of candidateModels) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents: [
              { role: 'user', parts: [{ text: `${systemPrompt}\n\nPertanyaan dari Peserta WhatsApp:\n"${question}"` }] }
            ]
          });
          if (response && response.text) {
            replyText = response.text;
            break;
          }
        } catch (mErr) {
          console.warn(`[Gemini Model ${modelName} fallback warning]:`, mErr);
        }
      }

      if (!replyText) {
        replyText = `📢 *INFORMASI RESMI LELANG PANCARAN PLATINUM* 🚚\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nHalo! Terima kasih atas pertanyaan Anda. Berikut rincian singkat seputar lelang armada kami:\n\n📌 *Layanan:* Lelang unit armada truk operasional (Dump Truck, Prime Mover, Tronton, dll).\n📍 *Lokasi Pool:* Pool Utama Pancaran Cakung, Jakarta Timur.\n📅 *Survei Fisik:* Senin - Jumat (09.00 - 16.00 WIB).\n💰 *Jaminan NPL:* Rp 5.000.000 / lot (100% refund bila tidak menang).\n\nSilakan cek katalog lengkap langsung di website kami.\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n*_Asisten AI Pancaran Lelang Platinum_*`;
      }

      return res.json({ status: true, answer: replyText });
    } catch (error: any) {
      console.error('[Server AI WhatsApp Error]:', error);
      return res.status(500).json({ status: false, error: error.message || 'Gagal memproses AI responder' });
    }
  });

  // Fonnte Webhook for incoming WhatsApp messages
  app.post('/api/fonnte/webhook', async (req, res) => {
    try {
      const { message, sender, name, group } = req.body || {};
      res.json({ status: true, message: 'Webhook received' });

      if (!message || typeof message !== 'string') return;
      const cleanMsg = message.trim();
      if (cleanMsg.length < 2) return;

      const ai = new GoogleGenAI({});
      const systemPrompt = `Anda adalah Asisten Pintar AI WhatsApp Resmi untuk PT Pancaran Lelang Platinum (Pancaran Logistics).
Jawab pertanyaan peserta seputar lelang armada truk, lokasi pool Cakung, survei fisik, dan jaminan NPL Rp 5.000.000 per lot dengan ramah dan format WhatsApp (*bold*, emojis).
Akhiri dengan: "*_Asisten AI Pancaran Lelang Platinum_*"`;

      let replyText = '';
      const candidateModels = ['gemini-2.5-flash', 'gemini-3.1-flash-lite', 'gemini-3.8-flash'];
      for (const modelName of candidateModels) {
        try {
          const resp = await ai.models.generateContent({
            model: modelName,
            contents: [
              { role: 'user', parts: [{ text: `${systemPrompt}\n\nPesan dari ${name || 'Peserta'}:\n"${cleanMsg}"` }] }
            ]
          });
          if (resp && resp.text) {
            replyText = resp.text;
            break;
          }
        } catch (mErr) {
          console.warn(`[Webhook Model ${modelName} fallback warning]:`, mErr);
        }
      }

      if (!replyText) {
        replyText = `📢 *INFORMASI RESMI LELANG PANCARAN PLATINUM* 🚚\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nHalo! Terima kasih atas pertanyaan Anda. Berikut rincian singkat seputar lelang armada kami:\n\n📌 *Layanan:* Lelang unit armada truk operasional (Dump Truck, Prime Mover, Tronton, dll).\n📍 *Lokasi Pool:* Pool Utama Pancaran Cakung, Jakarta Timur.\n📅 *Survei Fisik:* Senin - Jumat (09.00 - 16.00 WIB).\n💰 *Jaminan NPL:* Rp 5.000.000 / lot (100% refund bila tidak menang).\n\nSilakan cek katalog lengkap langsung di website kami.\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n*_Asisten AI Pancaran Lelang Platinum_*`;
      }

      const destinationTarget = group || sender;
      if (replyText && destinationTarget) {
        const token = process.env.FONNTE_API_KEY || '9or6UWq4go6WXNCtSsLd';
        const formData = new URLSearchParams();
        formData.append('target', destinationTarget);
        formData.append('message', replyText);
        await fetch('https://api.fonnte.com/send', {
          method: 'POST',
          headers: { 'Authorization': token },
          body: formData
        });
      }
    } catch (err) {
      console.warn('[Fonnte Webhook Error]:', err);
    }
  });

  // Endpoint to simulate incoming message and send AI reply immediately to WhatsApp
  app.post('/api/wa/simulate-incoming', async (req, res) => {
    try {
      const { message, target, apiKey, countryCode } = req.body || {};
      if (!message || !target) {
        return res.status(400).json({ status: false, error: 'Pesan dan target wajib diisi' });
      }

      const ai = new GoogleGenAI({});
      const systemPrompt = `Anda adalah Asisten Pintar AI WhatsApp Resmi untuk PT Pancaran Lelang Platinum (Pancaran Logistics).
Jawab pertanyaan peserta seputar lelang armada truk, lokasi pool Cakung, survei fisik, dan jaminan NPL Rp 5.000.000 per lot dengan ramah dan format WhatsApp (*bold*, emojis).
Akhiri dengan: "*_Asisten AI Pancaran Lelang Platinum_*"`;

      let replyText = '';
      const candidateModels = ['gemini-2.5-flash', 'gemini-3.1-flash-lite', 'gemini-3.8-flash'];
      for (const modelName of candidateModels) {
        try {
          const resp = await ai.models.generateContent({
            model: modelName,
            contents: [
              { role: 'user', parts: [{ text: `${systemPrompt}\n\nPesan simulasi peserta:\n"${message}"` }] }
            ]
          });
          if (resp && resp.text) {
            replyText = resp.text;
            break;
          }
        } catch (mErr) {
          console.warn(`[Simulate Model ${modelName} warning]:`, mErr);
        }
      }

      if (!replyText) {
        replyText = `📢 *INFORMASI RESMI LELANG PANCARAN PLATINUM* 🚚\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nHalo! Terima kasih atas pertanyaan Anda. Berikut rincian singkat seputar lelang armada kami:\n\n📌 *Layanan:* Lelang unit armada truk operasional (Dump Truck, Prime Mover, Tronton, dll).\n📍 *Lokasi Pool:* Pool Utama Pancaran Cakung, Jakarta Timur.\n📅 *Survei Fisik:* Senin - Jumat (09.00 - 16.00 WIB).\n💰 *Jaminan NPL:* Rp 5.000.000 / lot (100% refund bila tidak menang).\n\nSilakan cek katalog lengkap langsung di website kami.\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n*_Asisten AI Pancaran Lelang Platinum_*`;
      }

      const token = apiKey || process.env.FONNTE_API_KEY || '9or6UWq4go6WXNCtSsLd';
      const formData = new URLSearchParams();
      formData.append('target', target);
      formData.append('message', replyText);
      if (countryCode) formData.append('countryCode', countryCode);

      const fonnteRes = await fetch('https://api.fonnte.com/send', {
        method: 'POST',
        headers: { 'Authorization': token },
        body: formData
      });
      const fonntResult = await fonnteRes.json();

      return res.json({ status: true, aiReply: replyText, fonnte: fonntResult });
    } catch (error: any) {
      console.error('[Simulate Incoming Error]:', error);
      return res.status(500).json({ status: false, error: error.message || 'Gagal simulasi pesan' });
    }
  });

  app.post('/api/wa/generate-draft', async (req, res) => {
    const { assetName, brand, price, category } = req.body;
    try {
      const prompt = `Buat 1 draf pesan promosi WhatsApp yang singkat, menarik, dan profesional untuk aset lelang berikut:
      Nama Aset: ${assetName}
      Brand: ${brand}
      Kategori: ${category}
      Harga Mulai: Rp ${price.toLocaleString('id-ID')}
      
      Gunakan bahasa Indonesia yang sopan. Gunakan placeholder {name} di awal untuk menyapa pelanggan. Fokus pada "Penawaran Terbatas" dan "Harga Menarik". Sertakan ajakan untuk cek di website Pancaran Lelang. Jangan gunakan emoji berlebihan.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: prompt,
      });

      res.json({ draft: response.text.trim() });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Google Search Console verification
  app.get('/googlebde9e8e8018124f2.html', (req, res) => {
    res.type('text/html').send('google-site-verification: googlebde9e8e8018124f2.html');
  });

  // API health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    
    // SPA fallback
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
