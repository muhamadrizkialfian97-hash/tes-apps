import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Asset, AssetStatus, Bid, Brand, Category, Condition, Series, VehicleColour, FuelType, AttachmentCategory, AttachmentType, MAIN_CATEGORIES, normalizeCategory, getGoogleMapsUrl, UsedPartItem, sortAssetsByNewest, getHighestBidBreakdown, isSubCategoryMatch, getCleanAssetName, normalizeUsedPartItem } from '../types';
import { useLanguage } from './LanguageContext';
import { OfficialWinnerLetterModal } from './OfficialWinnerLetterModal';
import { 
  addBrandToDb, 
  deleteBrandFromDb,
  addCategoryToDb,
  deleteCategoryFromDb,
  addConditionToDb,
  deleteConditionFromDb,
  addSeriesToDb,
  deleteSeriesFromDb,
  addVehicleColourToDb,
  deleteVehicleColourFromDb,
  addFuelTypeToDb,
  deleteFuelTypeFromDb,
  addAttachmentCategoryToDb,
  deleteAttachmentCategoryFromDb,
  addAttachmentTypeToDb,
  deleteAttachmentTypeFromDb
} from '../firebase';
import { 
  Plus, 
  Search, 
  Filter, 
  Trash2, 
  Eye, 
  Check, 
  X, 
  ExternalLink,
  Calendar,
  DollarSign,
  Tag,
  AlertTriangle,
  FileText,
  MapPin,
  Clock,
  Sparkles,
  Upload,
  Trophy,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Settings,
  Mail,
  Phone,
  Copy,
  Truck,
  Wrench,
  Building2,
  Package,
  Disc,
  BatteryCharging,
  Layers,
  Droplet,
  CheckCircle,
  CheckSquare,
  Square,
  CameraOff,
  TrendingUp,
  Info,
  Edit2,
  Image as ImageIcon
} from 'lucide-react';

export const convertDriveUrlToDirect = (url: string): string => {
  if (!url) return '';
  const trimmed = url.trim();
  const driveRegex = /\/file\/d\/([a-zA-Z0-9_-]+)/;
  const match = trimmed.match(driveRegex);
  if (match && match[1]) {
    return `https://lh3.googleusercontent.com/d/${match[1]}=s1200`;
  }
  const idParamRegex = /[?&]id=([a-zA-Z0-9_-]+)/;
  const matchId = trimmed.match(idParamRegex);
  if (matchId && matchId[1]) {
    return `https://lh3.googleusercontent.com/d/${matchId[1]}=s1200`;
  }
  return trimmed;
};

export const TEMPLATE_PHOTOS = [
  {
    id: 'tpl-1',
    name: 'Template Foto 1',
    url: 'https://lh3.googleusercontent.com/d/1o6jjXq_qVsJK5LxByz8n3kRe6Gq0NN-V=s1200',
    driveUrl: 'https://drive.google.com/file/d/1o6jjXq_qVsJK5LxByz8n3kRe6Gq0NN-V/view?usp=drive_link'
  },
  {
    id: 'tpl-2',
    name: 'Template Foto 2',
    url: 'https://lh3.googleusercontent.com/d/18x4gjreZMjUkjhjGzlHAEIDf9vUkgP6l=s1200',
    driveUrl: 'https://drive.google.com/file/d/18x4gjreZMjUkjhjGzlHAEIDf9vUkgP6l/view?usp=drive_link'
  },
  {
    id: 'tpl-3',
    name: 'Template Foto 3',
    url: 'https://lh3.googleusercontent.com/d/1mHFE_M8faepQMPoBiKo--ChekgUaudwt=s1200',
    driveUrl: 'https://drive.google.com/file/d/1mHFE_M8faepQMPoBiKo--ChekgUaudwt/view?usp=drive_link'
  },
  {
    id: 'tpl-4',
    name: 'Template Foto 4',
    url: 'https://lh3.googleusercontent.com/d/1OVFFHLqL9qbndG7ZwXO1VLzQGOafatFH=s1200',
    driveUrl: 'https://drive.google.com/file/d/1OVFFHLqL9qbndG7ZwXO1VLzQGOafatFH/view?usp=drive_link'
  }
];

interface AdminAssetsProps {
  assets: Asset[];
  brands?: Brand[];
  categories?: Category[];
  conditions?: Condition[];
  seriesList?: Series[];
  vehicleColours?: VehicleColour[];
  fuelTypes?: FuelType[];
  attachmentCategories?: AttachmentCategory[];
  attachmentTypes?: AttachmentType[];
  selectedAssetId: string | null;
  onSelectAsset: (assetId: string | null) => void;
  onAddAsset: (newAsset: Omit<Asset, 'id' | 'bids' | 'highestBid'>) => void;
  onUpdateAsset: (assetId: string, updatedAsset: Partial<Asset>) => void;
  onUpdateAssetStatus: (assetId: string, status: AssetStatus) => void;
  onDeleteAsset: (assetId: string) => void;
  onDeleteBid?: (assetId: string, bidId: string) => void;
}

const compressImage = (file: File, maxWidth: number = 800, maxHeight: number = 600, quality: number = 0.75): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = document.createElement('img');
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // Calculate new dimensions keeping aspect ratio
        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(event.target?.result as string); // Fallback to original base64 if context is not available
          return;
        }

        // Draw image on canvas
        ctx.drawImage(img, 0, 0, width, height);
        
        // Get compressed base64 string
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.onerror = () => {
        reject(new Error('Gagal memuat gambar untuk kompresi.'));
      };
      img.src = event.target?.result as string;
    };
    reader.onerror = () => {
      reject(new Error('Gagal membaca file gambar.'));
    };
    reader.readAsDataURL(file);
  });
};

const VEHICLE_TEMPLATES = [
  { name: 'Hino Wingbox Heavy-Duty', brand: 'Hino', category: 'Vehicle', url: 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=800&q=80' },
  { name: 'Isuzu Giga Box Besi', brand: 'Isuzu', category: 'Vehicle', url: 'https://images.unsplash.com/photo-1516576885502-d5334430e52b?auto=format&fit=crop&w=800&q=80' },
  { name: 'Fuso Colt Dump Truck', brand: 'Fuso', category: 'Vehicle', url: 'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?auto=format&fit=crop&w=800&q=80' },
  { name: 'Scania Premium Head Container', brand: 'Scania', category: 'Vehicle', url: 'https://images.unsplash.com/photo-1592838064575-70ed626d3a44?auto=format&fit=crop&w=800&q=80' },
  { name: 'Toyota Hilux Single Cabin', brand: 'Toyota', category: 'Vehicle', url: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80' },
  { name: 'Caterpillar Forklift Diesel', brand: 'Caterpillar', category: 'Vehicle', url: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=800&q=80' },
];

function CountdownTimer({ targetDate, size = 'small' }: { targetDate: string; size?: 'small' | 'large' }) {
  const { t } = useLanguage();
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    isExpired: boolean;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0, isExpired: false });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = +new Date(targetDate) - +new Date();
      if (difference <= 0) {
        return { days: 0, hours: 0, minutes: 0, seconds: 0, isExpired: true };
      }
      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
        isExpired: false
      };
    };

    setTimeLeft(calculateTimeLeft());

    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(timer);
  }, [targetDate]);

  if (timeLeft.isExpired) {
    return (
      <span className={`font-bold text-rose-600 ${size === 'large' ? 'text-xs' : 'text-[10px]'}`}>
        {t('Close Bid')}
      </span>
    );
  }

  const parts = [];
  if (timeLeft.days > 0) parts.push(`${timeLeft.days}d`);
  if (timeLeft.hours > 0 || timeLeft.days > 0) parts.push(`${timeLeft.hours}h`);
  parts.push(`${timeLeft.minutes}m`);
  parts.push(`${timeLeft.seconds}s`);

  if (size === 'large') {
    return (
      <div className="flex items-center gap-1.5 font-mono">
        {timeLeft.days > 0 && (
          <div className="bg-amber-100/85 border border-amber-200 text-amber-950 px-2 py-1 rounded-xl text-center min-w-[32px]">
            <span className="text-sm font-bold block leading-none">{timeLeft.days}</span>
            <span className="text-[8px] font-extrabold uppercase text-amber-800 tracking-wider">Hari</span>
          </div>
        )}
        <div className="bg-amber-100/85 border border-amber-200 text-amber-950 px-2 py-1 rounded-xl text-center min-w-[32px]">
          <span className="text-sm font-bold block leading-none">{timeLeft.hours}</span>
          <span className="text-[8px] font-extrabold uppercase text-amber-800 tracking-wider">Jam</span>
        </div>
        <div className="bg-amber-100/85 border border-amber-200 text-amber-950 px-2 py-1 rounded-xl text-center min-w-[32px]">
          <span className="text-sm font-bold block leading-none">{timeLeft.minutes}</span>
          <span className="text-[8px] font-extrabold uppercase text-amber-800 tracking-wider">Menit</span>
        </div>
        <div className="bg-amber-100/85 border border-amber-200 text-amber-950 px-2 py-1 rounded-xl text-center min-w-[32px] animate-pulse">
          <span className="text-sm font-bold block leading-none text-rose-600">{timeLeft.seconds}</span>
          <span className="text-[8px] font-extrabold uppercase text-rose-500 tracking-wider">Detik</span>
        </div>
      </div>
    );
  }

  return (
    <span className="bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-md font-mono text-[10px] border border-amber-200 shadow-2xs font-extrabold">
      {parts.join(' ')}
    </span>
  );
}


export default function AdminAssets({
  assets,
  brands = [],
  categories = [],
  conditions = [],
  seriesList = [],
  vehicleColours = [],
  fuelTypes = [],
  attachmentCategories = [],
  attachmentTypes = [],
  selectedAssetId,
  onSelectAsset,
  onAddAsset,
  onUpdateAsset,
  onUpdateAssetStatus,
  onDeleteAsset,
  onDeleteBid
}: AdminAssetsProps) {
  const { language, t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'all' | 'Open' | 'Sold'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [brandFilter, setBrandFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [conditionFilter, setConditionFilter] = useState<string>('all');
  const [manifestFilter, setManifestFilter] = useState<string>('all');
  const [selectedWinnerLetterAsset, setSelectedWinnerLetterAsset] = useState<Asset | null>(null);

  // Master Brand Management State
  const [isBrandMasterOpen, setIsBrandMasterOpen] = useState(false);
  const [newBrandName, setNewBrandName] = useState('');
  const [brandError, setBrandError] = useState('');

  // Master Manifest Management State
  const [manifestOptions, setManifestOptions] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('pancaran_manifest_options');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return ['Pake Manifest', 'Tidak Pake Manifest'];
  });
  const [isManifestMasterOpen, setIsManifestMasterOpen] = useState(false);
  const [newManifestName, setNewManifestName] = useState('');
  const [manifestError, setManifestError] = useState('');

  // Master Used Part Sub-Categories Management State
  const [usedPartSubCats, setUsedPartSubCats] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('pancaran_usedpart_subcategories');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return ['Ban', 'Aki', 'Besi', 'Oli', 'Lainnya'];
  });
  const [isUsedPartSubCatMasterOpen, setIsUsedPartSubCatMasterOpen] = useState(false);
  const [newUsedPartSubCatName, setNewUsedPartSubCatName] = useState('');
  const [usedPartSubCatError, setUsedPartSubCatError] = useState('');

  // Master Sales System Options State
  const [salesSystemOptions, setSalesSystemOptions] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('pancaran_usedpart_sales_systems');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return ['Satuan', 'Borongan', 'Timbangan'];
  });
  const [isSalesSystemMasterOpen, setIsSalesSystemMasterOpen] = useState(false);
  const [newSalesSystemName, setNewSalesSystemName] = useState('');
  const [salesSystemError, setSalesSystemError] = useState('');

  // Master Tire Type Options State
  const [tireTypeOptions, setTireTypeOptions] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('pancaran_usedpart_tire_types');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return ['Ban Luar', 'Ban Dalam', 'Flap', 'Set (Ban Luar + Dalam + Flap)'];
  });
  const [isTireTypeMasterOpen, setIsTireTypeMasterOpen] = useState(false);
  const [newTireTypeName, setNewTireTypeName] = useState('');
  const [tireTypeError, setTireTypeError] = useState('');

  // Master Tire Rim Options State
  const [tireRimOptions, setTireRimOptions] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('pancaran_usedpart_tire_rim_types');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      'Tanpa Velg (Hanya Ban)',
      'Velg Besi / Steel Rim (Ring 20)',
      'Velg Besi Tubeless (Ring 22.5)',
      'Velg Aluminium / Alloy Rim',
      'Velg Ring Lock / Split Rim'
    ];
  });
  const [isTireRimMasterOpen, setIsTireRimMasterOpen] = useState(false);
  const [newTireRimName, setNewTireRimName] = useState('');
  const [tireRimError, setTireRimError] = useState('');

  // Master Tire Grade Options State
  const [tireGradeOptions, setTireGradeOptions] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('pancaran_usedpart_tire_grades');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return ['1', '2', '3', 'Grade A', 'Grade B', 'Grade C'];
  });
  const [isTireGradeMasterOpen, setIsTireGradeMasterOpen] = useState(false);
  const [newTireGradeName, setNewTireGradeName] = useState('');
  const [tireGradeError, setTireGradeError] = useState('');

  // Master Metal Type Options State
  const [metalTypeOptions, setMetalTypeOptions] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('pancaran_usedpart_metal_types');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      'Besi Berat / H-Beam / I-Beam / Plate',
      'Besi Siku / Pipa / Hollow',
      'Besi Tipis / Seng / Body Part',
      'Besi Campur / Scrap Variasi',
      'Logam Lain (Tembaga / Kuningan / Aluminium)'
    ];
  });
  const [isMetalTypeMasterOpen, setIsMetalTypeMasterOpen] = useState(false);
  const [newMetalTypeName, setNewMetalTypeName] = useState('');
  const [metalTypeError, setMetalTypeError] = useState('');

  // Master Metal Sales Method Options State
  const [metalSalesMethodOptions, setMetalSalesMethodOptions] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('pancaran_usedpart_metal_sales_methods');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      'Penimbangan (Harga per Kg / Ton)',
      'Taksiran / Borongan (Harga langsung 1 Lot)'
    ];
  });
  const [isMetalSalesMethodMasterOpen, setIsMetalSalesMethodMasterOpen] = useState(false);
  const [newMetalSalesMethodName, setNewMetalSalesMethodName] = useState('');
  const [metalSalesMethodError, setMetalSalesMethodError] = useState('');

  // Master Category Management State
  const [isCategoryMasterOpen, setIsCategoryMasterOpen] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [categoryError, setCategoryError] = useState('');

  // Master Physical Condition Management State
  const [isConditionMasterOpen, setIsConditionMasterOpen] = useState(false);
  const [newConditionName, setNewConditionName] = useState('');
  const [conditionError, setConditionError] = useState('');

  // Master Series Management State
  const [isSeriesMasterOpen, setIsSeriesMasterOpen] = useState(false);
  const [newSeriesName, setNewSeriesName] = useState('');
  const [seriesError, setSeriesError] = useState('');

  // Master Vehicle Colour Management State
  const [isColourMasterOpen, setIsColourMasterOpen] = useState(false);
  const [newColourName, setNewColourName] = useState('');
  const [colourError, setColourError] = useState('');

  // Master Fuel Type Management State
  const [isFuelMasterOpen, setIsFuelMasterOpen] = useState(false);
  const [newFuelName, setNewFuelName] = useState('');
  const [fuelError, setFuelError] = useState('');

  // Master Attachment Category Management State
  const [isAttachmentMasterOpen, setIsAttachmentMasterOpen] = useState(false);
  const [newAttachmentName, setNewAttachmentName] = useState('');
  const [attachmentError, setAttachmentError] = useState('');

  // Master Attachment Type Management State
  const [isAttachmentTypeMasterOpen, setIsAttachmentTypeMasterOpen] = useState(false);
  const [newAttachmentTypeName, setNewAttachmentTypeName] = useState('');
  const [attachmentTypeError, setAttachmentTypeError] = useState('');
  
  // Form State
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isAttachmentDragging, setIsAttachmentDragging] = useState(false);
  const [editAssetId, setEditAssetId] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [bidDeleteConfirmId, setBidDeleteConfirmId] = useState<string | null>(null);
  const [surveyCancelConfirmId, setSurveyCancelConfirmId] = useState<string | null>(null);
  const [detailImageIdx, setDetailImageIdx] = useState(0);

  // Bid rescheduling state
  const [editingBidId, setEditingBidId] = useState<string | null>(null);
  const [newSurveyDate, setNewSurveyDate] = useState('');
  const [newSurveyTime, setNewSurveyTime] = useState('');
  const [focusedBid, setFocusedBid] = useState<Bid | null>(null);
  const [copiedState, setCopiedState] = useState(false);
  const [editingCloseBidDateId, setEditingCloseBidDateId] = useState<string | null>(null);
  const [tempCloseBidDate, setTempCloseBidDate] = useState('');

  // Manual Bid Input State
  const [showAddBidModal, setShowAddBidModal] = useState(false);
  const [manualBidName, setManualBidName] = useState('');
  const [manualBidPrice, setManualBidPrice] = useState<number | ''>('');
  const [manualBidContact, setManualBidContact] = useState('');
  const [manualBidEmail, setManualBidEmail] = useState('');
  const [manualBidDate, setManualBidDate] = useState(new Date().toISOString().split('T')[0]);
  const [manualBidTime, setManualBidTime] = useState(new Date().toTimeString().slice(0, 5));
  const [manualBidSurveyDate, setManualBidSurveyDate] = useState('');
  const [manualBidSurveyTime, setManualBidSurveyTime] = useState('09:00');
  const [manualBidError, setManualBidError] = useState('');

  const formatBidTimestamp = (timestamp?: string) => {
    if (!timestamp) return '-';
    try {
      const d = new Date(timestamp);
      if (isNaN(d.getTime())) return timestamp;
      return d.toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      }) + ', ' + d.toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit'
      }) + ' WIB';
    } catch {
      return timestamp;
    }
  };

  const formatBidTimestampDetail = (timestamp?: string) => {
    if (!timestamp) return { dateStr: '-', timeStr: '-' };
    try {
      const d = new Date(timestamp);
      if (isNaN(d.getTime())) return { dateStr: timestamp, timeStr: '-' };
      const dateStr = d.toLocaleDateString('id-ID', {
        weekday: 'long',
        day: '2-digit',
        month: 'long',
        year: 'numeric'
      });
      const timeStr = d.toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      }) + ' WIB';
      return { dateStr, timeStr };
    } catch {
      return { dateStr: timestamp, timeStr: '-' };
    }
  };



  // States for fullscreen image lightbox
  const [lightboxImages, setLightboxImages] = useState<string[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [isZoomed, setIsZoomed] = useState(false);

  useEffect(() => {
    setIsZoomed(false);
  }, [lightboxIndex]);

  useEffect(() => {
    setDetailImageIdx(0);
  }, [selectedAssetId]);

  const handleAddNewBrand = async () => {
    const trimmed = newBrandName.trim();
    if (!trimmed) {
      setBrandError(t('Nama merek tidak boleh kosong.'));
      return;
    }
    
    // Check duplication (case-insensitive)
    const duplicate = brands.some(b => b.name.toLowerCase() === trimmed.toLowerCase());
    if (duplicate) {
      setBrandError(t('Merek tersebut sudah terdaftar.'));
      return;
    }

    try {
      const brandId = trimmed.toLowerCase().replace(/\s+/g, '-');
      await addBrandToDb({
        id: brandId,
        name: trimmed,
        createdAt: new Date().toISOString()
      });
      setNewBrandName('');
      setBrandError('');
    } catch (err) {
      console.error("Failed to add brand", err);
      setBrandError(t('Gagal menambahkan merek.'));
    }
  };

  const handleDeleteBrand = async (brandId: string) => {
    try {
      await deleteBrandFromDb(brandId);
    } catch (err) {
      console.error("Failed to delete brand", err);
    }
  };

  const handleAddNewCategory = async () => {
    const trimmed = newCategoryName.trim();
    if (!trimmed) {
      setCategoryError(t('Nama kategori tidak boleh kosong.'));
      return;
    }
    
    // Check duplication (case-insensitive)
    const duplicate = categories.some(c => c.name.toLowerCase() === trimmed.toLowerCase());
    if (duplicate) {
      setCategoryError(t('Kategori tersebut sudah terdaftar.'));
      return;
    }

    try {
      const catId = trimmed.toLowerCase().replace(/\s+/g, '-');
      await addCategoryToDb({
        id: catId,
        name: trimmed,
        createdAt: new Date().toISOString()
      });
      setNewCategoryName('');
      setCategoryError('');
    } catch (err) {
      console.error("Failed to add category", err);
      setCategoryError(t('Gagal menambahkan kategori.'));
    }
  };

  const handleDeleteCategory = async (catId: string) => {
    try {
      await deleteCategoryFromDb(catId);
    } catch (err) {
      console.error("Failed to delete category", err);
    }
  };

  const handleAddNewCondition = async () => {
    const trimmed = newConditionName.trim();
    if (!trimmed) {
      setConditionError(t('Nama kondisi tidak boleh kosong.'));
      return;
    }
    
    // Check duplication (case-insensitive)
    const duplicate = conditions.some(c => c.name.toLowerCase() === trimmed.toLowerCase());
    if (duplicate) {
      setConditionError(t('Kondisi tersebut sudah terdaftar.'));
      return;
    }

    try {
      const condId = trimmed.toLowerCase().replace(/\s+/g, '-');
      await addConditionToDb({
        id: condId,
        name: trimmed,
        createdAt: new Date().toISOString()
      });
      setNewConditionName('');
      setConditionError('');
    } catch (err) {
      console.error("Failed to add condition", err);
      setConditionError(t('Gagal menambahkan kondisi.'));
    }
  };

  const handleDeleteCondition = async (condId: string) => {
    try {
      await deleteConditionFromDb(condId);
    } catch (err) {
      console.error("Failed to delete condition", err);
    }
  };

  const handleAddNewSeries = async () => {
    const trimmed = newSeriesName.trim();
    if (!trimmed) {
      setSeriesError(t('Nama seri tidak boleh kosong.'));
      return;
    }
    const duplicate = seriesList.some(s => s.name.toLowerCase() === trimmed.toLowerCase());
    if (duplicate) {
      setSeriesError(t('Seri tersebut sudah terdaftar.'));
      return;
    }
    try {
      const sId = trimmed.toLowerCase().replace(/\s+/g, '-');
      await addSeriesToDb({
        id: sId,
        name: trimmed,
        createdAt: new Date().toISOString()
      });
      setNewSeriesName('');
      setSeriesError('');
    } catch (err) {
      console.error("Failed to add series", err);
      setSeriesError(t('Gagal menambahkan seri.'));
    }
  };

  const handleDeleteSeries = async (sId: string) => {
    try {
      await deleteSeriesFromDb(sId);
    } catch (err) {
      console.error("Failed to delete series", err);
    }
  };

  const handleAddNewColour = async () => {
    const trimmed = newColourName.trim();
    if (!trimmed) {
      setColourError(t('Warna tidak boleh kosong.'));
      return;
    }
    const duplicate = vehicleColours.some(c => c.name.toLowerCase() === trimmed.toLowerCase());
    if (duplicate) {
      setColourError(t('Warna tersebut sudah terdaftar.'));
      return;
    }
    try {
      const cId = trimmed.toLowerCase().replace(/\s+/g, '-');
      await addVehicleColourToDb({
        id: cId,
        name: trimmed,
        createdAt: new Date().toISOString()
      });
      setNewColourName('');
      setColourError('');
    } catch (err) {
      console.error("Failed to add colour", err);
      setColourError(t('Gagal menambahkan warna.'));
    }
  };

  const handleDeleteColour = async (cId: string) => {
    try {
      await deleteVehicleColourFromDb(cId);
    } catch (err) {
      console.error("Failed to delete colour", err);
    }
  };

  const handleAddNewFuel = async () => {
    const trimmed = newFuelName.trim();
    if (!trimmed) {
      setFuelError(t('Bahan bakar tidak boleh kosong.'));
      return;
    }
    const duplicate = fuelTypes.some(f => f.name.toLowerCase() === trimmed.toLowerCase());
    if (duplicate) {
      setFuelError(t('Bahan bakar tersebut sudah terdaftar.'));
      return;
    }
    try {
      const fId = trimmed.toLowerCase().replace(/\s+/g, '-');
      await addFuelTypeToDb({
        id: fId,
        name: trimmed,
        createdAt: new Date().toISOString()
      });
      setNewFuelName('');
      setFuelError('');
    } catch (err) {
      console.error("Failed to add fuel type", err);
      setFuelError(t('Gagal menambahkan bahan bakar.'));
    }
  };

  const handleDeleteFuel = async (fId: string) => {
    try {
      await deleteFuelTypeFromDb(fId);
    } catch (err) {
      console.error("Failed to delete fuel type", err);
    }
  };

  const handleAddNewAttachment = async () => {
    const trimmed = newAttachmentName.trim();
    if (!trimmed) {
      setAttachmentError(t('Nama jenis gandengan tidak boleh kosong.'));
      return;
    }
    const duplicate = attachmentCategories.some(a => a.name.toLowerCase() === trimmed.toLowerCase());
    if (duplicate) {
      setAttachmentError(t('Jenis gandengan tersebut sudah terdaftar.'));
      return;
    }
    try {
      const aId = trimmed.toLowerCase().replace(/\s+/g, '-');
      await addAttachmentCategoryToDb({
        id: aId,
        name: trimmed,
        createdAt: new Date().toISOString()
      });
      setNewAttachmentName('');
      setAttachmentError('');
    } catch (err) {
      console.error("Failed to add attachment category", err);
      setAttachmentError(t('Gagal menambahkan jenis gandengan.'));
    }
  };

  const handleDeleteAttachment = async (aId: string) => {
    try {
      await deleteAttachmentCategoryFromDb(aId);
    } catch (err) {
      console.error("Failed to delete attachment category", err);
    }
  };

  const handleAddNewAttachmentType = async () => {
    const trimmed = newAttachmentTypeName.trim();
    if (!trimmed) {
      setAttachmentTypeError(t('Tipe gandengan tidak boleh kosong.'));
      return;
    }
    const duplicate = attachmentTypes.some(at => at.name.toLowerCase() === trimmed.toLowerCase());
    if (duplicate) {
      setAttachmentTypeError(t('Tipe gandengan tersebut sudah terdaftar.'));
      return;
    }
    try {
      const atId = trimmed.toLowerCase().replace(/\s+/g, '-');
      await addAttachmentTypeToDb({
        id: atId,
        name: trimmed,
        createdAt: new Date().toISOString()
      });
      setNewAttachmentTypeName('');
      setAttachmentTypeError('');
    } catch (err) {
      console.error("Failed to add attachment type", err);
      setAttachmentTypeError(t('Gagal menambahkan tipe gandengan.'));
    }
  };

  const handleDeleteAttachmentType = async (atId: string) => {
    try {
      await deleteAttachmentTypeFromDb(atId);
    } catch (err) {
      console.error("Failed to delete attachment type", err);
    }
  };

  const handleAddNewManifest = () => {
    const trimmed = newManifestName.trim();
    if (!trimmed) {
      setManifestError(t('Nama status manifest tidak boleh kosong.'));
      return;
    }
    if (manifestOptions.some(m => m.toLowerCase() === trimmed.toLowerCase())) {
      setManifestError(t('Status manifest tersebut sudah terdaftar.'));
      return;
    }
    const updated = [...manifestOptions, trimmed];
    setManifestOptions(updated);
    try {
      localStorage.setItem('pancaran_manifest_options', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
    setNewManifestName('');
    setManifestError('');
  };

  const handleDeleteManifest = (manifestText: string) => {
    if (manifestOptions.length <= 1) {
      setManifestError(t('Minimal harus ada 1 pilihan status manifest.'));
      return;
    }
    const updated = manifestOptions.filter(m => m !== manifestText);
    setManifestOptions(updated);
    try {
      localStorage.setItem('pancaran_manifest_options', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddNewUsedPartSubCat = () => {
    const trimmed = newUsedPartSubCatName.trim();
    if (!trimmed) {
      setUsedPartSubCatError(t('Nama sub-kategori tidak boleh kosong.'));
      return;
    }
    if (usedPartSubCats.some(sc => sc.toLowerCase() === trimmed.toLowerCase())) {
      setUsedPartSubCatError(t('Sub-kategori tersebut sudah terdaftar.'));
      return;
    }
    const updated = [...usedPartSubCats, trimmed];
    setUsedPartSubCats(updated);
    try {
      localStorage.setItem('pancaran_usedpart_subcategories', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
    setNewUsedPartSubCatName('');
    setUsedPartSubCatError('');
  };

  const handleDeleteUsedPartSubCat = (catText: string) => {
    if (usedPartSubCats.length <= 1) {
      setUsedPartSubCatError(t('Minimal harus ada 1 pilihan sub-kategori.'));
      return;
    }
    const updated = usedPartSubCats.filter(sc => sc !== catText);
    setUsedPartSubCats(updated);
    try {
      localStorage.setItem('pancaran_usedpart_subcategories', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  // Sales System Handlers
  const handleAddNewSalesSystem = () => {
    const trimmed = newSalesSystemName.trim();
    if (!trimmed) {
      setSalesSystemError(t('Nama sistem penjualan tidak boleh kosong.'));
      return;
    }
    if (salesSystemOptions.some(s => s.toLowerCase() === trimmed.toLowerCase())) {
      setSalesSystemError(t('Pilihan tersebut sudah terdaftar.'));
      return;
    }
    const updated = [...salesSystemOptions, trimmed];
    setSalesSystemOptions(updated);
    try {
      localStorage.setItem('pancaran_usedpart_sales_systems', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
    setNewSalesSystemName('');
    setSalesSystemError('');
  };

  const handleDeleteSalesSystem = (itemText: string) => {
    if (salesSystemOptions.length <= 1) {
      setSalesSystemError(t('Minimal harus ada 1 pilihan.'));
      return;
    }
    const updated = salesSystemOptions.filter(s => s !== itemText);
    setSalesSystemOptions(updated);
    try {
      localStorage.setItem('pancaran_usedpart_sales_systems', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  // Tire Type Handlers
  const handleAddNewTireType = () => {
    const trimmed = newTireTypeName.trim();
    if (!trimmed) {
      setTireTypeError(t('Nama jenis ban tidak boleh kosong.'));
      return;
    }
    if (tireTypeOptions.some(s => s.toLowerCase() === trimmed.toLowerCase())) {
      setTireTypeError(t('Pilihan tersebut sudah terdaftar.'));
      return;
    }
    const updated = [...tireTypeOptions, trimmed];
    setTireTypeOptions(updated);
    try {
      localStorage.setItem('pancaran_usedpart_tire_types', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
    setNewTireTypeName('');
    setTireTypeError('');
  };

  const handleDeleteTireType = (itemText: string) => {
    if (tireTypeOptions.length <= 1) {
      setTireTypeError(t('Minimal harus ada 1 pilihan.'));
      return;
    }
    const updated = tireTypeOptions.filter(s => s !== itemText);
    setTireTypeOptions(updated);
    try {
      localStorage.setItem('pancaran_usedpart_tire_types', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  // Tire Rim Handlers
  const handleAddNewTireRim = () => {
    const trimmed = newTireRimName.trim();
    if (!trimmed) {
      setTireRimError(t('Nama jenis velg tidak boleh kosong.'));
      return;
    }
    if (tireRimOptions.some(s => s.toLowerCase() === trimmed.toLowerCase())) {
      setTireRimError(t('Pilihan tersebut sudah terdaftar.'));
      return;
    }
    const updated = [...tireRimOptions, trimmed];
    setTireRimOptions(updated);
    try {
      localStorage.setItem('pancaran_usedpart_tire_rim_types', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
    setNewTireRimName('');
    setTireRimError('');
  };

  const handleDeleteTireRim = (itemText: string) => {
    if (tireRimOptions.length <= 1) {
      setTireRimError(t('Minimal harus ada 1 pilihan.'));
      return;
    }
    const updated = tireRimOptions.filter(s => s !== itemText);
    setTireRimOptions(updated);
    try {
      localStorage.setItem('pancaran_usedpart_tire_rim_types', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  // Tire Grade Handlers
  const handleAddNewTireGrade = () => {
    const trimmed = newTireGradeName.trim();
    if (!trimmed) {
      setTireGradeError(t('Grade ban tidak boleh kosong.'));
      return;
    }
    if (tireGradeOptions.some(s => s.toLowerCase() === trimmed.toLowerCase())) {
      setTireGradeError(t('Pilihan tersebut sudah terdaftar.'));
      return;
    }
    const updated = [...tireGradeOptions, trimmed];
    setTireGradeOptions(updated);
    try {
      localStorage.setItem('pancaran_usedpart_tire_grades', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
    setNewTireGradeName('');
    setTireGradeError('');
  };

  const handleDeleteTireGrade = (itemText: string) => {
    if (tireGradeOptions.length <= 1) {
      setTireGradeError(t('Minimal harus ada 1 pilihan.'));
      return;
    }
    const updated = tireGradeOptions.filter(s => s !== itemText);
    setTireGradeOptions(updated);
    try {
      localStorage.setItem('pancaran_usedpart_tire_grades', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  // Metal Type Handlers
  const handleAddNewMetalType = () => {
    const trimmed = newMetalTypeName.trim();
    if (!trimmed) {
      setMetalTypeError(t('Jenis besi / logam tidak boleh kosong.'));
      return;
    }
    if (metalTypeOptions.some(s => s.toLowerCase() === trimmed.toLowerCase())) {
      setMetalTypeError(t('Pilihan tersebut sudah terdaftar.'));
      return;
    }
    const updated = [...metalTypeOptions, trimmed];
    setMetalTypeOptions(updated);
    try {
      localStorage.setItem('pancaran_usedpart_metal_types', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
    setNewMetalTypeName('');
    setMetalTypeError('');
  };

  const handleDeleteMetalType = (itemText: string) => {
    if (metalTypeOptions.length <= 1) {
      setMetalTypeError(t('Minimal harus ada 1 pilihan.'));
      return;
    }
    const updated = metalTypeOptions.filter(s => s !== itemText);
    setMetalTypeOptions(updated);
    try {
      localStorage.setItem('pancaran_usedpart_metal_types', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  // Metal Sales Method Handlers
  const handleAddNewMetalSalesMethod = () => {
    const trimmed = newMetalSalesMethodName.trim();
    if (!trimmed) {
      setMetalSalesMethodError(t('Metode penjualan tidak boleh kosong.'));
      return;
    }
    if (metalSalesMethodOptions.some(s => s.toLowerCase() === trimmed.toLowerCase())) {
      setMetalSalesMethodError(t('Pilihan tersebut sudah terdaftar.'));
      return;
    }
    const updated = [...metalSalesMethodOptions, trimmed];
    setMetalSalesMethodOptions(updated);
    try {
      localStorage.setItem('pancaran_usedpart_metal_sales_methods', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
    setNewMetalSalesMethodName('');
    setMetalSalesMethodError('');
  };

  const handleDeleteMetalSalesMethod = (itemText: string) => {
    if (metalSalesMethodOptions.length <= 1) {
      setMetalSalesMethodError(t('Minimal harus ada 1 pilihan.'));
      return;
    }
    const updated = metalSalesMethodOptions.filter(s => s !== itemText);
    setMetalSalesMethodOptions(updated);
    try {
      localStorage.setItem('pancaran_usedpart_metal_sales_methods', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setLightboxIndex(null);
      } else if (e.key === 'ArrowRight' && lightboxIndex !== null && lightboxImages.length > 1) {
        setLightboxIndex(prev => (prev === null ? null : (prev === lightboxImages.length - 1 ? 0 : prev + 1)));
      } else if (e.key === 'ArrowLeft' && lightboxIndex !== null && lightboxImages.length > 1) {
        setLightboxIndex(prev => (prev === null ? null : (prev === 0 ? lightboxImages.length - 1 : prev - 1)));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxIndex, lightboxImages]);

  const [formData, setFormData] = useState({
    name: '',
    brand: '',
    category: '',
    modelYear: 2022 as number | string,
    plateNumber: '',
    condition: 'Baik' as Asset['condition'],
    location: '',
    coordinates: '',
    description: '',
    startingPrice: '',
    manifestStatus: 'Tidak Pake Manifest' as 'Pake Manifest' | 'Tidak Pake Manifest',
    imageUrl: '',
    imageUrls: [] as string[],
    dimensions: '',
    propertyType: 'Gudang',
    auctionType: 'Jual',
    landArea: '',
    buildingArea: '',
    // Used Part fields
    usedPartCategory: 'Ban',
    usedPartCategories: ['Ban'] as string[],
    otherPartsNotes: '',
    quantity: '',
    salesSystem: 'Satuan',
    openHouseSchedule: '',
    tireBrand: '',
    tireSize: '',
    tireType: 'Ban Luar',
    tireRimType: '',
    tireTreadDepth: '',
    tireCondition: 'Masih Layak Pakai (Tubeless/Pakai Ban Dalam)',
    tireDotCode: '',
    batteryBrand: '',
    batteryTypeCode: '',
    batteryCapacity: '',
    batteryType: 'Aki Basah',
    batteryCondition: 'Masih Fungsi (Hanya Perlu Cas)',
    batteryElectrolyteStatus: 'Masih Terisi Air Aki',
    metalType: 'Besi Berat / H-Beam / I-Beam / Plate',
    metalSalesMethod: 'Penimbangan',
    metalEstimatedWeight: '',
    metalCondition: '',
    metalHandlingFacility: 'Pemenang Lelang wajib potong dan angkut sendiri',
    oilBrand: '',
    oilType: '',
    oilVolume: '',
    oilCondition: 'Baru (Dalam Kemasan Segel)',
    model: '',
    series: '',
    axels: '',
    vehicleColour: 'White',
    fuelType: 'Solar',
    horsepower: '',
    odometer: '',
    keurValidUntil: '',
    stnkPlateValidUntil: '',
    stnkTaxValidUntil: '',
    haveAttachment: false,
    attachmentCategory: 'Trailer',
    attachmentImageUrl: '',
    attachmentImageUrls: [] as string[],
    attachmentType: '',
    attachmentAxels: '',
    attachmentYearBuilt: '',
    attachmentKeurNo: '',
    attachmentValidUntil: '',
    attachmentLength: '',
    attachmentWidth: '',
    attachmentHeight: '',
    attachmentExtension: '',
    tnc: '',
    closeBidDate: '',
    usedPartItems: [
      { id: '1', type: '', qty: '', unitPrice: '', totalPrice: '' },
      { id: '2', type: '', qty: '', unitPrice: '', totalPrice: '' },
      { id: '3', type: '', qty: '', unitPrice: '', totalPrice: '' }
    ] as UsedPartItem[]
  });

  const handleUsedPartItemChange = (index: number, field: keyof UsedPartItem, value: string | number) => {
    setFormData(prev => {
      const items = [...(prev.usedPartItems || [])];
      if (!items[index]) return prev;
      const updated = { ...items[index], [field]: value };
      if (field === 'qty' || field === 'unitPrice') {
        const q = Number(String(field === 'qty' ? value : updated.qty || 0).replace(/\D/g, '')) || 0;
        const p = Number(String(field === 'unitPrice' ? value : updated.unitPrice || 0).replace(/\D/g, '')) || 0;
        updated.totalPrice = q * p;
      }
      items[index] = updated;
      return { ...prev, usedPartItems: items };
    });
  };

  const handleAddUsedPartItem = () => {
    setFormData(prev => {
      const items = [...(prev.usedPartItems || [])];
      items.push({
        id: String(Date.now()) + Math.random().toString(36).substr(2, 4),
        type: '',
        qty: '',
        unitPrice: '',
        totalPrice: ''
      });
      return { ...prev, usedPartItems: items };
    });
  };

  const handleRemoveUsedPartItem = (index: number) => {
    setFormData(prev => {
      const items = [...(prev.usedPartItems || [])];
      items.splice(index, 1);
      return { ...prev, usedPartItems: items.length > 0 ? items : [{ id: '1', type: '', qty: '', unitPrice: '', totalPrice: '' }] };
    });
  };

  const totalUsedPartsQty = (formData.usedPartItems || []).reduce((sum, it) => {
    const q = Number(String(it.qty || 0).replace(/\D/g, '')) || 0;
    return sum + q;
  }, 0);

  const totalUsedPartsPrice = (formData.usedPartItems || []).reduce((sum, it) => {
    const q = Number(String(it.qty || 0).replace(/\D/g, '')) || 0;
    const p = Number(String(it.unitPrice || 0).replace(/\D/g, '')) || 0;
    const rowT = typeof it.totalPrice === 'number' ? it.totalPrice : (q * p);
    return sum + rowT;
  }, 0);

  const isVehicle = normalizeCategory(formData.category) === 'Vehicle';
  const isUsedPart = normalizeCategory(formData.category) === 'Used part';
  const isProperty = normalizeCategory(formData.category) === 'Property';
  const isMisc = normalizeCategory(formData.category) === 'Miscellaneous';

  const handleToggleUsedPartSubCategory = (subCatId: string) => {
    setFormData(prev => {
      const currentCats = Array.isArray(prev.usedPartCategories)
        ? [...prev.usedPartCategories]
        : (prev.usedPartCategory ? prev.usedPartCategory.split(',').map(s => s.trim()).filter(Boolean) : []);
      
      let nextCats: string[];
      if (currentCats.includes(subCatId)) {
        nextCats = currentCats.filter(c => c !== subCatId);
      } else {
        nextCats = [...currentCats, subCatId];
      }
      return {
        ...prev,
        usedPartCategories: nextCats,
        usedPartCategory: nextCats.join(', ')
      };
    });
  };

  const handleUncheckAllUsedPartSubCategories = () => {
    setFormData(prev => ({
      ...prev,
      usedPartCategories: [],
      usedPartCategory: ''
    }));
  };

  const handleCheckAllUsedPartSubCategories = () => {
    setFormData(prev => ({
      ...prev,
      usedPartCategories: [...usedPartSubCats],
      usedPartCategory: usedPartSubCats.join(', ')
    }));
  };

  const isColVisible = (colKey: string) => {
    const hidden = formData.hiddenItemColumns || [];
    return !hidden.includes(colKey);
  };

  const handleToggleColumnVisibility = (colKey: string) => {
    setFormData(prev => {
      const currentHidden = prev.hiddenItemColumns || [];
      const nextHidden = currentHidden.includes(colKey)
        ? currentHidden.filter(c => c !== colKey)
        : [...currentHidden, colKey];
      return {
        ...prev,
        hiddenItemColumns: nextHidden
      };
    });
  };

  const handleResetAllColumns = () => {
    setFormData(prev => ({
      ...prev,
      hiddenItemColumns: []
    }));
  };

  const descriptionRef = React.useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isFormOpen && descriptionRef.current) {
      descriptionRef.current.style.height = 'auto';
      descriptionRef.current.style.height = `${Math.max(descriptionRef.current.scrollHeight, 100)}px`;
    }
  }, [formData.description, isFormOpen]);

  // Auto-sync starting price with Used Part items Grand Total
  useEffect(() => {
    if (isUsedPart && isFormOpen) {
      const nextPrice = String(totalUsedPartsPrice);
      if (formData.startingPrice !== nextPrice) {
        setFormData(prev => ({
          ...prev,
          startingPrice: nextPrice
        }));
      }
    }
  }, [isUsedPart, isFormOpen, totalUsedPartsPrice, formData.startingPrice]);

  const openNewAssetForm = () => {
    setEditAssetId(null);
    setFormData({
      name: '',
      brand: '',
      category: 'Vehicle',
      modelYear: 2022,
      plateNumber: '',
      condition: 'Baik',
      location: '',
      coordinates: '',
      description: '',
      startingPrice: '',
      manifestStatus: 'Tidak Pake Manifest',
      imageUrl: '',
      imageUrls: [],
      dimensions: '',
      propertyType: 'Gudang',
      auctionType: 'Jual',
      landArea: '',
      buildingArea: '',
      usedPartCategory: 'Ban',
      usedPartCategories: ['Ban'],
      otherPartsNotes: '',
      quantity: '',
      salesSystem: 'Satuan',
      openHouseSchedule: '',
      tireBrand: '',
      tireSize: '',
      tireType: 'Ban Luar',
      tireRimType: '',
      tireTreadDepth: '',
      tireCondition: 'Masih Layak Pakai (Tubeless/Pakai Ban Dalam)',
      tireDotCode: '',
      batteryBrand: '',
      batteryTypeCode: '',
      batteryCapacity: '',
      batteryType: 'Aki Basah',
      batteryCondition: 'Masih Fungsi (Hanya Perlu Cas)',
      batteryElectrolyteStatus: 'Masih Terisi Air Aki',
      metalType: 'Besi Berat / H-Beam / I-Beam / Plate',
      metalSalesMethod: 'Penimbangan',
      metalEstimatedWeight: '',
      metalCondition: '',
      metalHandlingFacility: 'Pemenang Lelang wajib potong dan angkut sendiri',
      oilBrand: '',
      oilType: '',
      oilVolume: '',
      oilCondition: 'Baru (Dalam Kemasan Segel)',
      model: '',
      series: '440',
      axels: '',
      vehicleColour: 'White',
      fuelType: 'Solar',
      horsepower: '',
      odometer: '',
      keurValidUntil: '',
      stnkPlateValidUntil: '',
      stnkTaxValidUntil: '',
      haveAttachment: false,
      attachmentCategory: 'Trailer',
      attachmentImageUrl: '',
      attachmentImageUrls: [],
      attachmentType: 'Highbed 40',
      attachmentAxels: '',
      attachmentYearBuilt: '',
      attachmentKeurNo: '',
      attachmentValidUntil: '',
      attachmentLength: '',
      attachmentWidth: '',
      attachmentHeight: '',
      attachmentExtension: '',
      tnc: '',
      closeBidDate: '',
      usedPartItems: [
        { id: '1', type: '', qty: '', unitPrice: '', totalPrice: '' },
        { id: '2', type: '', qty: '', unitPrice: '', totalPrice: '' },
        { id: '3', type: '', qty: '', unitPrice: '', totalPrice: '' }
      ]
    });
    setIsFormOpen(true);
  };

  const handleFillDummySparePart = () => {
    setEditAssetId(null);
    setFormData({
      name: 'Paket Lelang Suku Cadang & Ban Bekas Truk Tronton (Batch Pool Cakung 2026)',
      brand: '',
      category: 'Used part',
      modelYear: '',
      plateNumber: '',
      condition: 'Baik',
      location: 'Pool Cakung, Jakarta Timur',
      coordinates: '-6.1824,106.9421',
      description: 'Paket lelang limbah suku cadang dan ban bekas layak pakai/vulkanisir ex-armada logistik PT Pancaran. Terdiri dari ban luar ring 20, aki heavy duty, besi sasis UNP, plat kapal, besi siku, gasket mesin, dan filter udara. Seluruh unit tersimpan rapi di gudang sparepart Pool Cakung.',
      startingPrice: '49785000',
      imageUrl: '',
      imageUrls: [],
      dimensions: '',
      propertyType: 'Gudang',
      auctionType: 'Jual',
      landArea: '',
      buildingArea: '',
      usedPartCategory: 'Ban, Aki, Besi, Suku Cadang',
      usedPartCategories: ['Ban', 'Aki', 'Besi', 'Lainnya'],
      otherPartsNotes: '',
      quantity: '8 Jenis Item',
      salesSystem: 'Borongan',
      tireBrand: 'Bridgestone & Gajah Tunggal',
      tireSize: '10.00 - R20',
      tireType: 'Ban Luar & Dalam',
      tireTreadDepth: '1',
      tireCondition: 'Masih Layak Pakai',
      tireDotCode: 'DOT 2023/2024',
      batteryBrand: 'GS Astra',
      batteryTypeCode: 'N100 12V 100Ah',
      batteryCapacity: '100 Ah',
      batteryType: 'Aki Basah',
      batteryCondition: 'Masih Fungsi (Terisi Air Aki)',
      batteryElectrolyteStatus: 'Masih Terisi Air Aki',
      metalType: 'Besi UNP / Plat Kapal / Besi Siku',
      metalSalesMethod: 'Borongan',
      metalEstimatedWeight: '',
      metalCondition: '',
      metalHandlingFacility: 'Pemenang Lelang wajib potong dan angkut sendiri',
      oilBrand: '',
      oilType: '',
      oilVolume: '',
      oilCondition: 'Baru (Dalam Kemasan Segel)',
      model: 'Paket Suku Cadang, Ban R20, Aki 100Ah, & Besi Sasis',
      series: '',
      axels: '',
      vehicleColour: '',
      fuelType: '',
      horsepower: '',
      odometer: '',
      keurValidUntil: '',
      stnkPlateValidUntil: '',
      stnkTaxValidUntil: '',
      haveAttachment: false,
      attachmentCategory: 'Trailer',
      attachmentImageUrl: '',
      attachmentImageUrls: [],
      attachmentType: '',
      attachmentAxels: '',
      attachmentYearBuilt: '',
      attachmentKeurNo: '',
      attachmentValidUntil: '',
      attachmentLength: '',
      attachmentWidth: '',
      attachmentHeight: '',
      attachmentExtension: '',
      tnc: '1. Penjualan paket limbah suku cadang dan ban bekas bersifat "as-is" (apa adanya).\n2. Pengambilan barang wajib menggunakan armada pengangkut sendiri maksimal 3 hari kerja setelah pelunasan.\n3. Pemenang lelang wajib mematuhi K3 dan aturan keselamatan di area Pool Cakung.',
      closeBidDate: '',
      useItemTableMode: true,
      usedPartItems: [
        { id: '1', type: 'Ban Outer Truck', name: 'Ban Outer Truck', spec: 'Bridgestone Mixtech M729 10.00 - R20 16PR', qty: 6, uom: 'Pcs', unitPrice: 3850000, totalPrice: 23100000, notes: 'Kondisi baru 95%' },
        { id: '2', type: 'Ban Dalam & Flap Truck', name: 'Ban Dalam & Flap Truck', spec: 'Gajah Tunggal Inner Tube & Flap 10.00 - 20', qty: 6, uom: 'Set', unitPrice: 350000, totalPrice: 2100000, notes: 'Masih terbungkus rapat' },
        { id: '3', type: 'Aki Truck Heavy Duty', name: 'Aki Truck Heavy Duty', spec: 'GS Astra N100 / 95E41R (100 Ah, 12V)', qty: 4, uom: 'Pcs', unitPrice: 1650000, totalPrice: 6600000, notes: 'Siap pakai & terisi air' },
        { id: '4', type: 'Besi UNP (Channel Steel)', name: 'Besi UNP (Channel Steel)', spec: 'UNP 120 x 55 x 7 mm x 6 Meter (Sasis/Bak Truck)', qty: 10, uom: 'Batang', unitPrice: 480000, totalPrice: 4800000, notes: 'Bebas karat berat' },
        { id: '5', type: 'Besi Plat Kapal / Hitam', name: 'Besi Plat Kapal / Hitam', spec: 'Tebal 3 mm (4 x 8 Feet) (Lantai Bak Truck)', qty: 5, uom: 'Lembar', unitPrice: 1250000, totalPrice: 6250000, notes: 'Lembaran utuh' },
        { id: '6', type: 'Besi Siku (Angle Bar)', name: 'Besi Siku (Angle Bar)', spec: '50 x 50 x 5 mm x 6 Meter (Rangka Pagar Bak)', qty: 15, uom: 'Batang', unitPrice: 185000, totalPrice: 2775000, notes: 'Panjang standar 6m' },
        { id: '7', type: 'Oli Gasket Mesin Truck', name: 'Oli Gasket Mesin Truck', spec: 'Gasket Set Mesin Perkins 1104', qty: 2, uom: 'Set', unitPrice: 980000, totalPrice: 1960000, notes: 'Segel pabrik' },
        { id: '8', type: 'Filter Udara Truck', name: 'Filter Udara Truck', spec: 'Baldwin RS4621 Outer Filter', qty: 4, uom: 'Pcs', unitPrice: 550000, totalPrice: 2200000, notes: 'Original part' }
      ]
    });
    setIsFormOpen(true);
  };

  const handleEditClick = (asset: Asset) => {
    onSelectAsset(null);
    setEditAssetId(asset.id);
    const resolvedUrls = asset.imageUrls && asset.imageUrls.length > 0 
      ? asset.imageUrls 
      : (asset.imageUrl ? [asset.imageUrl] : []);
    
    const initialUsedPartItems = asset.usedPartItems && asset.usedPartItems.length > 0
      ? asset.usedPartItems.map((item, idx) => ({
          id: item.id || String(idx + 1),
          type: item.type || item.name || '',
          name: item.name || item.type || '',
          spec: item.spec || '',
          qty: item.qty ?? '',
          uom: item.uom ?? '',
          unitPrice: item.unitPrice ?? '',
          totalPrice: item.totalPrice ?? (Number(item.qty || 0) * Number(item.unitPrice || 0)) ?? '',
          notes: item.notes || ''
        }))
      : [
          { id: '1', type: '', name: '', spec: '', qty: '', uom: '', unitPrice: '', totalPrice: '', notes: '' },
          { id: '2', type: '', name: '', spec: '', qty: '', uom: '', unitPrice: '', totalPrice: '', notes: '' },
          { id: '3', type: '', name: '', spec: '', qty: '', uom: '', unitPrice: '', totalPrice: '', notes: '' }
        ];

    const initialUsedPartCategories = asset.usedPartCategories && asset.usedPartCategories.length > 0
      ? asset.usedPartCategories
      : (asset.usedPartCategory ? asset.usedPartCategory.split(',').map(s => s.trim()).filter(Boolean) : ['Ban']);

    const normCat = normalizeCategory(asset.category);
    const cleanName = getCleanAssetName(asset);
    const cleanBrand = normCat === 'Vehicle' ? (asset.brand || 'Hino') : '';
    setFormData({
      name: cleanName,
      model: cleanName,
      brand: cleanBrand,
      category: normCat,
      modelYear: asset.modelYear,
      plateNumber: asset.plateNumber === 'N/A' ? '' : asset.plateNumber,
      condition: asset.condition,
      location: asset.location,
      coordinates: asset.coordinates || '',
      description: asset.description,
      startingPrice: String(asset.startingPrice),
      manifestStatus: asset.manifestStatus || 'Tidak Pake Manifest',
      imageUrl: asset.imageUrl || (resolvedUrls[0] || ''),
      imageUrls: resolvedUrls,
      dimensions: asset.dimensions || '',
      propertyType: asset.propertyType || 'Gudang',
      auctionType: asset.auctionType || 'Jual',
      landArea: asset.landArea || '',
      buildingArea: asset.buildingArea || '',
      usedPartCategory: asset.usedPartCategory || initialUsedPartCategories.join(', ') || 'Ban',
      usedPartCategories: initialUsedPartCategories,
      otherPartsNotes: asset.otherPartsNotes || '',
      quantity: asset.quantity || '',
      salesSystem: asset.salesSystem || 'Satuan',
      openHouseSchedule: asset.openHouseSchedule || '',
      tireBrand: asset.tireBrand || '',
      tireSize: asset.tireSize || '',
      tireType: asset.tireType || 'Ban Luar',
      tireRimType: asset.tireRimType || '',
      tireTreadDepth: ['1', '2', '3'].includes(asset.tireTreadDepth || '') ? asset.tireTreadDepth : (asset.tireTreadDepth ? '1' : ''),
      tireCondition: asset.tireCondition || 'Masih Layak Pakai (Tubeless/Pakai Ban Dalam)',
      tireDotCode: asset.tireDotCode || '',
      batteryBrand: asset.batteryBrand || '',
      batteryTypeCode: asset.batteryTypeCode || '',
      batteryCapacity: asset.batteryCapacity || '',
      batteryType: asset.batteryType || 'Aki Basah',
      batteryCondition: asset.batteryCondition || 'Masih Fungsi (Hanya Perlu Cas)',
      batteryElectrolyteStatus: asset.batteryElectrolyteStatus || 'Masih Terisi Air Aki',
      metalType: asset.metalType || 'Besi Berat / H-Beam / I-Beam / Plate',
      metalSalesMethod: asset.metalSalesMethod || 'Penimbangan',
      metalEstimatedWeight: asset.metalEstimatedWeight || '',
      metalCondition: asset.metalCondition || '',
      metalHandlingFacility: asset.metalHandlingFacility || 'Pemenang Lelang wajib potong dan angkut sendiri',
      oilBrand: asset.oilBrand || '',
      oilType: asset.oilType || '',
      oilVolume: asset.oilVolume || '',
      oilCondition: asset.oilCondition || 'Baru (Dalam Kemasan Segel)',
      series: asset.series || '440',
      axels: asset.axels || '',
      vehicleColour: asset.vehicleColour || 'White',
      fuelType: asset.fuelType || 'Solar',
      horsepower: asset.horsepower || '',
      odometer: asset.odometer || '',
      keurValidUntil: asset.keurValidUntil || '',
      stnkPlateValidUntil: asset.stnkPlateValidUntil || '',
      stnkTaxValidUntil: asset.stnkTaxValidUntil || '',
      haveAttachment: !!asset.haveAttachment,
      attachmentCategory: asset.attachmentCategory || 'Trailer',
      attachmentImageUrl: asset.attachmentImageUrl || '',
      attachmentImageUrls: asset.attachmentImageUrls || [],
      attachmentType: asset.attachmentType || 'Highbed 40',
      attachmentAxels: asset.attachmentAxels || '',
      attachmentYearBuilt: asset.attachmentYearBuilt || '',
      attachmentKeurNo: asset.attachmentKeurNo || '',
      attachmentValidUntil: asset.attachmentValidUntil || '',
      attachmentLength: asset.attachmentLength || '',
      attachmentWidth: asset.attachmentWidth || '',
      attachmentHeight: asset.attachmentHeight || '',
      attachmentExtension: asset.attachmentExtension || '',
      tnc: asset.tnc || '',
      closeBidDate: asset.closeBidDate || '',
      usedPartItems: initialUsedPartItems
    });
    setIsFormOpen(true);
  };

  const handleFilesChange = async (files: FileList | File[]) => {
    if (!files || files.length === 0) return;
    
    const newImageUrls: string[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!file.type.startsWith('image/')) {
        alert('Hanya file gambar yang diperbolehkan.');
        continue;
      }
      
      try {
        const compressedBase64 = await compressImage(file, 800, 600, 0.75);
        newImageUrls.push(compressedBase64);
      } catch (err) {
        console.error('Gagal mengompresi gambar:', err);
        // Fallback
        const readerStr = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target?.result as string || '');
          reader.readAsDataURL(file);
        });
        if (readerStr) {
          newImageUrls.push(readerStr);
        }
      }
    }

    if (newImageUrls.length > 0) {
      setFormData(prev => {
        const currentUrls = prev.imageUrls || [];
        const merged = [...currentUrls, ...newImageUrls];
        return {
          ...prev,
          imageUrls: merged,
          imageUrl: merged[0] || prev.imageUrl
        };
      });
    }
  };

  const handleAttachmentFilesChange = async (files: FileList | File[]) => {
    if (!files || files.length === 0) return;
    
    const newImageUrls: string[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!file.type.startsWith('image/')) {
        alert('Hanya file gambar yang diperbolehkan.');
        continue;
      }
      
      try {
        const compressedBase64 = await compressImage(file, 800, 600, 0.75);
        newImageUrls.push(compressedBase64);
      } catch (err) {
        console.error('Gagal mengompresi gambar:', err);
        const readerStr = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target?.result as string || '');
          reader.readAsDataURL(file);
        });
        if (readerStr) {
          newImageUrls.push(readerStr);
        }
      }
    }

    if (newImageUrls.length > 0) {
      setFormData(prev => {
        const currentUrls = prev.attachmentImageUrls || [];
        const merged = [...currentUrls, ...newImageUrls];
        return {
          ...prev,
          attachmentImageUrls: merged,
          attachmentImageUrl: merged[0] || prev.attachmentImageUrl
        };
      });
    }
  };

  const selectedAsset = assets.find(a => a.id === selectedAssetId);

  // Filter logic (sorted so newest posted is at the top)
  const filteredAssets = sortAssetsByNewest(assets.filter(asset => {
    const matchesTab = activeTab === 'all' 
      ? true 
      : activeTab === 'Sold' 
        ? asset.status === 'Sold' && asset.bids && asset.bids.length > 0 
        : asset.status === 'Open' || !asset.bids || asset.bids.length === 0;
    const matchesBrand = brandFilter === 'all' || asset.brand === brandFilter;
    const matchesCategory = categoryFilter === 'all' || asset.category === categoryFilter;
    const matchesCondition = conditionFilter === 'all' || asset.condition === conditionFilter;
    const matchesManifest = manifestFilter === 'all' || 
      (asset.manifestStatus === manifestFilter) || 
      (manifestFilter === 'Tidak Pake Manifest' && (!asset.manifestStatus || asset.manifestStatus === 'Tidak Pake Manifest'));
    const matchesSearch = 
      asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.plateNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.brand.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesTab && matchesBrand && matchesCategory && matchesCondition && matchesManifest && matchesSearch;
  }));

  // Master brands list to display in filter options and forms
  const displayBrandsList = brands.length > 0
    ? brands.map(b => b.name)
    : Array.from(new Set(['Hino', 'Isuzu', 'Fuso', 'Scania', 'Toyota', 'Caterpillar', 'Komatsu', 'Lainnya', ...assets.map(a => a.brand)]));

  // Master categories list to display in forms
  const displayCategoriesList = categories.length > 0
    ? Array.from(new Set([...categories.map(c => c.name), ...MAIN_CATEGORIES]))
    : [...MAIN_CATEGORIES];

  // Master conditions list to display in forms
  const displayConditionsList = conditions.length > 0
    ? conditions.map(c => c.name)
    : Array.from(new Set(['Sangat Baik', 'Baik', 'Cukup', 'Butuh Perbaikan', ...assets.map(a => a.condition)]));

  // Master series list to display in forms and filters
  const displaySeriesList = seriesList.length > 0
    ? seriesList.map(s => s.name)
    : Array.from(new Set(['440', '500', '320', '260', 'FL 260', 'GIGA', 'Lainnya', ...assets.map(a => a.series).filter((x): x is string => !!x)]));

  // Master colours list to display in forms and filters
  const displayColoursList = vehicleColours.length > 0
    ? vehicleColours.map(c => c.name)
    : Array.from(new Set(['White', 'Yellow', 'Red', 'Blue', 'Green', 'Grey', 'Black', 'Lainnya', ...assets.map(a => a.vehicleColour).filter((x): x is string => !!x)]));

  // Master fuel list to display in forms and filters
  const displayFuelsList = fuelTypes.length > 0
    ? fuelTypes.map(f => f.name)
    : Array.from(new Set(['Solar', 'Diesel', 'Bensin', 'Listrik', ...assets.map(a => a.fuelType).filter((x): x is string => !!x)]));

  // Master attachment category list to display in forms and filters
  const displayAttachmentCategoriesList = attachmentCategories.length > 0
    ? attachmentCategories.map(ac => ac.name)
    : Array.from(new Set(['Trailer', 'Box', 'Dump Body', 'Flatbed', 'Lainnya', ...assets.map(a => a.attachmentCategory).filter((x): x is string => !!x)]));

  // Master attachment type list to display in forms and filters
  const displayAttachmentTypesList = attachmentTypes.length > 0
    ? attachmentTypes.map(at => at.name)
    : Array.from(new Set(['Highbed 40', 'Highbed 20', 'Flatbed 40', 'Flatbed 20', 'Skeleton 40', 'Skeleton 20', 'Lowbed', 'Dolly', 'Lainnya', ...assets.map(a => a.attachmentType).filter((x): x is string => !!x)]));

  // Unique brands for filter
  const uniqueBrands = displayBrandsList;

  const handleTemplateClick = (template: typeof VEHICLE_TEMPLATES[0]) => {
    setFormData(prev => ({
      ...prev,
      name: `${template.name} - New`,
      brand: template.brand,
      category: template.category,
      imageUrl: template.url,
      imageUrls: [template.url]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Get final asset name and clean brand
    const normCategory = normalizeCategory(formData.category);
    const isCategoryUsedPart = normCategory === 'Used part';
    const isCategoryProperty = normCategory === 'Property';
    const isCategoryMisc = normCategory === 'Miscellaneous';

    const trimmedModel = (formData.model || '').trim();
    const trimmedBrand = (formData.brand || '').trim();

    let cleanBrand = '';
    let finalName = '';

    if (isCategoryUsedPart || isCategoryProperty || isCategoryMisc) {
      cleanBrand = '';
      finalName = (formData.name && formData.name.trim()) || trimmedModel || formData.category || 'Unit Lelang';
      finalName = finalName.replace(/^(Hino|Isuzu|Fuso|Scania|Toyota|Caterpillar|Komatsu)\s+/i, '').trim() || finalName;
    } else {
      cleanBrand = trimmedBrand || 'Hino';
      if (trimmedModel) {
        if (cleanBrand && cleanBrand !== 'Lainnya' && cleanBrand !== 'Tanpa Merek' && !trimmedModel.toLowerCase().includes(cleanBrand.toLowerCase())) {
          finalName = `${cleanBrand} ${trimmedModel}`;
        } else {
          finalName = trimmedModel;
        }
      } else if (formData.name && formData.name.trim()) {
        finalName = formData.name.trim();
      } else if (cleanBrand && cleanBrand !== 'Lainnya') {
        finalName = cleanBrand;
      } else {
        finalName = formData.category || 'Unit Lelang';
      }
    }

    if (!finalName || !formData.startingPrice || !formData.location || !formData.category) {
      alert(t('Mohon lengkapi data harga awal, lokasi, dan kategori.'));
      return;
    }

    const resolvedUrls = formData.imageUrls && formData.imageUrls.length > 0
      ? formData.imageUrls
      : (formData.imageUrl ? [formData.imageUrl] : []);

    const assetData = {
      name: finalName,
      brand: cleanBrand,
      category: formData.category,
      modelYear: isNaN(Number(formData.modelYear)) || String(formData.modelYear).trim() === '' ? formData.modelYear : Number(formData.modelYear),
      plateNumber: formData.plateNumber || 'N/A',
      condition: formData.condition,
      location: formData.location,
      coordinates: formData.coordinates || '',
      description: formData.description || 'Tidak ada deskripsi tambahan.',
      startingPrice: Number(formData.startingPrice),
      manifestStatus: formData.manifestStatus || 'Tidak Pake Manifest',
      imageUrl: formData.imageUrl || (resolvedUrls[0] || ''),
      imageUrls: resolvedUrls,
      dimensions: formData.dimensions || '',
      propertyType: formData.propertyType || '',
      auctionType: formData.auctionType || '',
      landArea: formData.landArea || '',
      buildingArea: formData.buildingArea || '',
      usedPartCategory: (formData.usedPartCategories && formData.usedPartCategories.length > 0)
        ? formData.usedPartCategories.join(', ')
        : (formData.usedPartCategory || ''),
      usedPartCategories: (formData.usedPartCategories && formData.usedPartCategories.length > 0)
        ? formData.usedPartCategories
        : (formData.usedPartCategory ? formData.usedPartCategory.split(',').map(s => s.trim()).filter(Boolean) : []),
      otherPartsNotes: formData.otherPartsNotes || '',
      quantity: formData.quantity || '',
      salesSystem: formData.salesSystem || '',
      openHouseSchedule: formData.openHouseSchedule || '',
      tireBrand: formData.tireBrand || '',
      tireSize: formData.tireSize || '',
      tireType: formData.tireType || '',
      tireRimType: formData.tireRimType || '',
      tireTreadDepth: formData.tireTreadDepth || '',
      tireCondition: formData.tireCondition || '',
      tireDotCode: formData.tireDotCode || '',
      batteryBrand: formData.batteryBrand || '',
      batteryTypeCode: formData.batteryTypeCode || '',
      batteryCapacity: formData.batteryCapacity || '',
      batteryType: formData.batteryType || '',
      batteryCondition: formData.batteryCondition || '',
      batteryElectrolyteStatus: formData.batteryElectrolyteStatus || '',
      metalType: formData.metalType || '',
      metalSalesMethod: formData.metalSalesMethod || '',
      metalEstimatedWeight: formData.metalEstimatedWeight || '',
      metalCondition: formData.metalCondition || '',
      metalHandlingFacility: formData.metalHandlingFacility || '',
      oilBrand: formData.oilBrand || '',
      oilType: formData.oilType || '',
      oilVolume: formData.oilVolume || '',
      oilCondition: formData.oilCondition || '',
      model: formData.model || '',
      series: formData.series || '',
      axels: formData.axels || '',
      vehicleColour: formData.vehicleColour || 'White',
      fuelType: formData.fuelType || 'Solar',
      horsepower: formData.horsepower || '',
      odometer: formData.odometer || '',
      keurValidUntil: formData.keurValidUntil || '',
      stnkPlateValidUntil: formData.stnkPlateValidUntil || '',
      stnkTaxValidUntil: formData.stnkTaxValidUntil || '',
      haveAttachment: formData.haveAttachment,
      attachmentCategory: formData.attachmentCategory || 'Trailer',
      attachmentImageUrl: formData.attachmentImageUrl || '',
      attachmentImageUrls: formData.attachmentImageUrls || [],
      attachmentType: formData.attachmentType || '',
      attachmentAxels: formData.attachmentAxels || '',
      attachmentYearBuilt: formData.attachmentYearBuilt || '',
      attachmentKeurNo: formData.attachmentKeurNo || '',
      attachmentValidUntil: formData.attachmentValidUntil || '',
      attachmentLength: formData.attachmentLength || '',
      attachmentWidth: formData.attachmentWidth || '',
      attachmentHeight: formData.attachmentHeight || '',
      attachmentExtension: formData.attachmentExtension || '',
      tnc: formData.tnc || '',
      closeBidDate: formData.closeBidDate || '',
      useItemTableMode: formData.useItemTableMode,
      usedPartItems: (formData.usedPartItems || [])
        .filter(item => (item.type && String(item.type).trim()) || (item.name && String(item.name).trim()) || (item.spec && String(item.spec).trim()) || (item.qty && String(item.qty).trim()) || (item.unitPrice && String(item.unitPrice).trim()))
        .map((item, idx) => {
          const q = Number(String(item.qty).replace(/\D/g, '')) || 0;
          const p = Number(String(item.unitPrice).replace(/\D/g, '')) || 0;
          return {
            id: item.id || String(idx + 1),
            type: item.type || item.name || '',
            name: item.name || item.type || '',
            spec: item.spec || '',
            qty: q,
            uom: item.uom || 'Pcs',
            unitPrice: p,
            totalPrice: q * p,
            notes: item.notes || ''
          };
        })
    };

    if (editAssetId) {
      onUpdateAsset(editAssetId, assetData);
      setEditAssetId(null);
    } else {
      onAddAsset({
        ...assetData,
        status: 'Open'
      });
    }

    // Reset Form
    setFormData({
      name: '',
      brand: 'Hino',
      category: 'Vehicle',
      modelYear: 2022,
      plateNumber: '',
      condition: 'Baik',
      location: '',
      coordinates: '',
      description: '',
      startingPrice: '',
      manifestStatus: 'Tidak Pake Manifest',
      imageUrl: '',
      imageUrls: [],
      dimensions: '',
      propertyType: 'Gudang',
      auctionType: 'Jual',
      landArea: '',
      buildingArea: '',
      usedPartCategory: 'Ban',
      quantity: '',
      salesSystem: 'Satuan',
      openHouseSchedule: '',
      tireBrand: '',
      tireSize: '',
      tireType: 'Ban Luar',
      tireRimType: '',
      tireTreadDepth: '',
      tireCondition: 'Masih Layak Pakai (Tubeless/Pakai Ban Dalam)',
      tireDotCode: '',
      batteryBrand: '',
      batteryTypeCode: '',
      batteryCapacity: '',
      batteryType: 'Aki Basah',
      batteryCondition: 'Masih Fungsi (Hanya Perlu Cas)',
      batteryElectrolyteStatus: 'Masih Terisi Air Aki',
      metalType: 'Besi Berat / H-Beam / I-Beam / Plate',
      metalSalesMethod: 'Penimbangan',
      metalEstimatedWeight: '',
      metalCondition: '',
      metalHandlingFacility: 'Pemenang Lelang wajib potong dan angkut sendiri',
      oilBrand: '',
      oilType: '',
      oilVolume: '',
      oilCondition: 'Baru (Dalam Kemasan Segel)',
      model: '',
      series: '440',
      axels: '',
      vehicleColour: 'White',
      fuelType: 'Solar',
      horsepower: '',
      odometer: '',
      keurValidUntil: '',
      stnkPlateValidUntil: '',
      stnkTaxValidUntil: '',
      haveAttachment: false,
      attachmentCategory: 'Trailer',
      attachmentImageUrl: '',
      attachmentImageUrls: [],
      attachmentType: 'Highbed 40',
      attachmentAxels: '',
      attachmentYearBuilt: '',
      attachmentKeurNo: '',
      attachmentValidUntil: '',
      attachmentLength: '',
      attachmentWidth: '',
      attachmentHeight: '',
      attachmentExtension: '',
      tnc: '',
      closeBidDate: '',
      usedPartItems: [
        { id: '1', type: '', qty: '', unitPrice: '', totalPrice: '' },
        { id: '2', type: '', qty: '', unitPrice: '', totalPrice: '' },
        { id: '3', type: '', qty: '', unitPrice: '', totalPrice: '' }
      ]
    });
    setIsFormOpen(false);
  };

  const formatIDR = (value: number | undefined | null) => {
    const num = typeof value === 'number' && !isNaN(value) ? value : (Number(value) || 0);
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(num);
  };

  const formatNumberWithDots = (numStr: string) => {
    const clean = numStr.replace(/\D/g, '');
    if (!clean) return '';
    return new Intl.NumberFormat('id-ID').format(Number(clean));
  };

  const handleCopyDetails = (bid: Bid, assetName: string) => {
    const formattedDate = bid.timestamp ? new Date(bid.timestamp).toLocaleString('id-ID', {
      day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit'
    }) + ' WIB' : 'Waktu tidak tercatat';

    const textToCopy = `Detail Penawaran Harga (Bidding):
----------------------------------
Nama Unit: ${assetName}
Nama Penawar: ${bid.name}
Nilai Bid: ${formatIDR(bid.price)}
Waktu Bidding: ${formattedDate}
Nomor Telepon: ${bid.contact}
Email: ${bid.email}
Jadwal Survei: ${bid.scheduleSurveyDate ? `${bid.scheduleSurveyDate} @ ${bid.scheduleSurveyTime || 'N/A'} WIB` : 'Belum dijadwalkan'}`;
    
    if (navigator.clipboard) {
      navigator.clipboard.writeText(textToCopy)
        .then(() => {
          setCopiedState(true);
          setTimeout(() => setCopiedState(false), 2000);
        })
        .catch(() => {});
    }
  };

  return (
    <div className="space-y-8 animate-fade-in" id="admin-assets-view">
      
      {/* Top action header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 tracking-tight">{t('Kelola Aset Lelang')}</h1>
          <p className="text-sm text-slate-500 mt-1">{t('Daftarkan armada logistik baru, pantau status lelang, dan verifikasi riwayat penawaran.')}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5 self-stretch sm:self-auto">
          <button
            onClick={openNewAssetForm}
            className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 shadow-sm shadow-blue-600/10 hover:shadow-blue-600/20 active:scale-95 transition-all flex-1 sm:flex-initial cursor-pointer"
            id="btn-add-new-asset"
          >
            <Plus className="w-5 h-5" />
            <span>{t('Tambah Aset Baru')}</span>
          </button>
        </div>
      </div>

      {/* Main Assets Grid & Detail Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        
        {/* Left Side: Table & Filters (2-cols on desktop if details open, otherwise full width?) 
            Actually, let's keep it beautifully split or dynamic! If an asset is selected, let's show list on 2 columns and details on 1 column. If nothing selected, show list on 3 columns.
        */}
        <div className="space-y-6 transition-all duration-300 lg:col-span-3" id="assets-list-container">
          
          {/* Filters & Search Row */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 border-l-[6px] border-l-slate-300 shadow-sm space-y-4">
            
            {/* Search and Filters */}
            <div className="flex flex-col xl:flex-row gap-3">
              <div className="flex items-center gap-2 flex-1">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder={t('Cari berdasarkan nama aset, plat, kategori...')}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-8 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-sm"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-3 text-slate-400 hover:text-slate-600 p-0.5 rounded-full hover:bg-slate-100 cursor-pointer"
                      title={t('Hapus')}
                    >
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  )}
                </div>
                <button
                  type="button"
                  className="px-3.5 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-xs font-extrabold rounded-xl shadow-sm transition-all flex items-center gap-1.5 cursor-pointer shrink-0 h-[42px]"
                  onClick={() => {
                    const inputEl = document.querySelector('input[placeholder="Cari berdasarkan nama aset, plat, kategori..."]') as HTMLInputElement;
                    if (inputEl) inputEl.focus();
                  }}
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>{t('Cari')}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 w-full xl:w-auto xl:min-w-[680px]">
                {/* Brand Filter */}
                <div className="flex gap-1.5 items-center">
                  <div className="relative flex-1">
                    <select
                      value={brandFilter}
                      onChange={(e) => setBrandFilter(e.target.value)}
                      className="w-full pl-3 pr-8 py-2 bg-white border border-slate-200 rounded-xl appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-xs font-semibold text-slate-700"
                    >
                      <option value="all">{t('Semua Brand')}</option>
                      {uniqueBrands.map(b => (
                        <option key={b} value={b}>{b}</option>
                      ))}
                    </select>
                    <Filter className="w-3.5 h-3.5 absolute right-3 top-3 text-slate-400 pointer-events-none" />
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsBrandMasterOpen(true)}
                    className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-200 rounded-xl transition shadow-sm flex items-center justify-center shrink-0"
                    title={t('Kelola Master Merek')}
                  >
                    <Settings className="w-4 h-4 animate-spin-hover" />
                  </button>
                </div>

                {/* Category Filter */}
                <div className="flex gap-1.5 items-center">
                  <div className="relative flex-1">
                    <select
                      value={categoryFilter}
                      onChange={(e) => setCategoryFilter(e.target.value)}
                      className="w-full pl-3 pr-8 py-2 bg-white border border-slate-200 rounded-xl appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-xs font-semibold text-slate-700"
                    >
                      <option value="all">{t('Semua Kategori')}</option>
                      {displayCategoriesList.map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                    <Filter className="w-3.5 h-3.5 absolute right-3 top-3 text-slate-400 pointer-events-none" />
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsCategoryMasterOpen(true)}
                    className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-200 rounded-xl transition shadow-sm flex items-center justify-center shrink-0"
                    title={t('Kelola Master Kategori')}
                  >
                    <Settings className="w-4 h-4 animate-spin-hover" />
                  </button>
                </div>

                {/* Condition Filter */}
                <div className="flex gap-1.5 items-center">
                  <div className="relative flex-1">
                    <select
                      value={conditionFilter}
                      onChange={(e) => setConditionFilter(e.target.value)}
                      className="w-full pl-3 pr-8 py-2 bg-white border border-slate-200 rounded-xl appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-xs font-semibold text-slate-700"
                    >
                      <option value="all">{t('Semua Kondisi')}</option>
                      {displayConditionsList.map(c => (
                        <option key={c} value={t(c)}>{t(c)}</option>
                      ))}
                    </select>
                    <Filter className="w-3.5 h-3.5 absolute right-3 top-3 text-slate-400 pointer-events-none" />
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsConditionMasterOpen(true)}
                    className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-200 rounded-xl transition shadow-sm flex items-center justify-center shrink-0"
                    title={t('Kelola Master Kondisi')}
                  >
                    <Settings className="w-4 h-4 animate-spin-hover" />
                  </button>
                </div>

                {/* Manifest Filter */}
                {(categoryFilter === 'all' || categoryFilter === 'Used part') && (
                  <div className="flex gap-1.5 items-center">
                    <div className="relative flex-1">
                      <select
                        value={manifestFilter}
                        onChange={(e) => setManifestFilter(e.target.value)}
                        className="w-full pl-3 pr-8 py-2 bg-white border border-slate-200 rounded-xl appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-xs font-semibold text-slate-700 cursor-pointer"
                      >
                        <option value="all">{t('Semua Manifest')}</option>
                        {manifestOptions.map(m => (
                          <option key={m} value={m}>{t(m)}</option>
                        ))}
                      </select>
                      <Filter className="w-3.5 h-3.5 absolute right-3 top-3 text-slate-400 pointer-events-none" />
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsManifestMasterOpen(true)}
                      className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-200 rounded-xl transition shadow-sm flex items-center justify-center shrink-0"
                      title={t('Kelola Master Manifest (Tambah & Hapus Text)')}
                    >
                      <Settings className="w-4 h-4 animate-spin-hover" />
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Status Tabs */}
            <div className="flex border-b border-slate-100 pt-1">
              <button
                onClick={() => setActiveTab('all')}
                className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-all ${
                  activeTab === 'all'
                    ? 'border-blue-600 text-blue-600 font-bold'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {t('Semua Aset')} ({assets.length})
              </button>
              <button
                onClick={() => setActiveTab('Open')}
                className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-all ${
                  activeTab === 'Open'
                    ? 'border-blue-600 text-blue-600 font-bold'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {t('Aktif / Open')} ({assets.filter(a => a.status === 'Open' || !a.bids || a.bids.length === 0).length})
              </button>
              <button
                onClick={() => setActiveTab('Sold')}
                className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-all ${
                  activeTab === 'Sold'
                    ? 'border-blue-600 text-blue-600 font-bold'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {t('Terjual / Sold')} ({assets.filter(a => a.status === 'Sold' && a.bids && a.bids.length > 0).length})
              </button>
            </div>

          </div>

          {/* Cards List Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filteredAssets.map((asset) => {
              const isSelected = asset.id === selectedAssetId;
              const highestOffer = Math.max(asset.startingPrice, ...(asset.bids || []).map(b => b.price));
              const isSparePart = normalizeCategory(asset.category) === 'Used part' || (asset.usedPartItems && asset.usedPartItems.length > 0) || (asset.category || '').toLowerCase().includes('part') || (asset.category || '').toLowerCase().includes('spare');
              const spareItems = (asset.usedPartItems && asset.usedPartItems.length > 0) 
                ? asset.usedPartItems.map(normalizeUsedPartItem) 
                : [{ id: '1', type: asset.name, qty: 1, unitPrice: asset.startingPrice, totalPrice: asset.startingPrice }];
              
              return (
                <div
                  key={asset.id}
                  onClick={() => onSelectAsset(isSelected ? null : asset.id)}
                  className={`cursor-pointer group relative bg-white rounded-2xl overflow-hidden border border-l-[6px] border-l-slate-300 transition-all duration-300 flex flex-col justify-between ${
                    isSelected 
                      ? 'border-blue-500 ring-2 ring-blue-500/10 shadow-lg scale-[1.01] z-10' 
                      : selectedAssetId 
                        ? 'border-slate-200 opacity-30 brightness-[0.75] saturate-50 hover:opacity-95 hover:brightness-100 hover:saturate-100'
                        : 'border-slate-200 hover:border-blue-200 hover:shadow-md'
                  }`}
                >
                  {/* Visual Status Tag on Image */}
                  <div className={`relative ${isSparePart ? 'h-24 bg-slate-100' : 'h-44 bg-slate-100'} overflow-hidden flex items-center justify-center transition-all`}>
                    {(() => {
                      const rawImgs = asset.imageUrls && asset.imageUrls.length > 0 
                        ? asset.imageUrls 
                        : (asset.imageUrl ? [asset.imageUrl] : []);
                      const imgs = rawImgs.filter(url => url && typeof url === 'string' && url.trim() !== '');
                      
                      if (imgs.length === 0) {
                        return (
                          <div className="w-full h-full flex flex-col items-center justify-center gap-1 bg-slate-100 text-slate-400 select-none">
                            <div className="p-1.5 rounded-xl bg-white/90 border border-slate-200/80 shadow-2xs">
                              <CameraOff className="w-4 h-4 text-slate-400" />
                            </div>
                            <span className="text-[10px] font-bold text-slate-500">{t('Tidak Ada Foto')}</span>
                          </div>
                        );
                      }

                      return (
                        <img 
                          src={imgs[0]} 
                          alt={asset.name} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 cursor-zoom-in"
                          referrerPolicy="no-referrer"
                          onClick={(e) => {
                            e.stopPropagation();
                            setLightboxImages(imgs);
                            setLightboxIndex(0);
                          }}
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                          }}
                        />
                      );
                    })()}
                    <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5">
                      <span className="text-[10px] font-mono font-bold bg-white/90 backdrop-blur text-slate-800 px-2 py-0.5 rounded-lg shadow-sm border border-slate-200">
                        {asset.id}
                      </span>
                    </div>

                    <div className="absolute top-2.5 right-2.5 flex flex-col gap-2 items-end">
                      {(() => {
                        const isExpired = asset.closeBidDate ? new Date() > new Date(asset.closeBidDate) : false;
                        const isSold = asset.status === 'Sold' && asset.bids && asset.bids.length > 0;
                        if (isSold) {
                          return (
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full shadow-sm bg-emerald-600 text-white flex items-center gap-1">
                              <Check className="w-3 h-3" />
                              {t('Terjual')}
                            </span>
                          );
                        }
                        if (isExpired) {
                          return (
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full shadow-sm bg-rose-600 text-white flex items-center gap-1">
                              <span className="w-1.5 h-1.5 bg-rose-300 rounded-full"></span>
                              {t('Close Bid')}
                            </span>
                          );
                        }
                        return (
                          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full shadow-sm bg-blue-600 text-white">
                            {t('Menerima Bid')}
                          </span>
                        );
                      })()}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectAsset(asset.id);
                          setTimeout(() => setDeleteConfirmId(asset.id), 100);
                        }}
                        className="p-1.5 bg-white/90 backdrop-blur-sm text-rose-600 hover:bg-rose-600 hover:text-white rounded-lg shadow-sm border border-rose-100 transition-all cursor-pointer"
                        title={t('Hapus Unit Aset')}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="absolute bottom-2.5 left-2.5 bg-black/50 backdrop-blur-sm px-2 py-0.5 rounded-lg text-[10px] text-white font-semibold flex items-center gap-1">
                      <Tag className="w-3 h-3" />
                      {asset.brand && normalizeCategory(asset.category) === 'Vehicle' ? `${asset.brand} • ` : ''}{t(asset.category)}
                    </div>
                  </div>

                  {/* Body Info */}
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                    <div className="space-y-1">
                      <h3 className="font-bold text-slate-800 text-base leading-snug line-clamp-2">
                        {getCleanAssetName(asset)}
                      </h3>
                      {!isSparePart && (
                        <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                          <span>{t('Tahun')} {asset.modelYear}</span>
                          <span>•</span>
                          <span>{t('Plat')}: {asset.plateNumber}</span>
                        </div>
                      )}
                      {isSparePart && isSubCategoryMatch(asset, 'Oli') && (
                        <div className="flex items-center gap-2 text-xs font-medium">
                          <span className="text-slate-400">{t('Manifest')}:</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                            asset.manifestStatus === 'Pake Manifest' 
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                              : 'bg-slate-50 text-slate-600 border border-slate-200'
                          }`}>
                            {t(asset.manifestStatus || 'Tidak Pake Manifest')}
                          </span>
                        </div>
                      )}
                      {asset.closeBidDate && (
                        <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                          <div className="flex items-center gap-1 text-[10px] text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-100 w-fit">
                            <Clock className="w-3.5 h-3.5 text-amber-500" />
                            <span>{t('Tutup')}: {new Date(asset.closeBidDate).toLocaleString('id-ID', { dateStyle: 'short', timeStyle: 'short' })}</span>
                          </div>
                          <CountdownTimer targetDate={asset.closeBidDate} size="small" />
                        </div>
                      )}

                      {/* Spare Part Breakdown Table */}
                      {isSparePart && (() => {
                        const { highestBidObj, highestItemBids } = getHighestBidBreakdown(asset);
                        return (
                          <div className="pt-2 space-y-2" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1">
                                <Layers className="w-3 h-3 text-blue-600" />
                                {t('Tabel Rincian Item / Tipe Suku Cadang')}
                              </span>
                            </div>

                            <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white shadow-2xs">
                              <table className="w-full text-left border-collapse text-[10px]">
                                <thead>
                                  <tr className="bg-[#b8cce4] text-slate-900 font-bold border-b border-slate-300">
                                    <th className="py-1 px-1.5 text-center w-6 border-r border-slate-300/70">{t('No.')}</th>
                                    <th className="py-1 px-2 border-r border-slate-300/70">{t('Type / Nama Item')}</th>
                                    <th className="py-1 px-2 border-r border-slate-300/70">{t('Spesifikasi / Ukuran')}</th>
                                    <th className="py-1 px-1.5 text-center w-10 border-r border-slate-300/70">{t('QTY')}</th>
                                    <th className="py-1 px-2 text-right border-r border-slate-300/70 bg-emerald-100/70 text-emerald-950 font-extrabold">{t('Highest Bid Satuan')}</th>
                                    <th className="py-1 px-2 text-right bg-emerald-100/90 text-emerald-950 font-extrabold">{t('Total Highest Bid')}</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                  {spareItems.map((item, idx) => {
                                    const q = Number(item.qty) || 0;
                                    const hbItem = highestItemBids[idx];
                                    const hbUnit = Number(hbItem?.unitPrice) || 0;
                                    const hbTot = typeof hbItem?.totalPrice === 'number' ? hbItem.totalPrice : (q * hbUnit);
                                    return (
                                      <tr key={idx} className="hover:bg-slate-50">
                                        <td className="py-1 px-1 text-center font-bold text-slate-500 bg-slate-50/50 border-r border-slate-100">{idx + 1}</td>
                                        <td className="py-1 px-2 font-medium text-slate-800 border-r border-slate-100 truncate max-w-[130px]" title={item.type || item.name}>{item.type || item.name || '-'}</td>
                                        <td className="py-1 px-2 text-slate-600 border-r border-slate-100 truncate max-w-[120px]" title={item.spec}>{item.spec || '-'}</td>
                                        <td className="py-1 px-1 text-center font-mono font-bold text-blue-700 border-r border-slate-100">{q}</td>
                                        <td className="py-1 px-2 text-right font-mono font-bold text-emerald-700 bg-emerald-50/40 border-r border-slate-100">{hbUnit > 0 ? formatIDR(hbUnit) : '-'}</td>
                                        <td className="py-1 px-2 text-right font-mono font-bold text-emerald-800 bg-emerald-50/80">{hbTot > 0 ? formatIDR(hbTot) : '-'}</td>
                                      </tr>
                                    );
                                  })}
                                </tbody>
                                <tfoot>
                                  <tr className="bg-slate-50 border-t border-slate-200 font-bold text-[10px]">
                                    <td colSpan={3} className="py-1 px-2 text-right text-slate-700">{t('Grand Total:')}</td>
                                    <td className="py-1 px-1 text-center font-mono text-blue-800 bg-blue-50/40 border-r border-slate-200">
                                      {spareItems.reduce((acc, it) => acc + (Number(it.qty) || 0), 0)}
                                    </td>
                                    <td className="py-1 px-2 text-right text-emerald-900 font-bold bg-emerald-100/40 border-r border-slate-200">{t('Grand Total Bid')}</td>
                                    <td className="py-1 px-2 text-right font-mono font-extrabold text-emerald-950 bg-emerald-100/90">
                                      {formatIDR(highestBidObj ? highestBidObj.price : 0)}
                                    </td>
                                  </tr>
                                </tfoot>
                              </table>
                            </div>
                          </div>
                        );
                      })()}
                    </div>

                    <div className="pt-3 border-t border-slate-50 flex items-center justify-between">
                      <div>
                        <p className="text-[10px] text-slate-400 font-bold uppercase">{t('Harga Awal')}</p>
                        <p className="text-sm font-semibold text-slate-500">{formatIDR(asset.startingPrice)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] text-blue-500 font-bold uppercase">{t('Penawaran Tertinggi')}</p>
                        <p className="text-base font-bold text-blue-700">{formatIDR(highestOffer)}</p>
                      </div>
                    </div>

                    <div className="pt-2 flex items-center justify-between text-xs text-slate-500 font-medium bg-slate-50 -mx-4 -mb-4 px-4 py-2.5 border-t border-slate-100">
                      <span className="flex items-center gap-1">
                        {asset.bids.length} {t('Penawaran')}
                      </span>
                      <span className="text-blue-600 font-bold group-hover:underline flex items-center gap-0.5">
                        {t('Lihat Detail')} <Eye className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}

            {filteredAssets.length === 0 && (
              <div className="col-span-full py-16 bg-white border border-dashed border-slate-200 rounded-3xl text-center space-y-3">
                <p className="text-slate-400 font-medium">{t('Tidak ada aset lelang yang cocok dengan kriteria pencarian.')}</p>
                <button 
                  onClick={() => { setSearchQuery(''); setBrandFilter('all'); setActiveTab('all'); }} 
                  className="text-xs text-blue-600 hover:underline font-semibold"
                >
                  {t('Reset Semua Filter')}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Detail Specification Popup Modal */}
        {selectedAsset && typeof document !== 'undefined' && createPortal((
          <div 
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[999] flex items-center justify-center p-3 sm:p-4 md:p-6 animate-fade-in"
            onClick={() => onSelectAsset(null)}
          >
            <div 
              className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-3xl lg:max-w-4xl w-full overflow-hidden flex flex-col max-h-[84vh] my-auto animate-scale-in"
              onClick={(e) => e.stopPropagation()}
              id="asset-detail-drawer"
            >
              {/* Sticky Header */}
              <div className="flex justify-between items-center border-b border-slate-100 px-5 py-4 sm:px-6 sm:py-4.5 bg-slate-50/80 shrink-0">
                <div className="flex items-center gap-2.5">
                  <span className="text-[10px] font-mono font-bold bg-slate-200 text-slate-700 px-2.5 py-1 rounded-lg">
                    {selectedAsset.id}
                  </span>
                  <h2 className="text-base font-bold text-slate-800">{t('Detail Spesifikasi')}</h2>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleEditClick(selectedAsset)}
                    className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-xl text-xs font-bold flex items-center gap-1.5 border border-blue-200 transition-all active:scale-95 cursor-pointer shadow-3xs"
                    title={t('Edit Unit Aset')}
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>{t('Edit Unit Aset')}</span>
                  </button>
                  <button
                    onClick={() => setDeleteConfirmId(selectedAsset.id)}
                    className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-xl text-xs font-bold flex items-center gap-1.5 border border-rose-200 transition-all active:scale-95 cursor-pointer shadow-3xs"
                    title={t('Hapus Unit Aset')}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{t('Hapus')}</span>
                  </button>
                  <button
                    onClick={() => onSelectAsset(null)}
                    className="p-1.5 hover:bg-slate-200 rounded-xl text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                    title={t('Tutup Detail')}
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Scrollable Content Body */}
              <div className="p-5 sm:p-6 space-y-6 overflow-y-auto max-h-[calc(84vh-65px)]">

                {/* Consolidated Management Panel (4 Actions) */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <button
                    onClick={() => handleEditClick(selectedAsset)}
                    className="flex flex-col items-center justify-center gap-1.5 p-3 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl border border-blue-200 transition-all active:scale-95 cursor-pointer shadow-3xs"
                  >
                    <div className="p-2 bg-white rounded-lg shadow-2xs border border-blue-100">
                      <FileText className="w-4 h-4 text-blue-600" />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-tight">{t('Edit Aset')}</span>
                  </button>
                  
                  <button
                    onClick={() => setDeleteConfirmId(selectedAsset.id)}
                    className="flex flex-col items-center justify-center gap-1.5 p-3 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl border border-rose-200 transition-all active:scale-95 cursor-pointer shadow-3xs"
                  >
                    <div className="p-2 bg-white rounded-lg shadow-2xs border border-rose-100">
                      <Trash2 className="w-4 h-4 text-rose-600" />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-tight">{t('Hapus Aset')}</span>
                  </button>

                  <button
                    onClick={() => {
                      const el = document.getElementById('bids-history-section');
                      if (el) {
                        el.scrollIntoView({ behavior: 'smooth' });
                        // Flash the section
                        el.classList.add('ring-2', 'ring-amber-400', 'ring-offset-2');
                        setTimeout(() => el.classList.remove('ring-2', 'ring-amber-400', 'ring-offset-2'), 2000);
                      }
                    }}
                    className="flex flex-col items-center justify-center gap-1.5 p-3 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-xl border border-amber-200 transition-all active:scale-95 cursor-pointer shadow-3xs"
                  >
                    <div className="p-2 bg-white rounded-lg shadow-2xs border border-amber-100">
                      <DollarSign className="w-4 h-4 text-amber-600" />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-tight">{t('Hapus Bid')}</span>
                  </button>

                  <button
                    onClick={() => {
                      setEditingCloseBidDateId(selectedAsset.id);
                      setTempCloseBidDate(selectedAsset.closeBidDate || '');
                      // Scroll to date section
                      setTimeout(() => {
                        const el = document.getElementById('bid-date-section');
                        if (el) el.scrollIntoView({ behavior: 'smooth' });
                      }, 100);
                    }}
                    className="flex flex-col items-center justify-center gap-1.5 p-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl border border-indigo-200 transition-all active:scale-95 cursor-pointer shadow-3xs"
                  >
                    <div className="p-2 bg-white rounded-lg shadow-2xs border border-indigo-100">
                      <Clock className="w-4 h-4 text-indigo-600" />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-tight">{t('Edit Waktu')}</span>
                  </button>
                </div>

            {/* Asset quick status switcher */}
            <div className="bg-slate-50 p-4 rounded-xl space-y-3 border border-slate-200">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500 font-medium">{t('Status Lelang Saat Ini:')}</span>
                {(() => {
                  const isExpired = selectedAsset.closeBidDate ? new Date() > new Date(selectedAsset.closeBidDate) : false;
                  const isSold = selectedAsset.status === 'Sold' && selectedAsset.bids && selectedAsset.bids.length > 0;
                  if (isSold) {
                    return (
                      <span className="px-2 py-0.5 rounded-full font-bold uppercase text-[10px] bg-emerald-100 text-emerald-700 flex items-center gap-1">
                        <Check className="w-3 h-3" /> {t('Terjual')}
                      </span>
                    );
                  }
                  if (isExpired) {
                    return (
                      <span className="px-2 py-0.5 rounded-full font-bold uppercase text-[10px] bg-rose-100 text-rose-700 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 bg-rose-500 rounded-full"></span> {t('Close Bid')}
                      </span>
                    );
                  }
                  return (
                    <span className="px-2 py-0.5 rounded-full font-bold uppercase text-[10px] bg-blue-100 text-blue-700">
                      {t('Menerima Bid')}
                    </span>
                  );
                })()}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => onUpdateAssetStatus(selectedAsset.id, 'Open')}
                  disabled={selectedAsset.status === 'Open'}
                  className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
                    selectedAsset.status === 'Open' 
                      ? 'bg-blue-600 text-white cursor-not-allowed' 
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Clock className="w-3.5 h-3.5" /> {t('Buka Bid')}
                </button>
                <button
                  onClick={() => onUpdateAssetStatus(selectedAsset.id, 'Sold')}
                  disabled={selectedAsset.status === 'Sold'}
                  className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
                    selectedAsset.status === 'Sold' 
                      ? 'bg-emerald-600 text-white cursor-not-allowed' 
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" /> {t('Set Terjual')}
                </button>
              </div>
            </div>

            {/* Winner Section for Sold Units */}
            {selectedAsset.status === 'Sold' && selectedAsset.bids && selectedAsset.bids.length > 0 && (() => {
              const winnerBid = selectedAsset.bids.length > 0
                ? [...selectedAsset.bids].sort((a, b) => b.price - a.price)[0]
                : null;
              return (
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4.5 space-y-3 shadow-xs">
                  <div className="flex items-center gap-1.5 text-emerald-800 font-bold text-xs uppercase tracking-wider">
                    <Trophy className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{t('Pemenang Lelang')}</span>
                  </div>
                  {winnerBid ? (
                    <div className="space-y-2.5 text-xs">
                      <div className="flex justify-between items-center border-b border-emerald-100/70 pb-2">
                        <span className="text-emerald-600 font-medium">{t('Pemenang')}:</span>
                        <span className="font-bold text-emerald-900 text-sm">{winnerBid.name}</span>
                      </div>
                      <div className="flex justify-between items-center border-b border-emerald-100/70 pb-2">
                        <span className="text-emerald-600 font-medium">{t('Penawaran Pemenang')}:</span>
                        <span className="font-bold text-emerald-900 font-mono text-sm">{formatIDR(winnerBid.price)}</span>
                      </div>
                      <div className="space-y-1 pt-1 text-slate-700 bg-white/50 p-2.5 rounded-xl border border-emerald-100/30">
                        <p className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider mb-1.5">{t('Kontak Pemenang')}</p>
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between gap-1.5 font-medium">
                            <span className="flex items-center gap-1.5">
                              <span className="text-slate-400">📱</span> {winnerBid.contact}
                            </span>
                            {winnerBid.contact && (
                              <a
                                href={`https://wa.me/${winnerBid.contact.replace(/\D/g, '').startsWith('0') ? '62' + winnerBid.contact.replace(/\D/g, '').slice(1) : winnerBid.contact.replace(/\D/g, '')}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1 px-2.5 py-1 text-[10px] font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs hover:shadow-md transition-all cursor-pointer"
                                title={t('Hubungi via WhatsApp')}
                              >
                                <Phone className="w-3 h-3" />
                                <span>WhatsApp</span>
                              </a>
                            )}
                          </div>
                          <div className="flex items-center justify-between gap-1.5 font-medium">
                            <span className="flex items-center gap-1.5">
                              <span className="text-slate-400">✉️</span> {winnerBid.email}
                            </span>
                            {winnerBid.email && (
                              <a
                                href={`mailto:${winnerBid.email}`}
                                className="p-1 bg-white hover:bg-blue-50 text-blue-600 border border-slate-200/60 rounded-lg hover:border-blue-200 transition-all shrink-0"
                                title={t('Kirim Email')}
                              >
                                <Mail className="w-3 h-3" />
                              </a>
                            )}
                          </div>
                        </div>
                        {winnerBid.scheduleSurveyDate && (
                          <div className="text-[10px] text-emerald-800 bg-emerald-100/70 px-2.5 py-1.5 rounded-lg mt-2 font-semibold flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{t('Jadwal Survei')}: {winnerBid.scheduleSurveyDate} @ {winnerBid.scheduleSurveyTime || 'N/A'} WIB</span>
                          </div>
                        )}
                        <button
                          type="button"
                          onClick={() => setSelectedWinnerLetterAsset(selectedAsset)}
                          className="w-full mt-2.5 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
                        >
                          <FileText className="w-4 h-4" />
                          <span>{t('Lihat Surat Pemenang Resmi (PDF)')}</span>
                        </button>

                        <div className="pt-3 mt-3 border-t border-emerald-100/70">
                          <p className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider mb-2">{t('Status Pembayaran')}</p>
                          <div className="flex gap-2">
                            <button
                              onClick={() => onUpdateAsset(selectedAsset.id, { paymentStatus: 'Lunas' })}
                              className={`flex-1 py-1.5 px-2 rounded-lg text-[10px] font-bold transition-all border ${
                                selectedAsset.paymentStatus === 'Lunas'
                                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                                  : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50'
                              }`}
                            >
                              <CheckCircle className="w-3.5 h-3.5 inline-block mr-1 mb-0.5" />
                              {t('Lunas')}
                            </button>
                            <button
                              onClick={() => onUpdateAsset(selectedAsset.id, { paymentStatus: 'Belum Lunas' })}
                              className={`flex-1 py-1.5 px-2 rounded-lg text-[10px] font-bold transition-all border ${
                                selectedAsset.paymentStatus === 'Belum Lunas' || !selectedAsset.paymentStatus
                                  ? 'bg-amber-500 text-white border-amber-500 shadow-xs'
                                  : 'bg-white text-amber-700 border-amber-200 hover:bg-amber-50'
                              }`}
                            >
                              <Clock className="w-3.5 h-3.5 inline-block mr-1 mb-0.5" />
                              {t('Belum Lunas')}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-500 italic bg-white/40 p-3 rounded-xl border border-dashed border-slate-200 text-center">
                      {t('Belum ada penawar')}
                    </p>
                  )}
                </div>
              );
            })()}

            {/* Spec Details */}
            <div className="space-y-4 text-sm">
              {/* Image Carousel / Gallery */}
              <div className="space-y-2">
                {(() => {
                  const rawImgs = selectedAsset.imageUrls && selectedAsset.imageUrls.length > 0 
                    ? selectedAsset.imageUrls 
                    : (selectedAsset.imageUrl ? [selectedAsset.imageUrl] : []);
                  const imgs = rawImgs.filter(url => url && typeof url === 'string' && url.trim() !== '');

                  if (imgs.length === 0) {
                    return (
                      <div className="aspect-video w-full rounded-xl overflow-hidden bg-slate-100 flex flex-col items-center justify-center gap-2 text-slate-400 select-none border border-slate-200">
                        <div className="p-3 bg-white rounded-2xl border border-slate-200 shadow-2xs">
                          <CameraOff className="w-8 h-8 text-slate-400" />
                        </div>
                        <span className="text-xs font-bold text-slate-500">{t('Tidak Ada Foto')}</span>
                      </div>
                    );
                  }

                  return (
                    <>
                      <div className="aspect-video w-full rounded-xl overflow-hidden bg-slate-100 relative group/detail">
                        <img 
                          src={imgs[detailImageIdx] || imgs[0]} 
                          alt={`${selectedAsset.name} - ${detailImageIdx + 1}`} 
                          className="w-full h-full object-cover cursor-zoom-in transition-all duration-300 hover:scale-102" 
                          referrerPolicy="no-referrer"
                          onClick={() => {
                            setLightboxImages(imgs);
                            setLightboxIndex(detailImageIdx);
                          }}
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                          }}
                        />
                        
                        {/* Prev/Next Overlay buttons */}
                        {imgs.length > 1 && (
                          <>
                            <button
                              onClick={() => setDetailImageIdx(prev => (prev === 0 ? imgs.length - 1 : prev - 1))}
                              className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-1.5 rounded-full transition-all opacity-0 group-hover/detail:opacity-100 flex items-center justify-center w-6 h-6 text-xs font-bold"
                              title={t('Sebelumnya')}
                            >
                              ◀
                            </button>
                            <button
                              onClick={() => setDetailImageIdx(prev => (prev === imgs.length - 1 ? 0 : prev + 1))}
                              className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-1.5 rounded-full transition-all opacity-0 group-hover/detail:opacity-100 flex items-center justify-center w-6 h-6 text-xs font-bold"
                              title={t('Berikutnya')}
                            >
                              ▶
                            </button>
                            
                            {/* Image position label */}
                            <span className="absolute bottom-2 right-2 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded-md font-mono">
                              {detailImageIdx + 1} / {imgs.length}
                            </span>
                          </>
                        )}
                      </div>

                      {/* Thumbnails list with horizontal scroll buttons */}
                      {imgs.length > 1 && (
                        <div className="relative flex items-center gap-1.5 mt-2">
                          <button
                            type="button"
                            onClick={() => {
                              const el = document.getElementById('detail-thumb-container');
                              if (el) el.scrollBy({ left: -140, behavior: 'smooth' });
                            }}
                            className="p-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 shadow-xs rounded-lg text-xs font-bold shrink-0 z-10 cursor-pointer active:scale-95 transition-all"
                            title={t('Scroll Kiri')}
                          >
                            ◀
                          </button>
                          <div id="detail-thumb-container" className="flex gap-2 overflow-x-auto py-1 scroll-smooth scrollbar-thin scrollbar-thumb-slate-300 w-full">
                            {imgs.map((url, idx) => (
                              <button
                                key={idx}
                                onClick={() => setDetailImageIdx(idx)}
                                className={`w-16 h-11 rounded-lg overflow-hidden border shrink-0 transition-all cursor-pointer ${idx === detailImageIdx ? 'border-blue-600 ring-2 ring-blue-500/25' : 'border-slate-200 opacity-60 hover:opacity-100'}`}
                              >
                                <img src={url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                              </button>
                            ))}
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              const el = document.getElementById('detail-thumb-container');
                              if (el) el.scrollBy({ left: 140, behavior: 'smooth' });
                            }}
                            className="p-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 shadow-xs rounded-lg text-xs font-bold shrink-0 z-10 cursor-pointer active:scale-95 transition-all"
                            title={t('Scroll Kanan')}
                          >
                            ▶
                          </button>
                        </div>
                      )}
                    </>
                  );
                })()}
              </div>

              <div>
                <h3 className="font-bold text-slate-800 text-base">{selectedAsset.name}</h3>
                <p className="text-xs text-blue-600 font-medium mt-0.5">{selectedAsset.brand} • {selectedAsset.category}</p>
              </div>

              <div className="grid grid-cols-2 gap-y-3 gap-x-4 pt-2 border-t border-slate-50">
                {selectedAsset.category !== 'Used part' && (
                  <>
                    <div>
                      <span className="text-[11px] text-slate-400 font-bold block">{t('PLAT NOMOR')}</span>
                      <span className="font-mono font-semibold text-slate-800">{selectedAsset.plateNumber}</span>
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 font-bold block">{t('TAHUN PRODUKSI')}</span>
                      <span className="font-semibold text-slate-800">{selectedAsset.modelYear}</span>
                    </div>
                  </>
                )}
                <div>
                  <span className="text-[11px] text-slate-400 font-bold block">{t('KONDISI FISIK')}</span>
                  <span className="font-semibold text-slate-800">{t(selectedAsset.condition)}</span>
                </div>
                {selectedAsset.category === 'Used part' && selectedAsset.usedPartCategory === 'Oli' && (
                  <div>
                    <span className="text-[11px] text-slate-400 font-bold block">{t('STATUS MANIFEST')}</span>
                    <span className={`text-xs font-bold ${selectedAsset.manifestStatus === 'Pake Manifest' ? 'text-emerald-600 bg-emerald-50 px-2 py-0.5 border border-emerald-100 rounded-lg inline-block' : 'text-slate-600 bg-slate-100 px-2 py-0.5 border border-slate-200 rounded-lg inline-block'}`}>
                      {t(selectedAsset.manifestStatus || 'Tidak Pake Manifest')}
                    </span>
                  </div>
                )}
                <div>
                  <span className="text-[11px] text-slate-400 font-bold block">{t('LOKASI SEEDING')}</span>
                  <span className="font-semibold text-slate-800 flex items-center gap-0.5 text-xs">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate" title={selectedAsset.location}>{selectedAsset.location}</span>
                  </span>
                </div>
                {selectedAsset.coordinates && (
                  <div>
                    <span className="text-[11px] text-slate-400 font-bold block">{t('TITIK KOORDINAT')}</span>
                    {getGoogleMapsUrl(selectedAsset.coordinates) ? (
                      <a 
                        href={getGoogleMapsUrl(selectedAsset.coordinates)!} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1 text-xs hover:underline"
                      >
                        <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate" title={selectedAsset.coordinates}>{selectedAsset.coordinates}</span>
                      </a>
                    ) : (
                      <span className="font-semibold text-slate-800 text-xs">{selectedAsset.coordinates}</span>
                    )}
                  </div>
                )}
                {selectedAsset.closeBidDate && (
                  editingCloseBidDateId === selectedAsset.id ? (
                    <div id="bid-date-section" className="col-span-2 bg-amber-50 border border-amber-200 p-3 rounded-xl space-y-3 animate-fade-in">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold text-amber-800 uppercase flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5" />
                          {t('Ubah Waktu Penutupan Bid')}
                        </span>
                        <button onClick={() => setEditingCloseBidDateId(null)} className="p-1 hover:bg-amber-100 rounded-lg text-slate-400 hover:text-slate-600 transition-colors">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="datetime-local"
                          value={tempCloseBidDate}
                          onChange={(e) => setTempCloseBidDate(e.target.value)}
                          className="flex-1 p-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                        />
                        <button
                          onClick={() => {
                            onUpdateAsset(selectedAsset.id, { closeBidDate: tempCloseBidDate });
                            setEditingCloseBidDateId(null);
                          }}
                          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-sm transition-all active:scale-95 shrink-0"
                        >
                          {t('Simpan')}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div id="bid-date-section" className="col-span-2 bg-amber-50/50 border border-amber-100 p-2.5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 group/bidtime relative">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                        <div>
                          <span className="text-[10px] text-amber-800 font-bold uppercase block leading-none">{t('Tanggal Penutupan Bid')}</span>
                          <span className="text-xs font-semibold text-amber-950 mt-1 block">
                            {new Date(selectedAsset.closeBidDate).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' })}
                          </span>
                        </div>
                      </div>
                      <div className="flex flex-col items-start sm:items-end shrink-0 pl-6 sm:pl-0 pr-8 sm:pr-0">
                        <span className="text-[9px] font-bold text-amber-800 uppercase tracking-wider mb-1 block">{t('Sisa Waktu')}</span>
                        <CountdownTimer targetDate={selectedAsset.closeBidDate} size="small" />
                      </div>
                      <button
                        onClick={() => {
                          setEditingCloseBidDateId(selectedAsset.id);
                          setTempCloseBidDate(selectedAsset.closeBidDate || '');
                        }}
                        className="absolute right-2 top-2 sm:static p-1.5 bg-white hover:bg-amber-100 text-amber-600 border border-amber-200 rounded-lg shadow-3xs transition-all opacity-0 group-hover/bidtime:opacity-100 cursor-pointer"
                        title={t('Edit Waktu Penutupan')}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )
                )}
                {/* Property specifications fields - Only show for Property category */}
                {normalizeCategory(selectedAsset.category) === 'Property' && (
                  <>
                    {selectedAsset.propertyType && (
                      <div>
                        <span className="text-[11px] text-slate-400 font-bold block">{t('TIPE PROPERTI')}</span>
                        <span className="font-semibold text-slate-800 text-xs">{selectedAsset.propertyType}</span>
                      </div>
                    )}
                    {selectedAsset.auctionType && (
                      <div>
                        <span className="text-[11px] text-slate-400 font-bold block">{t('TIPE LELANG')}</span>
                        <span className="font-semibold text-blue-700 text-xs font-bold">{selectedAsset.auctionType}</span>
                      </div>
                    )}
                    {selectedAsset.landArea && (
                      <div>
                        <span className="text-[11px] text-slate-400 font-bold block">{t('LUAS TANAH')}</span>
                        <span className="font-semibold text-slate-800 text-xs">{selectedAsset.landArea}</span>
                      </div>
                    )}
                    {selectedAsset.buildingArea && (
                      <div>
                        <span className="text-[11px] text-slate-400 font-bold block">{t('LUAS BANGUNAN')}</span>
                        <span className="font-semibold text-slate-800 text-xs">{selectedAsset.buildingArea}</span>
                      </div>
                    )}
                  </>
                )}

                {/* Used Part details in Detail View */}
                {normalizeCategory(selectedAsset.category) === 'Used part' && (
                  <>
                    {/* Itemized Table for Used Part Asset in Detail View */}
                    {selectedAsset.usedPartItems && selectedAsset.usedPartItems.length > 0 && (() => {
                      const { highestBidObj, highestItemBids } = getHighestBidBreakdown(selectedAsset);
                      const totalQty = selectedAsset.usedPartItems.reduce((acc, it) => acc + (Number(it.qty) || 0), 0);
                      const grandTotalAwal = selectedAsset.usedPartItems.reduce((acc, it) => {
                        const q = Number(it.qty) || 0;
                        const p = Number(it.unitPrice) || 0;
                        return acc + (typeof it.totalPrice === 'number' ? it.totalPrice : (q * p));
                      }, 0);

                      return (
                        <div className="col-span-2 mt-2 pt-3 border-t border-slate-200/80 space-y-2">
                          <div className="flex items-center justify-between gap-2 flex-wrap">
                            <div className="flex items-center gap-1.5">
                              <span className="text-[11px] text-slate-700 font-bold uppercase tracking-wider flex items-center gap-1.5">
                                <Layers className="w-4 h-4 text-blue-600" />
                                {t('Tabel Rincian Item / Tipe Suku Cadang')}
                              </span>
                            </div>
                          </div>

                          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-xs">
                            <table className="w-full text-left text-xs border-collapse">
                              <thead>
                                <tr className="bg-[#b8cce4] text-slate-900 font-bold border-b border-slate-300 text-[11px]">
                                  <th className="py-2.5 px-2 text-center w-10 border-r border-slate-300/70">{t('No.')}</th>
                                  <th className="py-2.5 px-3 border-r border-slate-300/70">{t('Type / Nama Item')}</th>
                                  <th className="py-2.5 px-3 border-r border-slate-300/70">{t('Spesifikasi / Ukuran')}</th>
                                  <th className="py-2.5 px-2 text-center w-16 border-r border-slate-300/70">{t('QTY')}</th>
                                  <th className="py-2.5 px-2 text-center w-16 border-r border-slate-300/70">{t('UOM')}</th>
                                  <th className="py-2.5 px-3 border-r border-slate-300/70">{t('Keterangan')}</th>
                                  <th className="py-2.5 px-3 text-right border-r border-slate-300/70 bg-emerald-100/70 text-emerald-950 font-extrabold">{t('Highest Bid Satuan')}</th>
                                  <th className="py-2.5 px-3 text-right bg-emerald-100/90 text-emerald-950 font-extrabold">{t('Total Highest Bid')}</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-100 text-[11px]">
                                {selectedAsset.usedPartItems.map((item, idx) => {
                                  const q = Number(item.qty) || 0;
                                  const p = Number(item.unitPrice) || 0;
                                  const tot = typeof item.totalPrice === 'number' ? item.totalPrice : (q * p);
                                  const hbItem = highestItemBids[idx];
                                  const hbUnit = Number(hbItem?.unitPrice) || 0;
                                  const hbTot = typeof hbItem?.totalPrice === 'number' ? hbItem.totalPrice : (q * hbUnit);

                                  return (
                                    <tr key={idx} className="hover:bg-slate-50">
                                      <td className="py-2 px-2 text-center font-bold text-slate-500 bg-slate-50/50 border-r border-slate-100">{idx + 1}</td>
                                      <td className="py-2 px-3 font-medium text-slate-800 border-r border-slate-100">{item.name || item.type || '-'}</td>
                                      <td className="py-2 px-3 text-slate-600 border-r border-slate-100">{item.spec || '-'}</td>
                                      <td className="py-2 px-2 text-center font-mono font-bold text-blue-700 border-r border-slate-100">{item.qty || 0}</td>
                                      <td className="py-2 px-2 text-center text-slate-600 border-r border-slate-100">{item.uom || 'Pcs'}</td>
                                      <td className="py-2 px-3 text-slate-600 italic border-r border-slate-100">{item.notes || '-'}</td>
                                      <td className="py-2 px-3 text-right font-mono text-emerald-800 font-bold bg-emerald-50/40 border-r border-slate-100">{hbUnit > 0 ? formatIDR(hbUnit) : '-'}</td>
                                      <td className="py-2 px-3 text-right font-mono font-bold text-emerald-800 bg-emerald-50/80">{hbTot > 0 ? formatIDR(hbTot) : '-'}</td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                              <tfoot>
                                <tr className="bg-slate-50 border-t-2 border-slate-200 font-bold text-[11px]">
                                  <td colSpan={3} className="py-2.5 px-3 text-right text-slate-700">{t('Total Keseluruhan:')}</td>
                                  <td className="py-2.5 px-2 text-center font-mono text-blue-800 bg-blue-50/40">{totalQty}</td>
                                  <td colSpan={2} className="py-2.5 px-3 text-right text-slate-400"></td>
                                  <td className="py-2.5 px-3 text-right text-emerald-900 font-bold bg-emerald-100/40 border-r border-slate-200">{t('Grand Total Bid')}</td>
                                  <td className="py-2.5 px-3 text-right font-mono text-xs text-emerald-900 bg-emerald-100/90 font-extrabold">{formatIDR(highestBidObj ? highestBidObj.price : 0)}</td>
                                </tr>
                              </tfoot>
                            </table>
                          </div>
                        </div>
                      );
                    })()}
                  </>
                )}

                {/* Vehicle specifications fields - Only show for Vehicle category */}
                {normalizeCategory(selectedAsset.category) === 'Vehicle' && (
                  <>
                    {selectedAsset.dimensions && (
                      <div className="col-span-2 border-t border-slate-50/50 pt-2">
                        <span className="text-[11px] text-slate-400 font-bold block">{t('Dimensi / Ringkasan Luas')}</span>
                        <span className="font-semibold text-slate-800 font-mono text-xs">{selectedAsset.dimensions}</span>
                      </div>
                    )}
                    {selectedAsset.model && (
                      <div>
                        <span className="text-[11px] text-slate-400 font-bold block">{t('MODEL')}</span>
                        <span className="font-semibold text-slate-800 text-xs">{selectedAsset.model}</span>
                      </div>
                    )}
                    {selectedAsset.series && (
                      <div>
                        <span className="text-[11px] text-slate-400 font-bold block">{t('SERIES')}</span>
                        <span className="font-semibold text-slate-800 text-xs">{selectedAsset.series}</span>
                      </div>
                    )}
                    {selectedAsset.axels && (
                      <div>
                        <span className="text-[11px] text-slate-400 font-bold block">{t('AXELS')}</span>
                        <span className="font-semibold text-slate-800 text-xs">{selectedAsset.axels}</span>
                      </div>
                    )}
                    {selectedAsset.vehicleColour && (
                      <div>
                        <span className="text-[11px] text-slate-400 font-bold block">{t('WARNA')}</span>
                        <span className="font-semibold text-slate-800 text-xs">{t(selectedAsset.vehicleColour)}</span>
                      </div>
                    )}
                    {selectedAsset.fuelType && (
                      <div>
                        <span className="text-[11px] text-slate-400 font-bold block">{t('BAHAN BAKAR')}</span>
                        <span className="font-semibold text-slate-800 text-xs">{t(selectedAsset.fuelType)}</span>
                      </div>
                    )}
                    {selectedAsset.horsepower && (
                      <div>
                        <span className="text-[11px] text-slate-400 font-bold block">{t('Horsepower (HP)')}</span>
                        <span className="font-semibold text-slate-800 text-xs">{selectedAsset.horsepower}</span>
                      </div>
                    )}
                    {selectedAsset.odometer && (
                      <div>
                        <span className="text-[11px] text-slate-400 font-bold block">{t('KM Spidometer')}</span>
                        <span className="font-semibold text-slate-800 text-xs">{selectedAsset.odometer}</span>
                      </div>
                    )}
                  </>
                )}
              </div>

              <div className="pt-2 border-t border-slate-50">
                <span className="text-[11px] text-slate-400 font-bold block">{t('DESKRIPSI INTERNAL')}</span>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-100 max-h-24 overflow-y-auto">
                  {selectedAsset.description}
                </p>
              </div>
            </div>

            {/* Bids List ("list bid price" from flowchart) */}
            <div id="bids-history-section" className="space-y-3 pt-2 border-t border-slate-100 transition-all duration-500 rounded-xl">
              <div className="flex justify-between items-center gap-2">
                <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1">
                  <FileText className="w-4 h-4 text-blue-600" /> {t('Histori Penawaran')} ({selectedAsset.bids.length})
                </h3>
                <div className="flex items-center gap-2">
                  {selectedAsset.status !== 'Sold' && (
                    <button
                      type="button"
                      onClick={() => {
                        setManualBidName('');
                        setManualBidPrice('');
                        setManualBidContact('');
                        setManualBidEmail('');
                        setManualBidDate(new Date().toISOString().split('T')[0]);
                        setManualBidTime(new Date().toTimeString().slice(0, 5));
                        setManualBidSurveyDate('');
                        setManualBidSurveyTime('09:00');
                        setManualBidError('');
                        setShowAddBidModal(true);
                      }}
                      className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 border border-blue-200/80 cursor-pointer"
                      title={t('Input Penawaran Manual')}
                    >
                      <Plus className="w-3 h-3" />
                      <span>{t('Input Bid')}</span>
                    </button>
                  )}
                  <span className="text-[10px] text-slate-400 font-medium hidden sm:inline">{t('Bids Tertinggi Pertama')}</span>
                </div>
              </div>

              <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                {selectedAsset.bids
                  .sort((a, b) => b.price - a.price)
                  .map((bid, i) => {
                    const isTopBid = i === 0;
                    return (
                    <div 
                      key={bid.id} 
                      onClick={() => setFocusedBid(bid)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer space-y-2 text-xs relative group shadow-xs hover:shadow-md ${
                        isTopBid 
                          ? 'bg-amber-50/50 border-amber-200 hover:border-amber-400 hover:bg-amber-50/80 ring-1 ring-amber-300/40' 
                          : 'bg-slate-50 border-slate-200 hover:border-blue-400 hover:bg-white'
                      }`}
                    >
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${
                              isTopBid 
                                ? 'bg-amber-500 text-white' 
                                : 'bg-slate-200 text-slate-700'
                            }`}>
                              #{i + 1}
                            </span>
                            <span className="font-bold text-slate-800 truncate">{bid.name}</span>
                            {isTopBid && (
                              <span className="text-[9px] px-1.5 py-0.5 bg-amber-100 text-amber-800 font-bold rounded border border-amber-200">
                                👑 {t('Tertinggi')}
                              </span>
                            )}
                          </div>
                          <span className="font-mono font-bold text-blue-600 text-sm mt-1 block">{formatIDR(bid.price)}</span>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          {/* Zoom popup button */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setFocusedBid(bid);
                            }}
                            className="flex items-center gap-1 px-2 py-1 bg-white hover:bg-blue-50 text-blue-600 border border-slate-200 hover:border-blue-300 rounded-lg text-[10px] font-bold transition-all cursor-pointer shadow-2xs"
                            title={t('Klik untuk Zoom Pop-up Detail Penawaran')}
                          >
                            <ZoomIn className="w-3.5 h-3.5 text-blue-600" />
                            <span className="hidden sm:inline">{t('Zoom')}</span>
                          </button>

                          {bidDeleteConfirmId === bid.id ? (
                            <div className="flex items-center gap-1 bg-rose-50 p-1 rounded-lg border border-rose-100 shrink-0">
                              <span className="text-[9px] font-bold text-rose-700 shrink-0">{t('Hapus?')}</span>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setBidDeleteConfirmId(null);
                                }}
                                className="px-1.5 py-0.5 bg-white text-slate-600 border border-slate-200 rounded text-[9px] font-bold hover:bg-slate-50 cursor-pointer"
                              >
                                {t('Batal')}
                              </button>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const updatedBids = selectedAsset.bids.filter(b => b.id !== bid.id);
                                  const highestBid = updatedBids.length > 0
                                    ? Math.max(...updatedBids.map(b => b.price), selectedAsset.startingPrice)
                                    : selectedAsset.startingPrice;
                                  onUpdateAsset(selectedAsset.id, { 
                                    bids: updatedBids,
                                    highestBid: highestBid
                                  });
                                  setBidDeleteConfirmId(null);
                                }}
                                className="px-1.5 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[9px] font-bold cursor-pointer"
                              >
                                {t('Ya')}
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setBidDeleteConfirmId(bid.id);
                              }}
                              className="p-1 text-slate-400 hover:text-rose-500 rounded transition-colors cursor-pointer shrink-0"
                              title={t('Hapus Penawaran')}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Waktu Bidding Masuk */}
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-600 bg-white/90 p-1.5 rounded-lg border border-slate-200/70">
                        <Clock className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                        <span className="font-semibold">{t('Waktu Bidding')}:</span>
                        <span className="font-mono font-medium text-slate-700">{formatBidTimestamp(bid.timestamp)}</span>
                      </div>

                      <div className="text-slate-500 flex flex-col gap-0.5 text-[11px]">
                        <span>{t('Hubungi')}: <strong className="text-slate-700 font-semibold">{bid.contact}</strong></span>
                        <span>Email: <strong className="text-slate-700 font-semibold">{bid.email}</strong></span>
                      </div>
                      
                      {/* Survey date if requested, or inline rescheduling */}
                      {editingBidId === bid.id ? (
                        <div 
                          onClick={(e) => e.stopPropagation()}
                          className="mt-2.5 pt-2 border-t border-dashed border-slate-200 space-y-2.5 bg-blue-50/40 p-2.5 rounded-xl border border-blue-100"
                        >
                          <p className="font-bold text-blue-800 text-[10px] uppercase tracking-wide">{t('Atur Jadwal Baru')}</p>
                          <div className="grid grid-cols-2 gap-2">
                            <div className="space-y-0.5">
                              <label className="text-[9px] text-slate-400 font-bold uppercase">{t('Tanggal')}</label>
                              <input
                                type="date"
                                min={new Date().toISOString().split('T')[0]}
                                value={newSurveyDate}
                                onChange={(e) => setNewSurveyDate(e.target.value)}
                                className="w-full p-1.5 border border-slate-200 rounded-lg text-[10px] font-medium bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                              />
                            </div>
                            <div className="space-y-0.5">
                              <label className="text-[9px] text-slate-400 font-bold uppercase">{t('Sesi Jam')}</label>
                              <select
                                value={newSurveyTime}
                                onChange={(e) => setNewSurveyTime(e.target.value)}
                                className="w-full p-1.5 border border-slate-200 rounded-lg text-[10px] font-medium bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                              >
                                <option value="09:00">09:00 WIB</option>
                                <option value="11:00">11:00 WIB</option>
                                <option value="13:30">13:30 WIB</option>
                                <option value="15:30">15:30 WIB</option>
                              </select>
                            </div>
                          </div>
                          <div className="flex gap-1.5 pt-0.5">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingBidId(null);
                              }}
                              className="flex-1 py-1 bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 rounded-md text-[10px] font-bold transition-colors cursor-pointer"
                            >
                              {t('Batal')}
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                const updatedBids = selectedAsset.bids.map(b => {
                                  if (b.id === bid.id) {
                                    return {
                                      ...b,
                                      scheduleSurveyDate: newSurveyDate,
                                      scheduleSurveyTime: newSurveyTime
                                    };
                                  }
                                  return b;
                                });
                                const highestBid = updatedBids.length > 0
                                  ? Math.max(...updatedBids.map(b => b.price), selectedAsset.startingPrice)
                                  : selectedAsset.startingPrice;
                                onUpdateAsset(selectedAsset.id, { 
                                  bids: updatedBids,
                                  highestBid: highestBid
                                });
                                setEditingBidId(null);
                              }}
                              className="flex-1 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-[10px] font-bold transition-colors shadow-xs cursor-pointer"
                            >
                              {t('Simpan')}
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="mt-1.5 pt-1.5 border-t border-dashed border-slate-200 flex flex-col gap-1.5">
                          {bid.scheduleSurveyDate ? (
                            surveyCancelConfirmId === bid.id ? (
                              <div 
                                onClick={(e) => e.stopPropagation()}
                                className="flex items-center justify-between text-[10px] font-semibold text-rose-700 bg-rose-50 px-2 py-1 rounded gap-1.5 border border-rose-100 animate-fade-in"
                              >
                                <span className="font-bold truncate flex-1">{t('Batalkan survei ini?')}</span>
                                <div className="flex gap-1 shrink-0">
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSurveyCancelConfirmId(null);
                                    }}
                                    className="px-1.5 py-0.5 bg-white text-slate-600 border border-slate-200 rounded text-[9px] font-bold hover:bg-slate-50 cursor-pointer"
                                  >
                                    {t('Batal')}
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const updatedBids = selectedAsset.bids.map(b => {
                                        if (b.id === bid.id) {
                                          const updatedBid = { ...b };
                                          delete updatedBid.scheduleSurveyDate;
                                          delete updatedBid.scheduleSurveyTime;
                                          return updatedBid;
                                        }
                                        return b;
                                      });
                                      const highestBid = updatedBids.length > 0
                                        ? Math.max(...updatedBids.map(b => b.price), selectedAsset.startingPrice)
                                        : selectedAsset.startingPrice;
                                      onUpdateAsset(selectedAsset.id, { 
                                        bids: updatedBids,
                                        highestBid: highestBid
                                      });
                                      setSurveyCancelConfirmId(null);
                                    }}
                                    className="px-1.5 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[9px] font-bold cursor-pointer"
                                  >
                                    {t('Ya')}
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <div className="flex items-center justify-between text-[10px] font-semibold text-blue-600 bg-blue-50/50 px-2 py-1 rounded gap-1.5">
                                <span className="flex items-center gap-1 min-w-0 flex-1">
                                  <Calendar className="w-3.5 h-3.5 shrink-0" />
                                  <span className="truncate">{bid.scheduleSurveyDate} @ {bid.scheduleSurveyTime || 'N/A'} WIB</span>
                                </span>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSurveyCancelConfirmId(bid.id);
                                  }}
                                  className="p-0.5 text-blue-400 hover:text-rose-500 rounded transition-colors cursor-pointer shrink-0"
                                  title={t('Batalkan Booking')}
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            )
                          ) : (
                            <div className="text-[9px] text-slate-400 font-medium italic">
                              {t('Belum ada jadwal survei.')}
                            </div>
                          )}
                          
                          {selectedAsset.status !== 'Sold' && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingBidId(bid.id);
                                setNewSurveyDate(bid.scheduleSurveyDate || new Date().toISOString().split('T')[0]);
                                setNewSurveyTime(bid.scheduleSurveyTime || '09:00');
                              }}
                              className="text-left text-[10px] font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 mt-0.5 cursor-pointer"
                            >
                              <Calendar className="w-3 h-3" />
                              <span>{bid.scheduleSurveyDate ? t('Ubah Jadwal') : t('Atur Jadwal Kunjungan')}</span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                    );
                  })}

                {selectedAsset.bids.length === 0 && (
                  <div className="text-center py-6 text-slate-400 text-xs">
                    {t('Belum ada penawaran harga masuk untuk aset ini.')}
                  </div>
                )}
              </div>
            </div>

            {/* Actions: Edit & Delete */}
            {selectedAsset.status !== 'Sold' && (
              deleteConfirmId === selectedAsset.id ? (
                <div className="pt-4 border-t border-rose-100 bg-rose-50/70 p-4 rounded-xl space-y-3 animate-fade-in">
                  <div className="flex gap-2 text-rose-800 text-xs font-semibold items-start">
                    <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-rose-900">{t('Konfirmasi Hapus Unit')}</p>
                      <p className="text-rose-700 font-normal mt-1 leading-relaxed">
                        {t('Apakah Anda yakin ingin menghapus {name} secara permanen? Data historis penawaran juga akan ikut terhapus.').replace('{name}', selectedAsset.name)}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={() => setDeleteConfirmId(null)}
                      className="flex-1 bg-white hover:bg-slate-100 text-slate-700 py-1.5 rounded-lg text-[11px] font-bold border border-slate-200 transition-colors"
                    >
                      {t('Batal')}
                    </button>
                    <button
                      onClick={() => {
                        onDeleteAsset(selectedAsset.id);
                        setDeleteConfirmId(null);
                      }}
                      className="flex-1 bg-rose-600 hover:bg-rose-700 text-white py-1.5 rounded-lg text-[11px] font-bold shadow-sm transition-colors flex items-center justify-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> {t('Ya, Hapus')}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="pt-4 border-t border-slate-100 flex gap-3">
                  <button
                    onClick={() => handleEditClick(selectedAsset)}
                    className="w-full bg-blue-50 hover:bg-blue-100 text-blue-600 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border border-blue-200 transition-colors"
                  >
                    <FileText className="w-4 h-4" /> {t('Edit Unit Aset')}
                  </button>
                  <button
                    onClick={() => setDeleteConfirmId(selectedAsset.id)}
                    className="w-full bg-rose-50 hover:bg-rose-100 text-rose-600 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border border-rose-200 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" /> {t('Hapus Unit Aset')}
                  </button>
                </div>
              )
            )}

              </div>
            </div>
          </div>
        ), document.body)}

      </div>

      {/* Input Asset Modal/Dialog Form */}
      {isFormOpen && typeof document !== 'undefined' && createPortal(
        <div 
          className="fixed inset-0 z-[999999] bg-slate-950/80 backdrop-blur-md p-2 sm:p-4 md:p-6 flex items-center justify-center overflow-hidden animate-fade-in"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setIsFormOpen(false);
            }
          }}
        >
          <div 
            className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl h-full max-h-[90vh] sm:max-h-[92vh] flex flex-col overflow-hidden relative animate-scale-in my-auto border border-slate-100 shrink-0"
            onClick={(e) => e.stopPropagation()}
          >
            
            {/* Modal Header */}
            <div className="sticky top-0 z-30 p-5 sm:p-6 border-b border-slate-100 flex justify-between items-center bg-white/95 backdrop-blur-md rounded-t-3xl shadow-xs shrink-0">
              <div>
                <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2.5 flex-wrap">
                  <span>{editAssetId ? `${t('Ubah Detail Unit')}: ${editAssetId}` : t('Daftarkan Aset Lelang Baru')}</span>
                  {!editAssetId && (formData.category === 'Used part' || formData.category === 'Used Part' || formData.category === 'Sparepart' || (formData.category || '').toLowerCase().includes('part')) && (
                    <button
                      type="button"
                      onClick={handleFillDummySparePart}
                      className="text-[10px] bg-amber-50 hover:bg-amber-100 text-amber-700 font-bold px-2.5 py-1 rounded-full border border-amber-200 flex items-center gap-1 active:scale-95 transition-all shadow-3xs cursor-pointer"
                    >
                      <Wrench className="w-3 h-3 text-amber-600 animate-pulse" />
                      {t('Isi Cepat Dummy Sparepart')}
                    </button>
                  )}
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  {editAssetId ? t('Perbarui spesifikasi teknis dan kelengkapan dokumen kendaraan lelang.') : t('Lengkapi spesifikasi teknis dan detail dokumen kendaraan di bawah.')}
                </p>
              </div>
              <button 
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="p-2 hover:bg-slate-100 rounded-xl text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                title={t('Tutup')}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body / Natural Form Content */}
            <form 
              onSubmit={handleSubmit}
              className="p-5 sm:p-8 space-y-8 overflow-y-auto flex-1 custom-scrollbar scrollbar-thin scrollbar-thumb-indigo-400 overscroll-contain"
            >
              
              {/* Image Upload Component */}
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider block">{t('Foto / Gambar Unit * (Bisa Unggah Banyak)')}</label>
                
                {/* Template Foto (Pilihan Cepat) - Only for Sparepart */}
                {isUsedPart && (
                  <div className="bg-slate-50/80 border border-slate-200 rounded-2xl p-3.5 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5 uppercase tracking-wider">
                        <ImageIcon className="w-4 h-4 text-blue-600" />
                        {t('Template Foto (Pilihan Cepat)')}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setFormData(prev => {
                            const newUrls = TEMPLATE_PHOTOS.map(p => p.url);
                            const existing = prev.imageUrls || [];
                            const merged = Array.from(new Set([...existing, ...newUrls]));
                            return {
                              ...prev,
                              imageUrls: merged,
                              imageUrl: prev.imageUrl || merged[0] || ''
                            };
                          });
                        }}
                        className="text-[11px] font-bold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 px-2.5 py-1 rounded-lg border border-blue-200/80 transition-all active:scale-95 flex items-center gap-1 shadow-2xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        {t('Gunakan Semua Template ({count} Foto)', { count: TEMPLATE_PHOTOS.length })}
                      </button>
                    </div>
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
                      {TEMPLATE_PHOTOS.map((tpl, tIdx) => {
                        const isAlreadyAdded = (formData.imageUrls || []).includes(tpl.url);
                        return (
                          <div 
                            key={tpl.id}
                            className={`relative group rounded-xl overflow-hidden border bg-white flex flex-col justify-between transition-all ${
                              isAlreadyAdded ? 'border-emerald-500 ring-2 ring-emerald-500/15' : 'border-slate-200 hover:border-blue-400'
                            }`}
                          >
                            <div className="aspect-video w-full relative bg-slate-100 overflow-hidden">
                              <img 
                                src={tpl.url} 
                                alt={tpl.name}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                referrerPolicy="no-referrer"
                              />
                              {isAlreadyAdded && (
                                <span className="absolute top-1 right-1 bg-emerald-600 text-white text-[8px] font-bold px-1.5 py-0.5 rounded-md shadow-xs flex items-center gap-0.5">
                                  <Check className="w-2.5 h-2.5" />
                                  {t('Terpakai')}
                                </span>
                              )}
                            </div>
                            <div className="p-1.5 flex items-center justify-between gap-1 bg-slate-50 border-t border-slate-100">
                              <span className="text-[10px] font-semibold text-slate-700 truncate">{t(`Template ${tIdx + 1}`)}</span>
                              <button
                                type="button"
                                onClick={() => {
                                  setFormData(prev => {
                                    const list = prev.imageUrls || [];
                                    if (list.includes(tpl.url)) return prev;
                                    return {
                                      ...prev,
                                      imageUrls: [...list, tpl.url],
                                      imageUrl: prev.imageUrl || tpl.url
                                    };
                                  });
                                }}
                                disabled={isAlreadyAdded}
                                className={`text-[9px] font-bold px-2 py-1 rounded transition-all flex items-center gap-0.5 ${
                                  isAlreadyAdded 
                                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed' 
                                    : 'bg-blue-600 hover:bg-blue-700 text-white shadow-2xs active:scale-95'
                                }`}
                              >
                                <Plus className="w-3 h-3" />
                                {isAlreadyAdded ? t('Terpasang') : t('Tambah')}
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Drag and Drop Zone */}
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragging(true);
                  }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setIsDragging(false);
                    const files = e.dataTransfer.files;
                    if (files && files.length > 0) handleFilesChange(files);
                  }}
                  className={`border-2 border-dashed rounded-2xl p-6 text-center transition-all cursor-pointer relative ${
                    isDragging 
                      ? 'border-blue-500 bg-blue-50/50 animate-pulse' 
                      : 'border-slate-300 bg-white hover:border-blue-400 hover:bg-slate-50/50'
                  }`}
                  onClick={() => document.getElementById('file-upload-input')?.click()}
                >
                  <input
                    id="file-upload-input"
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      const files = e.target.files;
                      if (files && files.length > 0) handleFilesChange(files);
                    }}
                  />
                  
                  <div className="py-2 space-y-2">
                    <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mx-auto shadow-sm">
                      <Upload className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-700">{t('Pilih atau Seret Foto-Foto Armada')}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">{t('Mendukung format PNG, JPG, JPEG (Bisa pilih banyak sekaligus, Max 5MB per file)')}</p>
                    </div>
                  </div>
                </div>

                {/* Koleksi Foto Terunggah */}
                {formData.imageUrls && formData.imageUrls.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-slate-600 uppercase">
                        {t('Foto Terunggah')} ({formData.imageUrls.length})
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setFormData(prev => ({ ...prev, imageUrls: [], imageUrl: '' }));
                        }}
                        className="text-[10px] text-rose-600 font-bold hover:underline"
                      >
                        {t('Hapus Semua')}
                      </button>
                    </div>
                    
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                      {formData.imageUrls.map((url, index) => {
                        const isCover = formData.imageUrl === url || (!formData.imageUrl && index === 0);
                        return (
                          <div 
                            key={index}
                            className={`group relative aspect-[4/3] rounded-xl overflow-hidden border bg-white shadow-sm transition-all duration-300 ${
                              isCover ? 'border-blue-500 ring-2 ring-blue-500/15' : 'border-slate-200 hover:border-slate-300'
                            }`}
                          >
                            <img 
                              src={url} 
                              alt={`Upload ${index + 1}`}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                            
                            {/* Overlay Cover Badge */}
                            {isCover ? (
                              <div className="absolute top-2 left-2 bg-blue-600 text-white text-[9px] font-extrabold px-2 py-0.5 rounded-md flex items-center gap-1 shadow-sm">
                                <Check className="w-2.5 h-2.5 stroke-[3px]" />
                                {t('COVER')}
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setFormData(prev => ({ ...prev, imageUrl: url }))}
                                className="absolute top-2 left-2 bg-white/90 hover:bg-blue-600 hover:text-white text-[9px] font-bold px-2 py-0.5 rounded-md text-slate-700 opacity-0 group-hover:opacity-100 transition-all shadow-sm"
                              >
                                {t('Jadikan Cover')}
                              </button>
                            )}
                            
                            {/* Delete Button */}
                            <button
                              type="button"
                              onClick={() => {
                                setFormData(prev => {
                                  const list = (prev.imageUrls || []).filter(u => u !== url);
                                  return {
                                    ...prev,
                                    imageUrls: list,
                                    imageUrl: prev.imageUrl === url ? (list[0] || '') : prev.imageUrl
                                  };
                                });
                              }}
                              className="absolute top-2 right-2 bg-rose-500 hover:bg-rose-600 text-white p-1 rounded-md opacity-0 group-hover:opacity-100 transition-all shadow-sm"
                              title={t('Hapus Foto')}
                            >
                              <X className="w-3.5 h-3.5 stroke-[2.5px]" />
                            </button>

                            {/* Info Index */}
                            <div className="absolute bottom-2 right-2 bg-black/60 text-white text-[9px] font-mono font-bold px-1.5 py-0.5 rounded-md">
                              {index + 1}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}



                {/* Fallback URL Option removed */}
              </div>

              {/* CATEGORY HELPER CONSTANTS & SELECTOR */}
                    {/* CATEGORY SELECTION CARDS */}
                    <div className="space-y-2.5 bg-slate-50/80 p-4 rounded-2xl border border-slate-200">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                            {t('Pilih Kategori Aset Lelang *')}
                          </label>
                          <button
                            type="button"
                            onClick={() => setIsCategoryMasterOpen(true)}
                            className="p-1 text-slate-500 hover:text-blue-600 bg-white border border-slate-200 hover:border-blue-300 rounded-lg transition shadow-2xs flex items-center gap-1"
                            title={t('Kelola Master Kategori (Tambah & Hapus Text)')}
                          >
                            <Settings className="w-3.5 h-3.5 animate-spin-hover" />
                            <span className="text-[11px] font-semibold">{t('Kelola')}</span>
                          </button>
                        </div>
                        <span className="text-[10px] text-slate-500 font-semibold">
                          {t('Pilih salah satu kategori aset di bawah')}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        {[
                          { 
                            id: 'Vehicle', 
                            label: 'Vehicle', 
                            subLabel: 'Kendaraan & Armada', 
                            icon: Truck, 
                            color: 'blue' 
                          },
                          { 
                            id: 'Used part', 
                            label: 'Used part', 
                            subLabel: 'Suku Cadang / Sparepart', 
                            icon: Wrench, 
                            color: 'amber' 
                          },
                          { 
                            id: 'Property', 
                            label: 'Property', 
                            subLabel: 'Tanah & Properti', 
                            icon: Building2, 
                            color: 'emerald' 
                          },
                          { 
                            id: 'Miscellaneous', 
                            label: 'Miscellaneous', 
                            subLabel: 'Aset Lain-lain / Peralatan', 
                            icon: Package, 
                            color: 'purple' 
                          },
                        ].map((catItem) => {
                          const isSelected = normalizeCategory(formData.category) === normalizeCategory(catItem.id);
                          const IconComp = catItem.icon;
                          return (
                            <button
                              key={catItem.id}
                              type="button"
                              onClick={() => setFormData(prev => {
                                const normId = normalizeCategory(catItem.id);
                                let nextYear = prev.modelYear;
                                if (normId === 'Used part' || normId === 'Property' || normId === 'Miscellaneous') {
                                  if (prev.modelYear === 2022 || prev.modelYear === '2022') {
                                    nextYear = '';
                                  }
                                } else if (normId === 'Vehicle') {
                                  if (prev.modelYear === '') {
                                    nextYear = 2022;
                                  }
                                }
                                return { ...prev, category: catItem.id, modelYear: nextYear };
                              })}
                              className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-2 relative overflow-hidden ${
                                isSelected
                                  ? catItem.color === 'blue' ? 'border-blue-600 bg-blue-50 text-blue-900 ring-2 ring-blue-500/30 shadow-xs' :
                                    catItem.color === 'amber' ? 'border-amber-600 bg-amber-50 text-amber-900 ring-2 ring-amber-500/30 shadow-xs' :
                                    catItem.color === 'emerald' ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-500/30 shadow-xs' :
                                    catItem.color === 'purple' ? 'border-purple-600 bg-purple-50 text-purple-900 ring-2 ring-purple-500/30 shadow-xs' :
                                    'border-blue-600 bg-white text-blue-900 ring-2 ring-blue-500/30 shadow-xs'
                                  : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-100/70 text-slate-700'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <div className={`p-1.5 rounded-lg ${
                                  isSelected 
                                    ? catItem.color === 'blue' ? 'bg-blue-600 text-white' :
                                      catItem.color === 'amber' ? 'bg-amber-600 text-white' :
                                      catItem.color === 'emerald' ? 'bg-emerald-600 text-white' :
                                      catItem.color === 'purple' ? 'bg-purple-600 text-white' :
                                      'bg-blue-600 text-white'
                                    : 'bg-slate-100 text-slate-600'
                                }`}>
                                  <IconComp className="w-4 h-4" />
                                </div>
                                {isSelected && (
                                  <span className={`w-2.5 h-2.5 rounded-full ring-2 animate-pulse ${
                                    catItem.color === 'blue' ? 'bg-blue-600 ring-blue-200' :
                                    catItem.color === 'amber' ? 'bg-amber-600 ring-amber-200' :
                                    catItem.color === 'emerald' ? 'bg-emerald-600 ring-emerald-200' :
                                    catItem.color === 'purple' ? 'bg-purple-600 ring-purple-200' :
                                    'bg-blue-600 ring-blue-200'
                                  }`}></span>
                                )}
                              </div>
                              <div>
                                <p className="font-extrabold text-xs capitalize leading-snug text-slate-800">{catItem.label}</p>
                                <p className="text-[10px] text-slate-500 font-medium leading-tight mt-0.5">{catItem.subLabel}</p>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* GROUP 1: MAIN INFORMATION */}
                    <div className="space-y-4">
                      <div className="border-b border-slate-100 pb-2">
                        <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                          <span className="w-1.5 h-4 bg-slate-400 rounded-full"></span>
                          {t('INFORMASI UTAMA (MAIN INFORMATION)')}
                        </h3>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

                        {/* Brand (Only for Vehicle / non-UsedPart, non-Property, non-Misc) */}
                        {!isProperty && !isUsedPart && !isMisc && (
                          <div className="space-y-1.5">
                            <div className="flex items-center justify-between">
                              <label className="text-xs font-bold text-slate-600 uppercase">
                                {t('Merek (Brand) *')}
                              </label>
                              <button
                                type="button"
                                onClick={() => setIsBrandMasterOpen(true)}
                                className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1 font-semibold transition"
                                title={t('Kelola Master Merek')}
                              >
                                <Settings className="w-3.5 h-3.5 animate-spin-hover" />
                              </button>
                            </div>
                            <select
                              value={formData.brand}
                              onChange={(e) => setFormData(prev => ({ ...prev, brand: e.target.value }))}
                              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                            >
                              {displayBrandsList.map(bName => (
                                <option key={bName} value={bName}>{bName}</option>
                              ))}
                              {formData.brand && !displayBrandsList.includes(formData.brand) && (
                                <option value={formData.brand}>{formData.brand}</option>
                              )}
                            </select>
                          </div>
                        )}

                        {/* Model / Type / Spec / Title */}
                        <div className={`space-y-1.5 ${isProperty || isUsedPart || isMisc ? 'md:col-span-2' : ''}`}>
                          <label className="text-xs font-bold text-slate-600 uppercase">
                            {isVehicle ? `${t('Model')} *` : isProperty ? `${t('Nama / Judul / Spec Properti')} *` : `${t('Model / Tipe / Spec')} *`}
                          </label>
                          <input
                            type="text"
                            required
                            placeholder={
                              isVehicle ? t('Contoh: FMX, Ranger, Giga, 440') :
                              isUsedPart ? t('Contoh: Engine Assy Hino E13C 440HP / Transmission ZF') :
                              isProperty ? t('Contoh: Gudang & Lahan Depo Marunda 1.200 m²') :
                              t('Contoh: Genset Caterpillar 500 kVA / Heavy Equipment Tool')
                            }
                            value={formData.model}
                            onChange={(e) => setFormData(prev => ({ ...prev, model: e.target.value }))}
                            className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium text-slate-800"
                          />
                        </div>

                        {/* Plate Number (Only for Vehicle) */}
                        {isVehicle && (
                          <div className="space-y-1.5">
                            <label className="text-xs font-bold text-slate-600 uppercase">
                              {t('Nomor Polisi (Nopol) *')}
                            </label>
                            <input
                              type="text"
                              required
                              placeholder={t('Contoh: B 9012 PQA')}
                              value={formData.plateNumber}
                              onChange={(e) => setFormData(prev => ({ ...prev, plateNumber: e.target.value.toUpperCase() }))}
                              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono font-bold text-slate-800"
                            />
                          </div>
                        )}

                        {/* Model Year (Only for Vehicle) */}
                        {isVehicle && (
                          <div className="space-y-1.5">
                            <label className="text-xs font-bold text-slate-600 uppercase">
                              {t('Tahun Pembuatan *')}
                            </label>
                            <input
                              type="number"
                              required
                              min="1950"
                              max="2035"
                              placeholder={t('Contoh: 2022')}
                              value={formData.modelYear}
                              onChange={(e) => setFormData(prev => ({ ...prev, modelYear: e.target.value }))}
                              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium text-slate-800"
                            />
                          </div>
                        )}

                      </div>

                      {/* MODE OPSIONAL: TABEL RINCIAN ITEM / BARANG (Tabel Terstruktur) - ONLY FOR USED PART */}
                      {isUsedPart && (
                        <div className="bg-slate-50/90 border border-slate-200/90 rounded-2xl p-4 space-y-4 shadow-xs">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/80 pb-3">
                          <div className="flex items-center gap-2.5">
                            <div className="p-2 bg-blue-100/80 border border-blue-200 text-blue-700 rounded-xl">
                              <Layers className="w-4 h-4" />
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                                  {t('MODE OPSIONAL: TABEL RINCIAN ITEM / BARANG')}
                                </h4>
                                <span className="text-[10px] bg-blue-100 text-blue-800 font-bold px-2 py-0.5 rounded-full border border-blue-200">
                                  {(formData.usedPartItems || []).length} {t('Baris')}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-500 mt-0.5">
                                {t('Gunakan tabel ini jika aset memiliki rincian banyak barang dengan tombol X di tiap kolom untuk menyembunyikan/menampilkan kolom secara fleksibel.')}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              type="button"
                              onClick={handleFillDummySparePart}
                              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 active:scale-95 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
                              title={t('Isi 8 baris contoh barang dari sampel tabel')}
                            >
                              <Sparkles className="w-3.5 h-3.5" />
                              <span>{t('Isi Contoh Tabel')}</span>
                            </button>

                            <button
                              type="button"
                              onClick={handleAddUsedPartItem}
                              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>{t('Tambah Baris')}</span>
                            </button>
                          </div>
                        </div>

                        {/* Column Toggle Selector Bar */}
                        <div className="flex flex-wrap items-center justify-between gap-2 bg-blue-50/70 p-2.5 rounded-xl border border-blue-200/80 text-xs">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-bold text-slate-700 mr-1 flex items-center gap-1">
                              <Eye className="w-3.5 h-3.5 text-blue-600" />
                              {t('Tampilkan/Sembunyikan Kolom:')}
                            </span>
                            {[
                              { key: 'name', label: 'Nama Barang' },
                              { key: 'spec', label: 'Spesifikasi' },
                              { key: 'qty', label: 'QTY' },
                              { key: 'uom', label: 'UOM' },
                              { key: 'unitPrice', label: 'Harga Satuan' },
                              { key: 'totalPrice', label: 'Total Harga' },
                              { key: 'notes', label: 'Keterangan' },
                            ].map(col => {
                              const visible = isColVisible(col.key);
                              return (
                                <button
                                  key={col.key}
                                  type="button"
                                  onClick={() => handleToggleColumnVisibility(col.key)}
                                  className={`px-2 py-0.5 rounded-lg text-[11px] font-semibold border transition flex items-center gap-1 cursor-pointer ${
                                    visible
                                      ? 'bg-white text-slate-700 border-slate-300 hover:border-blue-400 shadow-2xs'
                                      : 'bg-slate-200 text-slate-400 border-slate-300 line-through'
                                  }`}
                                >
                                  {visible ? <CheckSquare className="w-3 h-3 text-blue-600" /> : <Square className="w-3 h-3 text-slate-400" />}
                                  {t(col.label)}
                                </button>
                              );
                            })}
                          </div>

                          {(formData.hiddenItemColumns && formData.hiddenItemColumns.length > 0) && (
                            <button
                              type="button"
                              onClick={handleResetAllColumns}
                              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-[11px] transition shadow-2xs flex items-center gap-1 cursor-pointer"
                            >
                              <Sparkles className="w-3 h-3" />
                              <span>{t('Tampilkan Semua Kolom')}</span>
                            </button>
                          )}
                        </div>

                        {/* Table Component */}
                        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-xs">
                          <table className="w-full text-left text-xs border-collapse">
                            <thead>
                              <tr className="bg-[#b8cce4] text-slate-900 border-b border-slate-300 font-bold text-[11px]">
                                <th className="py-2.5 px-2 text-center min-w-[45px] border-r border-slate-300 uppercase tracking-wider">{t('No.')}</th>

                                {isColVisible('name') && (
                                  <th className="py-2.5 px-3 border-r border-slate-300 uppercase tracking-wider min-w-[180px]">
                                    <div className="flex items-center justify-between gap-1">
                                      <span>{t('Nama Barang')}</span>
                                      <button
                                        type="button"
                                        onClick={() => handleToggleColumnVisibility('name')}
                                        className="p-0.5 text-slate-500 hover:text-rose-700 hover:bg-rose-100 rounded transition cursor-pointer"
                                        title={t('Hilangkan Kolom Ini')}
                                      >
                                        <X className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </th>
                                )}

                                {isColVisible('spec') && (
                                  <th className="py-2.5 px-3 border-r border-slate-300 uppercase tracking-wider min-w-[220px]">
                                    <div className="flex items-center justify-between gap-1">
                                      <span>{t('Spesifikasi / Ukuran')}</span>
                                      <button
                                        type="button"
                                        onClick={() => handleToggleColumnVisibility('spec')}
                                        className="p-0.5 text-slate-500 hover:text-rose-700 hover:bg-rose-100 rounded transition cursor-pointer"
                                        title={t('Hilangkan Kolom Ini')}
                                      >
                                        <X className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </th>
                                )}

                                {isColVisible('qty') && (
                                  <th className="py-2.5 px-2 text-center min-w-[90px] border-r border-slate-300 uppercase tracking-wider">
                                    <div className="flex items-center justify-between gap-1">
                                      <span>{t('QTY')}</span>
                                      <button
                                        type="button"
                                        onClick={() => handleToggleColumnVisibility('qty')}
                                        className="p-0.5 text-slate-500 hover:text-rose-700 hover:bg-rose-100 rounded transition cursor-pointer"
                                        title={t('Hilangkan Kolom Ini')}
                                      >
                                        <X className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </th>
                                )}

                                {isColVisible('uom') && (
                                  <th className="py-2.5 px-2 text-center min-w-[110px] border-r border-slate-300 uppercase tracking-wider">
                                    <div className="flex items-center justify-between gap-1">
                                      <span>{t('UOM')}</span>
                                      <button
                                        type="button"
                                        onClick={() => handleToggleColumnVisibility('uom')}
                                        className="p-0.5 text-slate-500 hover:text-rose-700 hover:bg-rose-100 rounded transition cursor-pointer"
                                        title={t('Hilangkan Kolom Ini')}
                                      >
                                        <X className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </th>
                                )}

                                {isColVisible('unitPrice') && (
                                  <th className="py-2.5 px-3 text-right min-w-[165px] border-r border-slate-300 uppercase tracking-wider">
                                    <div className="flex items-center justify-between gap-1">
                                      <button
                                        type="button"
                                        onClick={() => handleToggleColumnVisibility('unitPrice')}
                                        className="p-0.5 text-slate-500 hover:text-rose-700 hover:bg-rose-100 rounded transition cursor-pointer"
                                        title={t('Hilangkan Kolom Ini')}
                                      >
                                        <X className="w-3.5 h-3.5" />
                                      </button>
                                      <span>{t('Harga Satuan')}</span>
                                    </div>
                                  </th>
                                )}

                                {isColVisible('totalPrice') && (
                                  <th className="py-2.5 px-3 text-right min-w-[160px] border-r border-slate-300 uppercase tracking-wider">
                                    <div className="flex items-center justify-between gap-1">
                                      <button
                                        type="button"
                                        onClick={() => handleToggleColumnVisibility('totalPrice')}
                                        className="p-0.5 text-slate-500 hover:text-rose-700 hover:bg-rose-100 rounded transition cursor-pointer"
                                        title={t('Hilangkan Kolom Ini')}
                                      >
                                        <X className="w-3.5 h-3.5" />
                                      </button>
                                      <span>{t('Total Harga')}</span>
                                    </div>
                                  </th>
                                )}

                                {isColVisible('notes') && (
                                  <th className="py-2.5 px-3 border-r border-slate-300 uppercase tracking-wider min-w-[200px] text-left">
                                    <div className="flex items-center justify-between gap-1">
                                      <span>{t('Keterangan')}</span>
                                      <button
                                        type="button"
                                        onClick={() => handleToggleColumnVisibility('notes')}
                                        className="p-0.5 text-slate-500 hover:text-rose-700 hover:bg-rose-100 rounded transition cursor-pointer"
                                        title={t('Hilangkan Kolom Ini')}
                                      >
                                        <X className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </th>
                                )}

                                <th className="py-2.5 px-2 text-center min-w-[55px] uppercase tracking-wider">{t('Aksi')}</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-200">
                              {(formData.usedPartItems && formData.usedPartItems.length > 0) ? (
                                formData.usedPartItems.map((item, idx) => {
                                  const rowQty = Number(String(item.qty).replace(/\D/g, '')) || 0;
                                  const rowUnitPrice = Number(String(item.unitPrice).replace(/\D/g, '')) || 0;
                                  const rowTotal = rowQty * rowUnitPrice;

                                  return (
                                    <tr key={item.id || idx} className="hover:bg-slate-50/80 transition-colors">
                                      <td className="py-2 px-2 text-center font-bold text-slate-600 border-r border-slate-200 bg-slate-50/50">
                                        {idx + 1}
                                      </td>

                                      {isColVisible('name') && (
                                        <td className="py-1.5 px-2 border-r border-slate-200">
                                          <input
                                            type="text"
                                            value={item.name || item.type || ''}
                                            placeholder={t('Contoh: Ban Outer Truck / Aki Heavy Duty')}
                                            onChange={(e) => {
                                              handleUsedPartItemChange(idx, 'type', e.target.value);
                                              handleUsedPartItemChange(idx, 'name', e.target.value);
                                            }}
                                            className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white font-medium"
                                          />
                                        </td>
                                      )}

                                      {isColVisible('spec') && (
                                        <td className="py-1.5 px-2 border-r border-slate-200">
                                          <input
                                            type="text"
                                            value={item.spec || ''}
                                            placeholder={t('Contoh: Bridgestone Mixtech M729 10.00 - R20 16PR')}
                                            onChange={(e) => handleUsedPartItemChange(idx, 'spec', e.target.value)}
                                            className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                                          />
                                        </td>
                                      )}

                                      {isColVisible('qty') && (
                                        <td className="py-1.5 px-2 border-r border-slate-200 min-w-[90px]">
                                          <input
                                            type="text"
                                            inputMode="numeric"
                                            value={item.qty === '' ? '' : formatNumberWithDots(String(item.qty))}
                                            placeholder="0"
                                            onChange={(e) => {
                                              const raw = e.target.value.replace(/\D/g, '');
                                              handleUsedPartItemChange(idx, 'qty', raw);
                                            }}
                                            className="w-full px-1.5 py-1 text-center font-mono font-bold border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                                          />
                                        </td>
                                      )}

                                      {isColVisible('uom') && (
                                        <td className="py-1.5 px-2 border-r border-slate-200 min-w-[110px]">
                                          <input
                                            type="text"
                                            value={item.uom ?? ''}
                                            placeholder="Pcs/Set/Batang"
                                            onChange={(e) => handleUsedPartItemChange(idx, 'uom', e.target.value)}
                                            className="w-full px-2 py-1 text-center border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white font-medium"
                                          />
                                        </td>
                                      )}

                                      {isColVisible('unitPrice') && (
                                        <td className="py-1.5 px-2 border-r border-slate-200 min-w-[165px]">
                                          <div className="relative">
                                            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-bold">Rp</span>
                                            <input
                                              type="text"
                                              inputMode="numeric"
                                              value={item.unitPrice === '' ? '' : formatNumberWithDots(String(item.unitPrice))}
                                              placeholder="0"
                                              onChange={(e) => {
                                                const raw = e.target.value.replace(/\D/g, '');
                                                handleUsedPartItemChange(idx, 'unitPrice', raw);
                                              }}
                                              className="w-full pl-6 pr-2 py-1 text-right font-mono font-bold border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                                            />
                                          </div>
                                        </td>
                                      )}

                                      {isColVisible('totalPrice') && (
                                        <td className="py-2 px-3 text-right font-mono font-bold text-slate-900 border-r border-slate-200 bg-slate-50/30 min-w-[160px]">
                                          {rowTotal > 0 ? (
                                            <span className="text-emerald-700 font-extrabold">{formatIDR(rowTotal)}</span>
                                          ) : (
                                            <span className="text-slate-400 text-xs">Rp 0</span>
                                          )}
                                        </td>
                                      )}

                                      {isColVisible('notes') && (
                                        <td className="py-1.5 px-2 border-r border-slate-200">
                                          <input
                                            type="text"
                                            value={item.notes || ''}
                                            placeholder={t('Keterangan / Catatan')}
                                            onChange={(e) => handleUsedPartItemChange(idx, 'notes', e.target.value)}
                                            className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                                          />
                                        </td>
                                      )}

                                      <td className="py-1.5 px-2 text-center">
                                        <button
                                          type="button"
                                          onClick={() => handleRemoveUsedPartItem(idx)}
                                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                          title={t('Hapus Baris')}
                                        >
                                          <Trash2 className="w-3.5 h-3.5" />
                                        </button>
                                      </td>
                                    </tr>
                                  );
                                })
                              ) : (
                                <tr>
                                  <td colSpan={9} className="py-4 text-center text-slate-400 italic">
                                    {t('Belum ada baris item. Klik "Tambah Baris" atau "Isi Contoh Tabel" di atas.')}
                                  </td>
                                </tr>
                              )}
                            </tbody>

                            {/* Table Footer with Grand Total */}
                            {formData.usedPartItems && formData.usedPartItems.length > 0 && (() => {
                              const colSpanBeforeTotal = 1 +
                                (isColVisible('name') ? 1 : 0) +
                                (isColVisible('spec') ? 1 : 0) +
                                (isColVisible('qty') ? 1 : 0) +
                                (isColVisible('uom') ? 1 : 0) +
                                (isColVisible('unitPrice') ? 1 : 0);
                              const colSpanAfterTotal = (isColVisible('notes') ? 1 : 0) + 1;

                              return (
                                <tfoot>
                                  <tr className="bg-slate-100 border-t-2 border-slate-300 font-bold text-slate-800 text-[11px]">
                                    <td colSpan={colSpanBeforeTotal} className="py-2.5 px-3 text-right uppercase tracking-wider text-slate-700">
                                      {t('Grand Total (Total Seluruh Barang):')}
                                    </td>
                                    {isColVisible('totalPrice') && (
                                      <td className="py-2.5 px-3 text-right font-mono text-sm text-emerald-800 bg-emerald-50/90 font-extrabold border-r border-slate-300">
                                        {formatIDR(totalUsedPartsPrice)}
                                      </td>
                                    )}
                                    <td colSpan={colSpanAfterTotal} className="py-2.5 px-3 text-slate-500 font-normal italic">
                                      {totalUsedPartsQty} {t('Total Kuantitas Items')}
                                    </td>
                                  </tr>
                                </tfoot>
                              );
                            })()}
                          </table>
                        </div>

                        {totalUsedPartsPrice > 0 && (
                          <div className="flex items-center justify-between pt-1">
                            <div className="text-xs text-emerald-800 font-semibold flex items-center gap-1.5 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 shadow-2xs">
                              <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                              <span>{t('Grand Total otomatis terhubung & mengisi Harga Awal Lelang:')} <strong className="font-mono text-emerald-950 font-bold">{formatIDR(totalUsedPartsPrice)}</strong></span>
                            </div>
                          </div>
                        )}
                      </div>
                      )}

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Condition */}
                        {!isUsedPart && (
                          <div className="space-y-1.5">
                            <div className="flex items-center justify-between">
                              <label className="text-xs font-bold text-slate-600 uppercase">{t('Kondisi Fisik Unit *')}</label>
                              <button
                                type="button"
                                onClick={() => setIsConditionMasterOpen(true)}
                                className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1 font-semibold transition"
                                title={t('Kelola Master Kondisi')}
                              >
                                <Settings className="w-3.5 h-3.5 animate-spin-hover" />
                              </button>
                            </div>
                            <select
                              value={formData.condition}
                              onChange={(e) => setFormData(prev => ({ ...prev, condition: e.target.value }))}
                              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                            >
                              {displayConditionsList.map(condName => (
                                <option key={condName} value={condName}>{condName}</option>
                              ))}
                              {formData.condition && !displayConditionsList.includes(formData.condition) && (
                                <option value={formData.condition}>{formData.condition}</option>
                              )}
                            </select>
                          </div>
                        )}

                        {/* Starting Price */}
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between">
                            <label className="text-xs font-bold text-slate-600 uppercase">{t('Harga Awal Lelang (IDR) *')}</label>
                            {isUsedPart && (
                              <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                                <Sparkles className="w-3 h-3 text-emerald-600" />
                                {t('Otomatis dari Grand Total')}
                              </span>
                            )}
                          </div>
                          <input
                            type="text"
                            inputMode="numeric"
                            required
                            placeholder={t('Contoh: 150.000.000')}
                            value={formatNumberWithDots(formData.startingPrice)}
                            onChange={(e) => {
                              const raw = e.target.value.replace(/\D/g, '');
                              setFormData(prev => ({ ...prev, startingPrice: raw }));
                            }}
                            className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-semibold"
                          />
                          {isUsedPart && (
                            <p className="text-[11px] text-emerald-700 font-medium flex items-center gap-1">
                              <span>💡 {t('Otomatis sinkron dengan Grand Total tabel:')}</span>
                              <span className="font-mono font-bold">{formatIDR(totalUsedPartsPrice)}</span>
                            </p>
                          )}
                        </div>

                        {/* Manifest Status Field has been moved to Section D Oli specifications above */}

                        {/* Location */}
                        <div className="space-y-1.5 md:col-span-2">
                          <label className="text-xs font-bold text-slate-600 uppercase">
                            {isProperty ? t('Alamat Lengkap Properti *') : t('Lokasi Pool / Depo Unit *')}
                          </label>
                          <input
                            type="text"
                            required
                            placeholder={
                              isProperty ? t('Contoh: Jl. Raya Marunda No. 88, Cilincing, Jakarta Utara') :
                              t('Contoh: Pool Marunda Blok C, Jakut')
                            }
                            value={formData.location}
                            onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                            className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                          />
                        </div>

                        {/* Coordinates / Map Link */}
                        <div className="space-y-2 md:col-span-2">
                          <label className="text-xs font-bold text-slate-600 uppercase flex items-center gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-blue-600" />
                            {t('Link Google Maps')}
                          </label>
                          <input
                            type="text"
                            placeholder={t('Contoh: -6.229382, 106.820384 atau langsung tempel link Google Maps')}
                            value={formData.coordinates || ''}
                            onChange={(e) => setFormData(prev => ({ ...prev, coordinates: e.target.value }))}
                            className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                          />
                          <p className="text-[10px] text-slate-400">
                            {t('Masukkan titik koordinat (latitude, longitude) atau langsung tempel link Google Maps unit agar pembeli dapat langsung menuju lokasi.')}
                          </p>
                        </div>

                        {/* Close Bid Date & Time */}
                        <div className="space-y-1.5 md:col-span-2">
                          <label className="text-xs font-bold text-slate-600 uppercase">
                            {t('Tanggal & Waktu Penutupan Bid (Close Bid Date & Time)')}
                          </label>
                          <input
                            type="datetime-local"
                            value={formData.closeBidDate}
                            onChange={(e) => setFormData(prev => ({ ...prev, closeBidDate: e.target.value }))}
                            className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium text-slate-700"
                          />
                          <p className="text-[10px] text-slate-400">
                            {t('Kosongkan jika lelang tidak memiliki batas waktu penutupan otomatis.')}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* VEHICLE SPECIFIC GROUPS (Shown ONLY if Category is Vehicle) */}
                    {isVehicle && (
                      <div className="space-y-6">
                          {/* GROUP 2: VEHICLE SPECIFICATION DETAILS */}
                          <div className="space-y-4">
                <div className="border-b border-slate-100 pb-2">
                  <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                    <span className="w-1.5 h-4 bg-slate-400 rounded-full"></span>
                    {t('DETAIL SPESIFIKASI KENDARAAN (VEHICLE SPECIFICATION DETAILS)')}
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Series */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-600 uppercase">{t('Series')}</label>
                      <button
                        type="button"
                        onClick={() => setIsSeriesMasterOpen(true)}
                        className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1 font-semibold transition"
                        title={t('Kelola Master Seri')}
                      >
                        <Settings className="w-3.5 h-3.5 animate-spin-hover" />
                      </button>
                    </div>
                    <select
                      value={formData.series}
                      onChange={(e) => setFormData(prev => ({ ...prev, series: e.target.value }))}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    >
                      {displaySeriesList.map(sName => (
                        <option key={sName} value={sName}>{sName}</option>
                      ))}
                      {formData.series && !displaySeriesList.includes(formData.series) && (
                        <option value={formData.series}>{formData.series}</option>
                      )}
                    </select>
                  </div>

                  {/* Axels */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 uppercase">{t('Axels')}</label>
                    <input
                      type="text"
                      placeholder={t('Contoh: 6x4, 4x2')}
                      value={formData.axels}
                      onChange={(e) => setFormData(prev => ({ ...prev, axels: e.target.value }))}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    />
                  </div>

                  {/* Vehicle Colour */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-600 uppercase">{t('Warna Kendaraan')}</label>
                      <button
                        type="button"
                        onClick={() => setIsColourMasterOpen(true)}
                        className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1 font-semibold transition"
                        title={t('Kelola Master Warna')}
                      >
                        <Settings className="w-3.5 h-3.5 animate-spin-hover" />
                      </button>
                    </div>
                    <select
                      value={formData.vehicleColour}
                      onChange={(e) => setFormData(prev => ({ ...prev, vehicleColour: e.target.value }))}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    >
                      {displayColoursList.map(cName => (
                        <option key={cName} value={cName}>{cName}</option>
                      ))}
                      {formData.vehicleColour && !displayColoursList.includes(formData.vehicleColour) && (
                        <option value={formData.vehicleColour}>{formData.vehicleColour}</option>
                      )}
                    </select>
                  </div>

                  {/* Fuel Type */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-600 uppercase">{t('Bahan Bakar')}</label>
                      <button
                        type="button"
                        onClick={() => setIsFuelMasterOpen(true)}
                        className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1 font-semibold transition"
                        title={t('Kelola Master Bahan Bakar')}
                      >
                        <Settings className="w-3.5 h-3.5 animate-spin-hover" />
                      </button>
                    </div>
                    <select
                      value={formData.fuelType}
                      onChange={(e) => setFormData(prev => ({ ...prev, fuelType: e.target.value }))}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    >
                      {displayFuelsList.map(fName => (
                        <option key={fName} value={fName}>{fName}</option>
                      ))}
                      {formData.fuelType && !displayFuelsList.includes(formData.fuelType) && (
                        <option value={formData.fuelType}>{formData.fuelType}</option>
                      )}
                    </select>
                  </div>

                  {/* Horsepower */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 uppercase">{t('Horsepower (HP)')}</label>
                    <input
                      type="text"
                      placeholder={t('Contoh: 280 HP atau 340')}
                      value={formData.horsepower}
                      onChange={(e) => setFormData(prev => ({ ...prev, horsepower: e.target.value }))}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    />
                  </div>

                  {/* KM Spidometer */}
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-xs font-bold text-slate-600 uppercase">{t('KM Spidometer')}</label>
                    <input
                      type="text"
                      placeholder={t('Contoh: 150.000 atau 75.000')}
                      value={formData.odometer}
                      onChange={(e) => setFormData(prev => ({ ...prev, odometer: e.target.value }))}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* GROUP 2.5: VEHICLE DOCUMENTS & LEGALITY */}
              <div className="space-y-4">
                <div className="border-b border-slate-100 pb-2">
                  <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                    <span className="w-1.5 h-4 bg-slate-400 rounded-full"></span>
                    {t('DOKUMEN & LEGALITAS KENDARAAN (VEHICLE DOCUMENTS & LEGALITY)')}
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* KEUR Berlaku Hingga */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 uppercase">{t('KEUR BERLAKU HINGGA')}</label>
                    <input
                      type="date"
                      value={formData.keurValidUntil}
                      onChange={(e) => setFormData(prev => ({ ...prev, keurValidUntil: e.target.value }))}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    />
                  </div>

                  {/* STNK Plat Berlaku Hingga */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 uppercase">{t('PLAT STNK BERLAKU HINGGA')}</label>
                    <input
                      type="date"
                      value={formData.stnkPlateValidUntil}
                      onChange={(e) => setFormData(prev => ({ ...prev, stnkPlateValidUntil: e.target.value }))}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    />
                  </div>

                  {/* STNK Pajak Berlaku Hingga */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 uppercase">{t('PAJAK STNK BERLAKU HINGGA')}</label>
                    <input
                      type="date"
                      value={formData.stnkTaxValidUntil}
                      onChange={(e) => setFormData(prev => ({ ...prev, stnkTaxValidUntil: e.target.value }))}
                      className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* GROUP 3: ATTACHMENT SPECIFICATIONS */}
              <div className="space-y-4">
                <div className="border-b border-slate-100 pb-2">
                  <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                    <span className="w-1.5 h-4 bg-slate-400 rounded-full"></span>
                    {t('SPESIFIKASI ATTACHMENT (ATTACHMENT SPECIFICATIONS)')}
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Have Attachment Radio Buttons */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-600 uppercase block">{t('Memiliki Attachment?')}</label>
                    <div className="flex items-center gap-6 pt-1.5">
                      <label className="flex items-center gap-2.5 cursor-pointer text-sm font-semibold text-slate-700 select-none">
                        <input
                          type="radio"
                          name="haveAttachment"
                          checked={formData.haveAttachment === true}
                          onChange={() => setFormData(prev => ({ ...prev, haveAttachment: true }))}
                          className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-slate-300"
                        />
                        {t('Ya')}
                      </label>
                      <label className="flex items-center gap-2.5 cursor-pointer text-sm font-semibold text-slate-700 select-none">
                        <input
                          type="radio"
                          name="haveAttachment"
                          checked={formData.haveAttachment === false}
                          onChange={() => setFormData(prev => ({ ...prev, haveAttachment: false }))}
                          className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-slate-300"
                        />
                        {t('Tidak')}
                      </label>
                    </div>
                  </div>

                  {/* Attachment Category */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-600 uppercase">{t('Attachment')}</label>
                      {formData.haveAttachment && (
                        <button
                          type="button"
                          onClick={() => setIsAttachmentMasterOpen(true)}
                          className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1 font-semibold transition"
                          title={t('Kelola Master Jenis Gandengan')}
                        >
                          <Settings className="w-3.5 h-3.5 animate-spin-hover" />
                        </button>
                      )}
                    </div>
                    <select
                      value={formData.attachmentCategory}
                      onChange={(e) => setFormData(prev => ({ ...prev, attachmentCategory: e.target.value }))}
                      disabled={!formData.haveAttachment}
                      className={`w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition ${
                        !formData.haveAttachment ? 'bg-slate-50 text-slate-400 cursor-not-allowed' : 'bg-white'
                      }`}
                    >
                      {displayAttachmentCategoriesList.map(aName => (
                        <option key={aName} value={aName}>{aName}</option>
                      ))}
                      {formData.attachmentCategory && !displayAttachmentCategoriesList.includes(formData.attachmentCategory) && (
                        <option value={formData.attachmentCategory}>{formData.attachmentCategory}</option>
                      )}
                    </select>
                  </div>
                </div>

                {/* ATTACHMENT DETAIL PANEL (Shown only if haveAttachment is true) */}
                {formData.haveAttachment && (
                  <div className="border border-slate-200/80 bg-slate-50/50 rounded-2xl p-5 space-y-5 animate-fade-in">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t('Detail Attachment')}</h4>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      
                      {/* Upload Attachment Photo */}
                      <div className="space-y-2 md:col-span-2">
                        <label className="text-xs font-semibold text-slate-600 uppercase block">{t('Unggah Attachment')}</label>
                        
                        <div className="flex flex-col md:flex-row gap-4 items-start">
                          {/* Mini Drag Drop Area */}
                          <div 
                            onClick={() => document.getElementById('attachment-file-input')?.click()}
                            onDragOver={(e) => {
                              e.preventDefault();
                              setIsAttachmentDragging(true);
                            }}
                            onDragLeave={() => setIsAttachmentDragging(false)}
                            onDrop={(e) => {
                              e.preventDefault();
                              setIsAttachmentDragging(false);
                              const files = e.dataTransfer.files;
                              if (files && files.length > 0) handleAttachmentFilesChange(files);
                            }}
                            className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer flex-1 w-full flex flex-col items-center justify-center min-h-[100px] transition-all ${
                              isAttachmentDragging 
                                ? 'border-blue-500 bg-blue-50/50 animate-pulse' 
                                : 'border-slate-300 bg-white hover:border-blue-400 hover:bg-slate-50/50'
                            }`}
                          >
                            <input
                              id="attachment-file-input"
                              type="file"
                              accept="image/*"
                              multiple
                              className="hidden"
                              onChange={(e) => {
                                const files = e.target.files;
                                if (files && files.length > 0) handleAttachmentFilesChange(files);
                              }}
                            />
                            <Upload className="w-5 h-5 text-slate-400 mb-1" />
                            <p className="text-xs font-semibold text-slate-600">{t('Pilih Foto Attachment')}</p>
                            <p className="text-[10px] text-slate-400 mt-0.5">JPG, JPEG, PNG (Max 1MB)</p>
                          </div>

                          {/* Previews */}
                          {formData.attachmentImageUrls && formData.attachmentImageUrls.length > 0 && (
                            <div className="flex flex-wrap gap-2 shrink-0">
                              {formData.attachmentImageUrls.map((url, i) => (
                                <div key={i} className="relative w-20 h-20 rounded-lg overflow-hidden border border-slate-200 bg-white">
                                  <img 
                                    src={url} 
                                    alt="Attachment Preview" 
                                    className="w-full h-full object-cover" 
                                    referrerPolicy="no-referrer"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => setFormData(prev => {
                                      const filtered = prev.attachmentImageUrls.filter((_, idx) => idx !== i);
                                      return {
                                        ...prev,
                                        attachmentImageUrls: filtered,
                                        attachmentImageUrl: prev.attachmentImageUrl === url ? (filtered[0] || '') : prev.attachmentImageUrl
                                      };
                                    })}
                                    className="absolute top-1 right-1 bg-rose-500 hover:bg-rose-600 text-white p-0.5 rounded-full shadow"
                                  >
                                    <X className="w-3 h-3" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Type (Subtype) */}
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-bold text-slate-600 uppercase">{t('Tipe')}</label>
                          <button
                            type="button"
                            onClick={() => setIsAttachmentTypeMasterOpen(true)}
                            className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1 font-semibold transition"
                            title={t('Kelola Master Tipe Gandengan')}
                          >
                            <Settings className="w-3.5 h-3.5 animate-spin-hover" />
                          </button>
                        </div>
                        <select
                          value={formData.attachmentType}
                          onChange={(e) => setFormData(prev => ({ ...prev, attachmentType: e.target.value }))}
                          className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                        >
                          {displayAttachmentTypesList.map(atName => (
                            <option key={atName} value={atName}>{atName}</option>
                          ))}
                          {formData.attachmentType && !displayAttachmentTypesList.includes(formData.attachmentType) && (
                            <option value={formData.attachmentType}>{formData.attachmentType}</option>
                          )}
                        </select>
                      </div>

                      {/* Axels */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 uppercase">{t('Axels')}</label>
                        <input
                          type="text"
                          placeholder={t('Contoh: 2.2 atau 3.0')}
                          value={formData.attachmentAxels}
                          onChange={(e) => setFormData(prev => ({ ...prev, attachmentAxels: e.target.value }))}
                          className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                        />
                      </div>

                      {/* Year Built */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 uppercase">{t('Tahun Produksi *')}</label>
                        <input
                          type="text"
                          placeholder={t('Contoh: 2016')}
                          value={formData.attachmentYearBuilt}
                          onChange={(e) => setFormData(prev => ({ ...prev, attachmentYearBuilt: e.target.value }))}
                          className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                        />
                      </div>

                      {/* Valid Until */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 uppercase">{t('KEUR BERLAKU HINGGA')}</label>
                        <input
                          type="date"
                          value={formData.attachmentValidUntil}
                          onChange={(e) => setFormData(prev => ({ ...prev, attachmentValidUntil: e.target.value }))}
                          className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                        />
                      </div>

                      {/* Nested subsection Dimension */}
                      <div className="md:col-span-2 border-t border-slate-200 pt-4 mt-2 space-y-4">
                        <h5 className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t('Dimensi')}</h5>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                          {/* Length */}
                          <div className="space-y-1.5">
                            <label className="text-xs font-bold text-slate-600 uppercase">{t('Panjang Total (Meter)')}</label>
                            <input
                              type="text"
                              placeholder={t('Contoh: 40 M atau 12.0')}
                              value={formData.attachmentLength}
                              onChange={(e) => setFormData(prev => ({ ...prev, attachmentLength: e.target.value }))}
                              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                            />
                          </div>

                          {/* Width */}
                          <div className="space-y-1.5">
                            <label className="text-xs font-bold text-slate-600 uppercase">{t('Lebar Total (TON)')}</label>
                            <input
                              type="text"
                              placeholder={t('Contoh: 60 Ton')}
                              value={formData.attachmentWidth}
                              onChange={(e) => setFormData(prev => ({ ...prev, attachmentWidth: e.target.value }))}
                              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                            />
                          </div>

                          {/* Height */}
                          <div className="space-y-1.5">
                            <label className="text-xs font-bold text-slate-600 uppercase">{t('Tinggi Total (Meter)')}</label>
                            <input
                              type="text"
                              placeholder={t('Contoh: 1.5 M')}
                              value={formData.attachmentHeight}
                              onChange={(e) => setFormData(prev => ({ ...prev, attachmentHeight: e.target.value }))}
                              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 bg-white"
                            />
                          </div>


                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

              {/* Description */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 uppercase">{t('Deskripsi & Spesifikasi Tambahan')}</label>
                <textarea
                  ref={descriptionRef}
                  rows={4}
                  placeholder={t('Jelaskan kondisi mesin, transmisi, kelengkapan surat KIR/STNK, riwayat perawatan, dsb.')}
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 min-h-[100px] resize-none overflow-hidden"
                />
              </div>

              {/* Syarat & Ketentuan (TNC) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 uppercase">{t('Syarat & Ketentuan Lelang (TNC)')}</label>
                <textarea
                  rows={4}
                  placeholder={t('Opsional. Masukkan syarat & ketentuan lelang khusus untuk unit ini. Jika dikosongkan, area Syarat & Ketentuan tidak akan menampilkan ketentuan apapun.')}
                  value={formData.tnc}
                  onChange={(e) => setFormData(prev => ({ ...prev, tnc: e.target.value }))}
                  className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 min-h-[100px]"
                />
              </div>

              {/* Modal Footer actions */}
              <div className="sticky bottom-0 z-30 -mx-5 sm:-mx-8 -mb-5 sm:-mb-8 px-5 sm:px-8 py-4 bg-white/95 backdrop-blur-md border-t border-slate-100 flex gap-3 justify-end rounded-b-3xl shadow-xs">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  {t('Batal')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-md shadow-blue-600/10 hover:shadow-blue-600/20 transition-all flex items-center gap-1 cursor-pointer"
                >
                  <Check className="w-4 h-4" /> {editAssetId ? t('Simpan Perubahan') : t('Simpan Unit Baru')}
                </button>
              </div>

            </form>

          </div>
        </div>,
        document.body
      )}

      {/* Immersive Fullscreen Lightbox Zoom Overlay */}
      {lightboxIndex !== null && lightboxImages.length > 0 && (
        <div 
          className="fixed inset-0 bg-slate-950/95 backdrop-blur-md z-[100] flex flex-col items-center justify-center p-4 md:p-8 select-none animate-fade-in"
          id="image-lightbox-overlay"
          onClick={() => setLightboxIndex(null)}
        >
          {/* Controls Bar */}
          <div className="absolute top-4 right-4 flex items-center gap-2 z-[110]">
            {/* Zoom Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsZoomed(prev => !prev);
              }}
              className="bg-slate-900/80 hover:bg-slate-800 text-white p-2.5 rounded-full border border-slate-800 hover:border-slate-700 hover:scale-105 transition-all shadow-xl flex items-center justify-center cursor-pointer"
              title={isZoomed ? t('Zoom Out') : t('Zoom In')}
            >
              {isZoomed ? <ZoomOut className="w-5 h-5" /> : <ZoomIn className="w-5 h-5" />}
            </button>

            {/* Close button */}
            <button
              onClick={() => setLightboxIndex(null)}
              className="bg-slate-900/80 hover:bg-slate-800 text-white p-2.5 rounded-full border border-slate-800 hover:border-slate-700 hover:scale-105 transition-all shadow-xl flex items-center justify-center cursor-pointer"
              title={t('Tutup')}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Prev button */}
          {lightboxImages.length > 1 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                setLightboxIndex(prev => (prev === null ? 0 : (prev === 0 ? lightboxImages.length - 1 : prev - 1)));
              }}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-slate-900/80 hover:bg-slate-800 text-white p-3 rounded-full border border-slate-800 hover:border-slate-700 hover:scale-105 transition-all shadow-xl z-[110] flex items-center justify-center w-12 h-12 cursor-pointer"
              title={t('Sebelumnya')}
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
          )}

          {/* Next button */}
          {lightboxImages.length > 1 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                setLightboxIndex(prev => (prev === null ? 0 : (prev === lightboxImages.length - 1 ? 0 : prev + 1)));
              }}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-slate-900/80 hover:bg-slate-800 text-white p-3 rounded-full border border-slate-800 hover:border-slate-700 hover:scale-105 transition-all shadow-xl z-[110] flex items-center justify-center w-12 h-12 cursor-pointer"
              title={t('Berikutnya')}
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          )}

          {/* Image Container with Smooth Animation & Zoom Scroll Support */}
          <div 
            className={`relative w-full max-w-6xl max-h-[85vh] flex items-center justify-center animate-zoom-in transition-all duration-300 ${
              isZoomed ? "overflow-auto cursor-zoom-out p-4 justify-start items-start bg-slate-950/40 rounded-2xl border border-slate-900" : ""
            }`}
            onClick={(e) => {
              e.stopPropagation();
              if (isZoomed) {
                setIsZoomed(false);
              }
            }}
          >
            <img
              src={lightboxImages[lightboxIndex] || ""}
              alt={`Zoomed Asset - ${lightboxIndex + 1}`}
              className={`select-none transition-all duration-300 ${
                isZoomed 
                  ? "w-[200%] md:w-[150%] max-w-none max-h-none object-contain cursor-zoom-out rounded-lg shadow-2xl" 
                  : "w-full max-w-full max-h-[85vh] object-contain rounded-2xl shadow-2xl border border-slate-800 cursor-zoom-in hover:scale-[1.01]"
              }`}
              referrerPolicy="no-referrer"
              onClick={(e) => {
                e.stopPropagation();
                setIsZoomed(prev => !prev);
              }}
            />
          </div>

          {/* Position indicator & Close hint */}
          <div className="mt-4 flex flex-col items-center gap-1.5 text-center">
            {lightboxImages.length > 1 && (
              <span className="text-xs text-slate-300 font-mono font-bold bg-slate-900/60 px-3 py-1 rounded-full border border-slate-800">
                {lightboxIndex + 1} / {lightboxImages.length}
              </span>
            )}
            <p className="text-[10px] text-slate-400 font-semibold tracking-wider uppercase mt-1">
              {isZoomed 
                ? t('Klik gambar untuk memperkecil • Geser untuk menjelajah detail') 
                : t('Klik gambar untuk memperbesar • Klik di luar untuk kembali')}
            </p>
          </div>
        </div>
      )}

      {/* Immersive Focused Bid Details Modal Overlay (Zoom Detail) */}
      {focusedBid && selectedAsset && (() => {
        const sortedBids = [...selectedAsset.bids].sort((a, b) => b.price - a.price);
        const bidRank = sortedBids.findIndex(b => b.id === focusedBid.id) + 1;
        const isWinnerCandidate = bidRank === 1;
        const timeDetail = formatBidTimestampDetail(focusedBid.timestamp);
        const priceDiff = focusedBid.price - selectedAsset.startingPrice;
        const diffPercent = selectedAsset.startingPrice > 0 ? ((priceDiff / selectedAsset.startingPrice) * 100).toFixed(1) : '0';

        return (
        <div 
          className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-[120] flex items-center justify-center p-3 sm:p-4 animate-fade-in"
          onClick={() => setFocusedBid(null)}
        >
          <div 
            className="bg-white rounded-3xl border border-slate-100 shadow-2xl max-w-xl w-full p-6 sm:p-7 relative overflow-hidden transition-all duration-300 animate-zoom-in flex flex-col max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header Gradient line */}
            <div className={`absolute top-0 left-0 right-0 h-2 bg-gradient-to-r ${
              isWinnerCandidate ? 'from-amber-400 via-amber-500 to-yellow-400' : 'from-blue-500 via-indigo-500 to-sky-500'
            }`} />
            
            {/* Title Bar */}
            <div className="flex justify-between items-start mb-5 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className={`p-3 rounded-2xl border ${
                  isWinnerCandidate ? 'bg-amber-50 border-amber-200 text-amber-600' : 'bg-blue-50 border-blue-100 text-blue-600'
                }`}>
                  <ZoomIn className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-extrabold text-slate-900 tracking-tight">
                      {t('Detail Penawaran Harga')}
                    </h3>
                    <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                      isWinnerCandidate 
                        ? 'bg-amber-500 text-white shadow-xs' 
                        : 'bg-slate-200 text-slate-700'
                    }`}>
                      #{bidRank} {isWinnerCandidate ? `👑 ${t('Penawar Tertinggi')}` : `${t('Peringkat')} ${bidRank}`}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-semibold mt-0.5">
                    {selectedAsset.brand} {selectedAsset.name} • <span className="font-mono text-slate-700 font-bold">{selectedAsset.plateNumber}</span>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setFocusedBid(null)}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-all cursor-pointer"
                title={t('Tutup')}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable details area */}
            <div className="space-y-4 overflow-y-auto pr-1 flex-1 py-1">
              
              {/* Huge Price Block */}
              <div className={`border rounded-2xl p-5 text-center shadow-xs relative overflow-hidden ${
                isWinnerCandidate ? 'bg-amber-50/40 border-amber-200' : 'bg-blue-50/30 border-blue-100'
              }`}>
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block mb-1">
                  {t('NILAI PENAWARAN (BID PRICE)')}
                </span>
                <span className="text-3xl sm:text-4xl font-extrabold text-blue-700 font-mono tracking-tight block">
                  {formatIDR(focusedBid.price)}
                </span>
                <div className="flex items-center justify-center gap-2 mt-2 text-[11px] text-slate-500">
                  <span>{t('Harga Dasar')}: <strong className="font-mono">{formatIDR(selectedAsset.startingPrice)}</strong></span>
                  <span>•</span>
                  <span className={priceDiff >= 0 ? 'text-emerald-600 font-bold' : 'text-slate-500 font-bold'}>
                    {priceDiff >= 0 ? `+${formatIDR(priceDiff)} (+${diffPercent}%)` : `-${formatIDR(Math.abs(priceDiff))}`}
                  </span>
                </div>
              </div>

              {/* Itemized Sparepart Bids Table in Admin detail view */}
              {focusedBid.itemBids && focusedBid.itemBids.length > 0 && (
                <div className="bg-slate-50 border border-slate-200/90 rounded-2xl p-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-700 font-bold uppercase tracking-wider flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-blue-600" />
                      {t('Rincian Penawaran Per Tipe ({count} Tipe)', { count: focusedBid.itemBids.length })}
                    </span>
                    <span className="text-[9px] bg-blue-100 text-blue-800 font-bold px-2 py-0.5 rounded-full">
                      {t('Itemized Bid')}
                    </span>
                  </div>
                  <div className="overflow-x-auto rounded-xl border border-slate-200/80 bg-white">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-[#b8cce4] text-slate-900 font-bold text-[10px] uppercase border-b border-slate-300">
                          <th className="py-2 px-2.5">{t('No')}</th>
                          <th className="py-2 px-2.5">{t('Tipe Barang')}</th>
                          <th className="py-2 px-2.5 text-center">{t('Qty')}</th>
                          <th className="py-2 px-2.5 text-right">{t('Harga Bid Satuan')}</th>
                          <th className="py-2 px-2.5 text-right">{t('Subtotal Bid')}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-[11px]">
                        {focusedBid.itemBids.map((item, idx) => {
                          const qty = Number(item.qty) || 1;
                          const unitPrice = Number(item.unitPrice) || 0;
                          const subtotal = qty * unitPrice;
                          return (
                            <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                              <td className="py-2 px-2.5 font-bold text-slate-500">{idx + 1}</td>
                              <td className="py-2 px-2.5 font-semibold text-slate-800">{item.type}</td>
                              <td className="py-2 px-2.5 text-center font-mono font-medium text-slate-700">{qty}</td>
                              <td className="py-2 px-2.5 text-right font-mono text-slate-600">{formatIDR(unitPrice)}</td>
                              <td className="py-2 px-2.5 text-right font-mono font-bold text-emerald-700">{formatIDR(subtotal)}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                      <tfoot>
                        <tr className="bg-slate-100/80 font-bold text-xs border-t border-slate-200">
                          <td colSpan={4} className="py-2 px-2.5 text-right text-slate-700 uppercase text-[10px]">{t('Total Bid')}:</td>
                          <td className="py-2 px-2.5 text-right font-mono font-extrabold text-blue-700">{formatIDR(focusedBid.price)}</td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              )}

              {/* WAKTU BIDDING (TANGGAL & JAM INPUT) HIGHLIGHT CARD */}
              <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-4 shadow-md border border-slate-700/60 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-blue-300 font-bold text-xs">
                    <Clock className="w-4 h-4 text-blue-400" />
                    <span>{t('WAKTU BIDDING / INPUT PENAWARAN')}</span>
                  </div>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-semibold">
                    ✓ {t('Tercatat Sistem')}
                  </span>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-slate-700/60">
                  <div className="flex items-center gap-2 bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
                    <Calendar className="w-4 h-4 text-sky-400 shrink-0" />
                    <div>
                      <span className="text-[9px] text-slate-400 font-bold uppercase block">{t('Tanggal Penawaran')}</span>
                      <span className="text-xs font-bold text-white block">{timeDetail.dateStr}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
                    <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                    <div>
                      <span className="text-[9px] text-slate-400 font-bold uppercase block">{t('Jam Input')}</span>
                      <span className="text-xs font-mono font-bold text-amber-300 block">{timeDetail.timeStr}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Grid of Key Bidder Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Bidder Name */}
                <div className="bg-slate-50/70 p-3.5 rounded-2xl border border-slate-200/80 flex flex-col justify-between">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">
                    {t('NAMA PENAWAR')}
                  </span>
                  <span className="text-sm font-bold text-slate-800 break-words block">
                    {focusedBid.name}
                  </span>
                </div>

                {/* Scheduled Visit / Survey Date */}
                <div className="bg-slate-50/70 p-3.5 rounded-2xl border border-slate-200/80 flex flex-col justify-between">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">
                    {t('JADWAL KUNJUNGAN / SURVEY')}
                  </span>
                  {focusedBid.scheduleSurveyDate ? (
                    <div className="flex items-center gap-1.5 text-blue-600 font-bold text-xs mt-1">
                      <Calendar className="w-4 h-4 shrink-0 text-blue-500" />
                      <span className="truncate">
                        {focusedBid.scheduleSurveyDate} @ {focusedBid.scheduleSurveyTime || '09:00'} WIB
                      </span>
                    </div>
                  ) : (
                    <span className="text-xs text-slate-400 font-medium italic mt-1">
                      {t('Belum ada jadwal survei.')}
                    </span>
                  )}
                </div>

                {/* Email address */}
                <div className="bg-slate-50/70 p-3.5 rounded-2xl border border-slate-200/80 flex flex-col justify-between">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">
                    EMAIL
                  </span>
                  <div className="flex items-center justify-between gap-1 mt-1">
                    <span className="text-xs text-slate-700 font-semibold break-all block truncate flex-1" title={focusedBid.email}>
                      {focusedBid.email || '-'}
                    </span>
                    {focusedBid.email && focusedBid.email !== '-' && (
                      <a
                        href={`mailto:${focusedBid.email}`}
                        className="p-1 bg-white hover:bg-blue-50 text-blue-600 border border-slate-200 rounded-lg hover:border-blue-200 transition-all shrink-0 ml-1"
                        title={t('Kirim Email')}
                      >
                        <Mail className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                </div>

                {/* Contact/WhatsApp */}
                <div className="bg-slate-50/70 p-3.5 rounded-2xl border border-slate-200/80 flex flex-col justify-between">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">
                    {t('NOMOR HP / WHATSAPP')}
                  </span>
                  <div className="flex items-center justify-between gap-1 mt-1">
                    <span className="text-xs text-slate-700 font-semibold break-words block truncate flex-1">
                      {focusedBid.contact || '-'}
                    </span>
                    {focusedBid.contact && focusedBid.contact !== '-' && (
                      <a
                        href={`https://wa.me/${focusedBid.contact.replace(/\D/g, '').startsWith('0') ? '62' + focusedBid.contact.replace(/\D/g, '').slice(1) : focusedBid.contact.replace(/\D/g, '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1 bg-white hover:bg-emerald-50 text-emerald-600 border border-slate-200 rounded-lg hover:border-emerald-200 transition-all shrink-0 ml-1"
                        title={t('Hubungi via WhatsApp')}
                      >
                        <Phone className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                </div>
              </div>

              {/* Unit Asset Snapshot Summary */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/70 text-[11px] text-slate-600 flex justify-between items-center">
                <span>{t('Status Unit')}: <strong className="text-slate-800">{selectedAsset.status}</strong></span>
                <span>{t('Lokasi')}: <strong className="text-slate-800">{selectedAsset.location}</strong></span>
              </div>
            </div>

            {/* Bottom Panel Actions */}
            <div className="mt-5 pt-3 border-t border-slate-100 flex flex-col sm:flex-row gap-2 shrink-0">
              {/* Copy structured details */}
              <button
                type="button"
                onClick={() => handleCopyDetails(focusedBid, `${selectedAsset.brand} ${selectedAsset.name} (${selectedAsset.plateNumber})`)}
                className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer border ${
                  copiedState 
                    ? "bg-emerald-50 text-emerald-700 border-emerald-200" 
                    : "bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200/60"
                }`}
              >
                {copiedState ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                <span>{copiedState ? t('Berhasil Disalin!') : t('Salin Detail')}</span>
              </button>

              {/* WhatsApp direct contact */}
              {focusedBid.contact && focusedBid.contact !== '-' && (
                <a
                  href={`https://wa.me/${focusedBid.contact.replace(/\D/g, '').startsWith('0') ? '62' + focusedBid.contact.replace(/\D/g, '').slice(1) : focusedBid.contact.replace(/\D/g, '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm shadow-emerald-600/10 hover:shadow-emerald-600/20"
                >
                  <Phone className="w-4 h-4" />
                  <span>WhatsApp</span>
                </a>
              )}

              {/* Close Button */}
              <div className="flex flex-1 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm(t('Apakah Anda yakin ingin menghapus penawaran ini?'))) {
                      if (onDeleteBid) {
                        onDeleteBid(selectedAsset.id, focusedBid.id);
                      } else {
                        const updatedBids = selectedAsset.bids.filter(b => b.id !== focusedBid.id);
                        const highestBid = updatedBids.length > 0
                          ? Math.max(...updatedBids.map(b => b.price), selectedAsset.startingPrice)
                          : selectedAsset.startingPrice;
                        onUpdateAsset(selectedAsset.id, { 
                          bids: updatedBids,
                          highestBid: highestBid
                        });
                      }
                      setFocusedBid(null);
                    }
                  }}
                  className="flex-1 py-2.5 px-4 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-xl text-xs font-bold transition-all border border-rose-200 flex items-center justify-center gap-1.5 cursor-pointer shadow-3xs"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{t('Hapus Bid')}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFocusedBid(null)}
                  className="flex-1 py-2.5 px-5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition-all cursor-pointer text-center"
                >
                  {t('Tutup')}
                </button>
              </div>
            </div>
          </div>
        </div>
        );
      })()}

      {/* Manual Add Bid Modal */}
      {showAddBidModal && selectedAsset && (
        <div 
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-[120] flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setShowAddBidModal(false)}
        >
          <div 
            className="bg-white rounded-2xl border border-slate-100 shadow-2xl max-w-lg w-full p-6 relative overflow-hidden transition-all duration-300 animate-zoom-in"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-start mb-5 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-blue-50 rounded-xl text-blue-600">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 tracking-tight">
                    {t('Input Penawaran (Bid) Manual')}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {selectedAsset.brand} {selectedAsset.name} ({selectedAsset.plateNumber})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddBidModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {manualBidError && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs font-semibold text-rose-700 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{manualBidError}</span>
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!manualBidName.trim()) {
                  setManualBidError(t('Nama penawar wajib diisi.'));
                  return;
                }
                const priceNum = Number(manualBidPrice);
                if (!priceNum || isNaN(priceNum) || priceNum <= 0) {
                  setManualBidError(t('Nominal penawaran harus berupa angka valid di atas 0.'));
                  return;
                }

                // Combine date and time for timestamp
                let timestampIso = new Date().toISOString();
                if (manualBidDate && manualBidTime) {
                  const combinedDate = new Date(`${manualBidDate}T${manualBidTime}:00`);
                  if (!isNaN(combinedDate.getTime())) {
                    timestampIso = combinedDate.toISOString();
                  }
                }

                const newBidItem: Bid = {
                  id: `B-${Math.floor(100 + Math.random() * 900)}`,
                  name: manualBidName.trim(),
                  price: priceNum,
                  contact: manualBidContact.trim() || '-',
                  email: manualBidEmail.trim() || '-',
                  timestamp: timestampIso,
                  scheduleSurveyDate: manualBidSurveyDate || undefined,
                  scheduleSurveyTime: manualBidSurveyDate ? (manualBidSurveyTime || '09:00') : undefined
                };

                const updatedBids = [...(selectedAsset.bids || []), newBidItem];
                const highestBid = Math.max(...updatedBids.map(b => b.price), selectedAsset.startingPrice);

                onUpdateAsset(selectedAsset.id, {
                  bids: updatedBids,
                  highestBid: highestBid
                });

                setShowAddBidModal(false);
              }}
              className="space-y-4 text-xs"
            >
              <div>
                <label className="block font-bold text-slate-700 mb-1">{t('Nama Penawar')} *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Ricky Darmawan / PT Logistik"
                  value={manualBidName}
                  onChange={(e) => setManualBidName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">{t('Nominal Penawaran (IDR)')} *</label>
                <input
                  type="number"
                  required
                  placeholder="Contoh: 425600000"
                  value={manualBidPrice}
                  onChange={(e) => setManualBidPrice(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono font-bold text-blue-600"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Harga dasar: {formatIDR(selectedAsset.startingPrice)}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t('Nomor WhatsApp / HP')}</label>
                  <input
                    type="tel"
                    placeholder="081319000979"
                    value={manualBidContact}
                    onChange={(e) => setManualBidContact(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t('Email Penawar')}</label>
                  <input
                    type="email"
                    placeholder="info@perusahaan.com"
                    value={manualBidEmail}
                    onChange={(e) => setManualBidEmail(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium"
                  />
                </div>
              </div>

              {/* WAKTU BIDDING (TANGGAL & JAM INPUT) */}
              <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-100 space-y-2">
                <span className="font-bold text-blue-900 text-[11px] flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-blue-600" />
                  {t('Waktu Bidding Masuk (Tanggal & Jam)')}
                </span>
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[10px] text-slate-500 font-bold uppercase block mb-0.5">{t('Tanggal')}</label>
                    <input
                      type="date"
                      value={manualBidDate}
                      onChange={(e) => setManualBidDate(e.target.value)}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-medium focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-500 font-bold uppercase block mb-0.5">{t('Jam (WIB)')}</label>
                    <input
                      type="time"
                      value={manualBidTime}
                      onChange={(e) => setManualBidTime(e.target.value)}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-medium focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddBidModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition-all cursor-pointer"
                >
                  {t('Batal')}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-all cursor-pointer shadow-sm shadow-blue-600/20"
                >
                  {t('Simpan Penawaran')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Brand Master Data Management Modal */}
      {isBrandMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-blue-600" />
                  {t('Kelola Master Merek')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan merek yang ada.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsBrandMasterOpen(false);
                  setNewBrandName('');
                  setBrandError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content & List */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Form Input */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Merek Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Mitsubishi, Volvo')}
                    value={newBrandName}
                    onChange={(e) => {
                      setNewBrandName(e.target.value);
                      setBrandError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewBrand();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewBrand}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {brandError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {brandError}
                  </p>
                )}
              </div>

              {/* Brands List */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Merek Aktif')} ({brands.length})
                </label>
                
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {brands.length > 0 ? (
                    brands.map((brandObj) => (
                      <div key={brandObj.id} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                        <span className="text-sm font-semibold text-slate-800">{brandObj.name}</span>
                        <button
                          type="button"
                          onClick={() => handleDeleteBrand(brandObj.id)}
                          className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                          title={t('Hapus Merek')}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-slate-400 text-xs font-medium">
                      {t('Tidak ada data merek.')}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsBrandMasterOpen(false);
                  setNewBrandName('');
                  setBrandError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Category Master Data Management Modal */}
      {isCategoryMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-blue-600" />
                  {t('Kelola Master Kategori')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan kategori yang ada.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsCategoryMasterOpen(false);
                  setNewCategoryName('');
                  setCategoryError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content & List */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Form Input */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Kategori Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Trailer, Tronton, Box')}
                    value={newCategoryName}
                    onChange={(e) => {
                      setNewCategoryName(e.target.value);
                      setCategoryError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewCategory();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewCategory}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {categoryError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {categoryError}
                  </p>
                )}
              </div>

              {/* Categories List */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Kategori Aktif')} ({categories.length})
                </label>
                
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {categories.length > 0 ? (
                    categories.map((catObj) => (
                      <div key={catObj.id} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                        <span className="text-sm font-semibold text-slate-800">{catObj.name}</span>
                        <button
                          type="button"
                          onClick={() => handleDeleteCategory(catObj.id)}
                          className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                          title={t('Hapus Kategori')}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-slate-400 text-xs font-medium">
                      {t('Tidak ada data kategori.')}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsCategoryMasterOpen(false);
                  setNewCategoryName('');
                  setCategoryError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Condition Master Data Management Modal */}
      {isConditionMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-blue-600" />
                  {t('Kelola Master Kondisi')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan kondisi fisik yang ada.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsConditionMasterOpen(false);
                  setNewConditionName('');
                  setConditionError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content & List */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Form Input */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Kondisi Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Rusak Ringan, Rekondisi')}
                    value={newConditionName}
                    onChange={(e) => {
                      setNewConditionName(e.target.value);
                      setConditionError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewCondition();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewCondition}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {conditionError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {conditionError}
                  </p>
                )}
              </div>

              {/* Conditions List */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Kondisi Aktif')} ({conditions.length})
                </label>
                
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {conditions.length > 0 ? (
                    conditions.map((condObj) => (
                      <div key={condObj.id} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                        <span className="text-sm font-semibold text-slate-800">{condObj.name}</span>
                        <button
                          type="button"
                          onClick={() => handleDeleteCondition(condObj.id)}
                          className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                          title={t('Hapus Kondisi')}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-slate-400 text-xs font-medium">
                      {t('Tidak ada data kondisi.')}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsConditionMasterOpen(false);
                  setNewConditionName('');
                  setConditionError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Series Master Data Management Modal */}
      {isSeriesMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-blue-600" />
                  {t('Kelola Master Seri')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan seri kendaraan.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsSeriesMasterOpen(false);
                  setNewSeriesName('');
                  setSeriesError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content & List */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Form Input */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Seri Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: 500, GIGA, FL 260')}
                    value={newSeriesName}
                    onChange={(e) => {
                      setNewSeriesName(e.target.value);
                      setSeriesError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewSeries();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewSeries}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {seriesError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {seriesError}
                  </p>
                )}
              </div>

              {/* Series List */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Seri Aktif')} ({seriesList.length})
                </label>
                
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {seriesList.length > 0 ? (
                    seriesList.map((sObj) => (
                      <div key={sObj.id} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                        <span className="text-sm font-semibold text-slate-800">{sObj.name}</span>
                        <button
                          type="button"
                          onClick={() => handleDeleteSeries(sObj.id)}
                          className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                          title={t('Hapus Seri')}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-slate-400 text-xs font-medium">
                      {t('Tidak ada data seri.')}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsSeriesMasterOpen(false);
                  setNewSeriesName('');
                  setSeriesError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Colour Master Data Management Modal */}
      {isColourMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-blue-600" />
                  {t('Kelola Master Warna')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan warna kendaraan.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsColourMasterOpen(false);
                  setNewColourName('');
                  setColourError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content & List */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Form Input */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Warna Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Merah, Putih, Kuning')}
                    value={newColourName}
                    onChange={(e) => {
                      setNewColourName(e.target.value);
                      setColourError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewColour();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewColour}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {colourError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {colourError}
                  </p>
                )}
              </div>

              {/* Colours List */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Warna Aktif')} ({vehicleColours.length})
                </label>
                
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {vehicleColours.length > 0 ? (
                    vehicleColours.map((cObj) => (
                      <div key={cObj.id} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                        <span className="text-sm font-semibold text-slate-800">{cObj.name}</span>
                        <button
                          type="button"
                          onClick={() => handleDeleteColour(cObj.id)}
                          className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                          title={t('Hapus Warna')}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-slate-400 text-xs font-medium">
                      {t('Tidak ada data warna.')}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsColourMasterOpen(false);
                  setNewColourName('');
                  setColourError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fuel Master Data Management Modal */}
      {isFuelMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-blue-600" />
                  {t('Kelola Master Bahan Bakar')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan jenis bahan bakar.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsFuelMasterOpen(false);
                  setNewFuelName('');
                  setFuelError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content & List */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Form Input */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Bahan Bakar Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Solar, Diesel, Bensin')}
                    value={newFuelName}
                    onChange={(e) => {
                      setNewFuelName(e.target.value);
                      setFuelError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewFuel();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewFuel}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {fuelError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {fuelError}
                  </p>
                )}
              </div>

              {/* Fuel List */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Bahan Bakar Aktif')} ({fuelTypes.length})
                </label>
                
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {fuelTypes.length > 0 ? (
                    fuelTypes.map((fObj) => (
                      <div key={fObj.id} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                        <span className="text-sm font-semibold text-slate-800">{fObj.name}</span>
                        <button
                          type="button"
                          onClick={() => handleDeleteFuel(fObj.id)}
                          className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                          title={t('Hapus Bahan Bakar')}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-slate-400 text-xs font-medium">
                      {t('Tidak ada data bahan bakar.')}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsFuelMasterOpen(false);
                  setNewFuelName('');
                  setFuelError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Attachment Category Master Data Management Modal */}
      {isAttachmentMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-blue-600" />
                  {t('Kelola Master Jenis Gandengan')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan jenis gandengan.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsAttachmentMasterOpen(false);
                  setNewAttachmentName('');
                  setAttachmentError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content & List */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Form Input */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Jenis Gandengan Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Trailer, Box, Dump Body')}
                    value={newAttachmentName}
                    onChange={(e) => {
                      setNewAttachmentName(e.target.value);
                      setAttachmentError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewAttachment();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewAttachment}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {attachmentError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {attachmentError}
                  </p>
                )}
              </div>

              {/* Attachment Category List */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Jenis Gandengan Aktif')} ({attachmentCategories.length})
                </label>
                
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {attachmentCategories.length > 0 ? (
                    attachmentCategories.map((aObj) => (
                      <div key={aObj.id} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                        <span className="text-sm font-semibold text-slate-800">{aObj.name}</span>
                        <button
                          type="button"
                          onClick={() => handleDeleteAttachment(aObj.id)}
                          className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                          title={t('Hapus Jenis Gandengan')}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-slate-400 text-xs font-medium">
                      {t('Tidak ada data jenis gandengan.')}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsAttachmentMasterOpen(false);
                  setNewAttachmentName('');
                  setAttachmentError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Attachment Type Master Data Management Modal */}
      {isAttachmentTypeMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-blue-600" />
                  {t('Kelola Master Tipe Gandengan')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan tipe/model gandengan.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsAttachmentTypeMasterOpen(false);
                  setNewAttachmentTypeName('');
                  setAttachmentTypeError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content & List */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Form Input */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Tipe Gandengan Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Highbed 40, Skeleton 20')}
                    value={newAttachmentTypeName}
                    onChange={(e) => {
                      setNewAttachmentTypeName(e.target.value);
                      setAttachmentTypeError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewAttachmentType();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewAttachmentType}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {attachmentTypeError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {attachmentTypeError}
                  </p>
                )}
              </div>

              {/* Attachment Type List */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Tipe Gandengan Aktif')} ({attachmentTypes.length})
                </label>
                
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {attachmentTypes.length > 0 ? (
                    attachmentTypes.map((atObj) => (
                      <div key={atObj.id} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                        <span className="text-sm font-semibold text-slate-800">{atObj.name}</span>
                        <button
                          type="button"
                          onClick={() => handleDeleteAttachmentType(atObj.id)}
                          className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                          title={t('Hapus Tipe Gandengan')}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-slate-400 text-xs font-medium">
                      {t('Tidak ada data tipe gandengan.')}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsAttachmentTypeMasterOpen(false);
                  setNewAttachmentTypeName('');
                  setAttachmentTypeError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manifest Master Data Management Modal */}
      {isManifestMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-blue-600" />
                  {t('Kelola Master Manifest')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan status manifest secara manual.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsManifestMasterOpen(false);
                  setNewManifestName('');
                  setManifestError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content & List */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Form Input */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Pilihan Manifest Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Pake Manifest Khusus, Limbah B3')}
                    value={newManifestName}
                    onChange={(e) => {
                      setNewManifestName(e.target.value);
                      setManifestError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewManifest();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewManifest}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {manifestError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {manifestError}
                  </p>
                )}
              </div>

              {/* Manifests List */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Pilihan Manifest Aktif')} ({manifestOptions.length})
                </label>
                
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {manifestOptions.map((manifestText) => (
                    <div key={manifestText} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                      <span className="text-sm font-semibold text-slate-800">{t(manifestText)}</span>
                      <button
                        type="button"
                        onClick={() => handleDeleteManifest(manifestText)}
                        className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                        title={t('Hapus Pilihan Manifest')}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsManifestMasterOpen(false);
                  setNewManifestName('');
                  setManifestError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Used Part Sub-Categories Master Data Management Modal */}
      {isUsedPartSubCatMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-amber-600" />
                  {t('Kelola Sub-Kategori Suku Cadang')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus pilihan sub-kategori sparepart (Ban, Aki, Oli, Besi, dll).')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsUsedPartSubCatMasterOpen(false);
                  setNewUsedPartSubCatName('');
                  setUsedPartSubCatError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content & List */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Form Input */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Sub-Kategori Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Mesin, Transmisi, Filter, Gardan')}
                    value={newUsedPartSubCatName}
                    onChange={(e) => {
                      setNewUsedPartSubCatName(e.target.value);
                      setUsedPartSubCatError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewUsedPartSubCat();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewUsedPartSubCat}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {usedPartSubCatError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {usedPartSubCatError}
                  </p>
                )}
              </div>

              {/* Sub-Categories List */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Sub-Kategori Aktif')} ({usedPartSubCats.length})
                </label>
                
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {usedPartSubCats.map((catText) => (
                    <div key={catText} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                      <span className="text-sm font-semibold text-slate-800">{t(catText)}</span>
                      <button
                        type="button"
                        onClick={() => handleDeleteUsedPartSubCat(catText)}
                        className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                        title={t('Hapus Sub-Kategori')}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsUsedPartSubCatMasterOpen(false);
                  setNewUsedPartSubCatName('');
                  setUsedPartSubCatError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Master Sales System Modal */}
      {isSalesSystemMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-amber-600" />
                  {t('Kelola Master Sistem Penjualan')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan sistem penjualan.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsSalesSystemMasterOpen(false);
                  setNewSalesSystemName('');
                  setSalesSystemError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Sistem Penjualan Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Satuan, Borongan, Lelang Kilat')}
                    value={newSalesSystemName}
                    onChange={(e) => {
                      setNewSalesSystemName(e.target.value);
                      setSalesSystemError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewSalesSystem();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewSalesSystem}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {salesSystemError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {salesSystemError}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Pilihan Aktif')} ({salesSystemOptions.length})
                </label>
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {salesSystemOptions.map((item) => (
                    <div key={item} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                      <span className="text-sm font-semibold text-slate-800">{t(item)}</span>
                      <button
                        type="button"
                        onClick={() => handleDeleteSalesSystem(item)}
                        className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                        title={t('Hapus Pilihan')}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsSalesSystemMasterOpen(false);
                  setNewSalesSystemName('');
                  setSalesSystemError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Master Tire Type Modal */}
      {isTireTypeMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-amber-600" />
                  {t('Kelola Master Jenis Ban')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan jenis ban.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsTireTypeMasterOpen(false);
                  setNewTireTypeName('');
                  setTireTypeError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Jenis Ban Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Ban Tubeless, Ban Vulkanisir')}
                    value={newTireTypeName}
                    onChange={(e) => {
                      setNewTireTypeName(e.target.value);
                      setTireTypeError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewTireType();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewTireType}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {tireTypeError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {tireTypeError}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Pilihan Aktif')} ({tireTypeOptions.length})
                </label>
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {tireTypeOptions.map((item) => (
                    <div key={item} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                      <span className="text-sm font-semibold text-slate-800">{t(item)}</span>
                      <button
                        type="button"
                        onClick={() => handleDeleteTireType(item)}
                        className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                        title={t('Hapus Pilihan')}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsTireTypeMasterOpen(false);
                  setNewTireTypeName('');
                  setTireTypeError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Master Tire Rim Modal */}
      {isTireRimMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-amber-600" />
                  {t('Kelola Master Jenis Velg Truck')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan jenis velg.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsTireRimMasterOpen(false);
                  setNewTireRimName('');
                  setTireRimError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Jenis Velg Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Velg Heavy Duty Ring 24')}
                    value={newTireRimName}
                    onChange={(e) => {
                      setNewTireRimName(e.target.value);
                      setTireRimError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewTireRim();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewTireRim}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {tireRimError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {tireRimError}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Pilihan Aktif')} ({tireRimOptions.length})
                </label>
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {tireRimOptions.map((item) => (
                    <div key={item} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                      <span className="text-sm font-semibold text-slate-800">{t(item)}</span>
                      <button
                        type="button"
                        onClick={() => handleDeleteTireRim(item)}
                        className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                        title={t('Hapus Pilihan')}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsTireRimMasterOpen(false);
                  setNewTireRimName('');
                  setTireRimError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Master Tire Grade Modal */}
      {isTireGradeMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-amber-600" />
                  {t('Kelola Master Grade Ban')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan grade ban.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsTireGradeMasterOpen(false);
                  setNewTireGradeName('');
                  setTireGradeError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Grade Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Grade S, 4, 5, Bekas Layak')}
                    value={newTireGradeName}
                    onChange={(e) => {
                      setNewTireGradeName(e.target.value);
                      setTireGradeError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewTireGrade();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewTireGrade}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {tireGradeError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {tireGradeError}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Pilihan Aktif')} ({tireGradeOptions.length})
                </label>
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {tireGradeOptions.map((item) => (
                    <div key={item} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                      <span className="text-sm font-semibold text-slate-800">{t(item)}</span>
                      <button
                        type="button"
                        onClick={() => handleDeleteTireGrade(item)}
                        className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                        title={t('Hapus Pilihan')}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsTireGradeMasterOpen(false);
                  setNewTireGradeName('');
                  setTireGradeError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Master Metal Type Modal */}
      {isMetalTypeMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-amber-600" />
                  {t('Kelola Master Jenis Besi / Logam')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan jenis besi/logam.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsMetalTypeMasterOpen(false);
                  setNewMetalTypeName('');
                  setMetalTypeError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Jenis Besi/Logam Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Stainless Steel, Tembaga Murni')}
                    value={newMetalTypeName}
                    onChange={(e) => {
                      setNewMetalTypeName(e.target.value);
                      setMetalTypeError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewMetalType();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewMetalType}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {metalTypeError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {metalTypeError}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Pilihan Aktif')} ({metalTypeOptions.length})
                </label>
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {metalTypeOptions.map((item) => (
                    <div key={item} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                      <span className="text-sm font-semibold text-slate-800">{t(item)}</span>
                      <button
                        type="button"
                        onClick={() => handleDeleteMetalType(item)}
                        className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                        title={t('Hapus Pilihan')}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsMetalTypeMasterOpen(false);
                  setNewMetalTypeName('');
                  setMetalTypeError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Master Metal Sales Method Modal */}
      {isMetalSalesMethodMasterOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-amber-600" />
                  {t('Kelola Master Metode Penjualan Besi')}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t('Tambah atau hapus daftar pilihan metode penjualan besi.')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsMetalSalesMethodMasterOpen(false);
                  setNewMetalSalesMethodName('');
                  setMetalSalesMethodError('');
                }}
                className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 uppercase block">
                  {t('Tambah Metode Penjualan Baru')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t('Contoh: Penimbangan Ritase, Lelang Tertutup')}
                    value={newMetalSalesMethodName}
                    onChange={(e) => {
                      setNewMetalSalesMethodName(e.target.value);
                      setMetalSalesMethodError('');
                    }}
                    className="flex-1 px-3.5 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddNewMetalSalesMethod();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddNewMetalSalesMethod}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl text-sm shadow-sm transition flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    {t('Tambah')}
                  </button>
                </div>
                {metalSalesMethodError && (
                  <p className="text-rose-500 text-xs font-medium flex items-center gap-1 mt-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    {metalSalesMethodError}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase block">
                  {t('Daftar Pilihan Aktif')} ({metalSalesMethodOptions.length})
                </label>
                <div className="border border-slate-100 rounded-2xl divide-y divide-slate-100 overflow-hidden max-h-[35vh] overflow-y-auto">
                  {metalSalesMethodOptions.map((item) => (
                    <div key={item} className="flex items-center justify-between p-3.5 hover:bg-slate-50 transition">
                      <span className="text-sm font-semibold text-slate-800">{t(item)}</span>
                      <button
                        type="button"
                        onClick={() => handleDeleteMetalSalesMethod(item)}
                        className="text-slate-400 hover:text-rose-600 p-1.5 hover:bg-rose-50 rounded-lg transition"
                        title={t('Hapus Pilihan')}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsMetalSalesMethodMasterOpen(false);
                  setNewMetalSalesMethodName('');
                  setMetalSalesMethodError('');
                }}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-semibold rounded-xl text-sm hover:bg-slate-100 transition shadow-sm"
              >
                {t('Tutup')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Official Winner Letter Modal */}
      {selectedWinnerLetterAsset && (
        <OfficialWinnerLetterModal
          asset={selectedWinnerLetterAsset}
          onClose={() => setSelectedWinnerLetterAsset(null)}
          formatIDR={formatIDR}
        />
      )}

    </div>
  );
}
