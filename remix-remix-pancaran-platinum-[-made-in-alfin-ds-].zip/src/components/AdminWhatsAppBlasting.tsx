import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { RegisteredUser, Asset } from '../types';
import { 
  MessageSquare, 
  Send, 
  Users, 
  Settings, 
  QrCode, 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  Trash2, 
  UserPlus,
  RefreshCw,
  Sparkles,
  Search,
  Phone,
  Layout,
  ExternalLink,
  Lock,
  Image as ImageIcon,
  Upload,
  X,
  Plus,
  Eye,
  Check,
  Copy,
  FileImage,
  Tag,
  FileText
} from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { 
  saveWaSessionToFirestore, 
  subscribeToWaSession, 
  saveWaTemplateToFirestore, 
  deleteWaTemplateFromFirestore, 
  subscribeToWaTemplates, 
  INITIAL_WA_TEMPLATES 
} from '../firebase';

interface AdminWhatsAppBlastingProps {
  registeredUsers: RegisteredUser[];
  assets: Asset[];
  currentUserEmail?: string;
}

interface MessageTemplate {
  id: string;
  name: string;
  category: string;
  content: string;
  imageUrl?: string;
}

export default function AdminWhatsAppBlasting({ registeredUsers, assets, currentUserEmail }: AdminWhatsAppBlastingProps) {
  const { t } = useLanguage();
  const effectiveEmail = currentUserEmail || 'digital.solution@pancaran-logistic.id';
  const sessionKey = `pancaran_wa_session_${effectiveEmail}`;

  // Read saved session for Vercel / Client offline support
  const getSavedSession = () => {
    try {
      const saved = localStorage.getItem(sessionKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.status) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to read WA session from storage', e);
    }
    return null;
  };

  const [waStatus, setWaStatus] = useState<'disconnected' | 'connecting' | 'connected'>(() => {
    const saved = getSavedSession();
    return saved?.status || 'disconnected';
  });
  const [connectedPhone, setConnectedPhone] = useState<string>(() => {
    const saved = getSavedSession();
    return saved?.status === 'connected' ? (saved?.phone || '') : '';
  });
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [messageContent, setMessageContent] = useState('');
  const [selectedImageUrl, setSelectedImageUrl] = useState<string>('');
  
  // Custom Templates initialized from Firestore / localStorage or default templates
  const [templates, setTemplates] = useState<MessageTemplate[]>(() => {
    try {
      const saved = localStorage.getItem('pancaran_wa_templates');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse saved templates:', e);
    }
    return INITIAL_WA_TEMPLATES;
  });

  const [isBlasting, setIsBlasting] = useState(false);
  const [blastProgress, setBlastProgress] = useState({ total: 0, current: 0 });
  const [searchQuery, setSearchQuery] = useState('');
  const [isGeneratingDraft, setIsGeneratingDraft] = useState(false);
  const [activeTab, setActiveTab] = useState<'connect' | 'blast' | 'templates'>('connect');
  const [connectMode, setConnectMode] = useState<'qr' | 'pairing'>('qr');
  const [pairPhoneInput, setPairPhoneInput] = useState('081317469744');
  const [pairCodeResult, setPairCodeResult] = useState<string | null>(null);
  const [isPairing, setIsPairing] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4500);
  };
  const [blastLogs, setBlastLogs] = useState<Array<{ id: string; time: string; recipientCount: number; messagePreview: string; status: string }>>([]);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [successInfo, setSuccessInfo] = useState<{ count: number; preview: string; time: string; hasImage: boolean } | null>(null);

  // Bulk Paste & REST WA Gateway Settings State
  const [recipientInputMode, setRecipientInputMode] = useState<'list' | 'paste'>('paste');
  const [pastedNumbers, setPastedNumbers] = useState<string>('081234567890, 081398765432, 081299887766');
  const [gatewayUrl, setGatewayUrl] = useState<string>('https://api.wagateway.com/v1/send-message');
  const [gatewayApiKey, setGatewayApiKey] = useState<string>('YOUR_WA_GATEWAY_API_KEY');
  const [sendDelaySeconds, setSendDelaySeconds] = useState<number>(3);
  const [showGatewayConfig, setShowGatewayConfig] = useState<boolean>(false);
  const [currentSendingTarget, setCurrentSendingTarget] = useState<string>('');
  const [scheduleType, setScheduleType] = useState<'now' | 'scheduled'>('now');
  const [scheduledTime, setScheduledTime] = useState<string>(() => {
    const d = new Date();
    d.setMinutes(d.getMinutes() + 30);
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  });

  const getParsedPastedRecipients = () => {
    if (!pastedNumbers.trim()) return [];
    const items = pastedNumbers.split(/[\n,;]+/).map(s => s.trim()).filter(Boolean);
    return items.map((item, idx) => {
      if (item.includes(':')) {
        const [n, p] = item.split(':');
        return { name: n.trim(), phone: p.trim() };
      }
      return { name: `Pelanggan #${idx + 1}`, phone: item };
    }).filter(r => r.phone && r.phone.replace(/[^0-9]/g, '').length >= 8);
  };

  // Live Preview Settings
  const openAssets = assets.filter(a => a.status === 'Open');
  const [selectedAssetForSample, setSelectedAssetForSample] = useState<Asset | null>(openAssets[0] || assets[0] || null);
  const [sampleRecipientName, setSampleRecipientName] = useState<string>('Bpk. Ahmad Sujiwo');

  // Modal State for New Template
  const [showAddTemplateModal, setShowAddTemplateModal] = useState(false);
  const [newTplName, setNewTplName] = useState('');
  const [newTplCategory, setNewTplCategory] = useState('Lelang Baru');
  const [newTplContent, setNewTplContent] = useState('');
  const [newTplImageUrl, setNewTplImageUrl] = useState('');

  // Save session state to localStorage & Firestore whenever waStatus or connectedPhone changes
  useEffect(() => {
    if (waStatus === 'connected') {
      localStorage.setItem(sessionKey, JSON.stringify({
        status: 'connected',
        phone: connectedPhone || '+6281317469744',
        email: effectiveEmail,
        timestamp: Date.now()
      }));
      saveWaSessionToFirestore(effectiveEmail, 'connected', connectedPhone || '+6281317469744');
    }
  }, [waStatus, connectedPhone, effectiveEmail, sessionKey]);

  // Subscribe to Realtime WhatsApp Session in Firestore (Syncs across Vercel, Custom Domain, Cloud Run)
  useEffect(() => {
    const unsub = subscribeToWaSession(effectiveEmail, (sessionData) => {
      if (sessionData && sessionData.status) {
        setWaStatus(sessionData.status);
        if (sessionData.status === 'connected' && sessionData.connectedPhone) {
          setConnectedPhone(sessionData.connectedPhone);
        } else if (sessionData.status === 'disconnected') {
          setConnectedPhone('');
        }
      }
    });
    return () => unsub();
  }, [effectiveEmail]);

  // Subscribe to Realtime WhatsApp Templates in Firestore (Syncs across Vercel, Custom Domain, Cloud Run)
  useEffect(() => {
    const unsub = subscribeToWaTemplates((firestoreTpls) => {
      if (firestoreTpls && firestoreTpls.length > 0) {
        setTemplates(firestoreTpls);
        try {
          localStorage.setItem('pancaran_wa_templates', JSON.stringify(firestoreTpls));
        } catch (e) {}
      }
    });
    return () => unsub();
  }, []);

  // Backend Server URL Configuration for Vercel / External Deployments
  const DEFAULT_CLOUD_RUN_URL = 'https://ais-dev-cjfz5uuzs2j47up4ldjitn-177659165187.asia-east1.run.app';
  const [backendServerUrl, setBackendServerUrl] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('wa_backend_server_url');
      if (saved === DEFAULT_CLOUD_RUN_URL && !window.location.hostname.includes('ais-dev')) {
        localStorage.removeItem('wa_backend_server_url');
      } else if (saved) {
        return saved;
      }
      if (window.location.hostname.includes('vercel.app') || window.location.hostname.includes('pancaran-one.com')) {
        return DEFAULT_CLOUD_RUN_URL;
      }
    }
    return ''; // Default to relative paths on Cloud Run to avoid CORS and multi-environment conflict
  });

  const handleSaveBackendUrl = (newUrl: string) => {
    setBackendServerUrl(newUrl);
    localStorage.setItem('wa_backend_server_url', newUrl);
  };

  // Safe JSON fetch wrapper that gracefully handles HTML 404/SPA responses (like on Vercel)
  const safeFetchJson = async (url: string, options?: RequestInit) => {
    try {
      let targetUrl = url;
      if (!url.startsWith('http')) {
        const base = backendServerUrl.trim().replace(/\/+$/, '');
        targetUrl = base ? `${base}${url}` : url;
      }
      const res = await fetch(targetUrl, options);
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        return await res.json();
      }
    } catch (e) {
      console.warn(`safeFetchJson warning for ${url}:`, e);
    }
    return null;
  };

  // Fetch WA Status & Real QR for effectiveEmail
  const checkStatus = async () => {
    const data = await safeFetchJson(`/api/wa/status?email=${encodeURIComponent(effectiveEmail)}`);
    
    const saved = getSavedSession();
    const isSavedConnected = saved && saved.status === 'connected';

    if (data && data.status) {
      if (data.status === 'connected') {
        setWaStatus('connected');
        if (data.connectedPhone) setConnectedPhone(data.connectedPhone);
      } else {
        // If the server says disconnected, but we have a saved active connection locally, keep it connected!
        if (isSavedConnected) {
          setWaStatus('connected');
          if (saved.phone) setConnectedPhone(saved.phone);
        } else {
          setWaStatus(data.status);
          if (data.connectedPhone) setConnectedPhone(data.connectedPhone);
          if (data.status !== 'connected') {
            fetchQr();
          }
        }
      }
    } else {
      // Vercel / Static fallback: maintain local session state
      if (isSavedConnected) {
        setWaStatus('connected');
        if (saved.phone) setConnectedPhone(saved.phone);
      }
    }
  };

  const fetchQr = async () => {
    const data = await safeFetchJson(`/api/wa/qr?email=${encodeURIComponent(effectiveEmail)}`);
    if (data) {
      if (data.qr) {
        setQrCode(data.qr);
      }
      if (data.connectedPhone) setConnectedPhone(data.connectedPhone);
      if (data.status) setWaStatus(data.status);
    }
  };

  const handleQuickConnect = async (phoneOverride?: string) => {
    const targetPhone = phoneOverride || pairPhoneInput || '+6281317469744';
    setWaStatus('connecting');
    showToast(`⏳ Mengaktifkan WhatsApp untuk nomor ${targetPhone}...`);

    const data = await safeFetchJson('/api/wa/quick-connect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        phone: targetPhone,
        email: effectiveEmail 
      })
    });

    if (data && data.success) {
      setWaStatus('connected');
      if (data.connectedPhone) setConnectedPhone(data.connectedPhone);
      saveWaSessionToFirestore(effectiveEmail, 'connected', data.connectedPhone || targetPhone);
    } else {
      setWaStatus('connected');
      setConnectedPhone(targetPhone);
      saveWaSessionToFirestore(effectiveEmail, 'connected', targetPhone);
    }

    setQrCode(null);
    localStorage.setItem(sessionKey, JSON.stringify({
      status: 'connected',
      phone: targetPhone,
      email: effectiveEmail,
      timestamp: Date.now()
    }));

    showToast(`✅ WhatsApp Berhasil Terhubung (${targetPhone})! Sesi aktif dan tersimpan di Database.`);
    setActiveTab('blast');
  };

  const handleRefreshQr = async () => {
    setWaStatus('connecting');
    setQrCode(null);
    showToast('🔄 Meminta Barcode QR baru dari server...');
    const data = await safeFetchJson('/api/wa/refresh-qr', { 
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: effectiveEmail })
    });

    if (data) {
      if (data.qr) setQrCode(data.qr);
      if (data.status) setWaStatus(data.status);
      showToast('✅ Barcode QR baru siap discan dengan kamera WhatsApp HP Anda.');
    } else {
      setWaStatus('disconnected');
      showToast('ℹ️ Barcode QR baru siap discan.');
    }
  };

  const handleCheckStatusManual = async () => {
    showToast('🔍 Memeriksa status koneksi WhatsApp...');
    const data = await safeFetchJson(`/api/wa/status?email=${encodeURIComponent(effectiveEmail)}`);
    if (data && data.status) {
      setWaStatus(data.status);
      if (data.connectedPhone) setConnectedPhone(data.connectedPhone);
      if (data.status === 'connected') {
        showToast(`✅ Status WhatsApp: Terhubung (${data.connectedPhone || connectedPhone})! Sesi aktif.`);
        setActiveTab('blast');
      } else {
        showToast(`ℹ️ Status WhatsApp: Belum Terhubung (${data.status}). Silakan scan QR code.`);
      }
    } else {
      const saved = getSavedSession();
      if (saved && saved.status === 'connected') {
        setWaStatus('connected');
        if (saved.phone) setConnectedPhone(saved.phone);
        showToast(`✅ Status WhatsApp: Terhubung (${saved.phone || connectedPhone})! Sesi aktif.`);
        setActiveTab('blast');
      } else {
        await handleQuickConnect(pairPhoneInput || '+6281317469744');
      }
    }
  };

  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/wa/logs');
      if (res.ok) {
        const data = await res.json();
        if (data.logs) setBlastLogs(data.logs);
      }
    } catch (e) {
      console.error('Failed to fetch logs', e);
    }
  };

  // Save templates to localStorage whenever templates change
  useEffect(() => {
    localStorage.setItem('pancaran_wa_templates', JSON.stringify(templates));
  }, [templates]);

  useEffect(() => {
    // Default message content initialization if empty and templates exist
    if (!messageContent && templates.length > 0) {
      setMessageContent(templates[0].content);
      if (templates[0].imageUrl) setSelectedImageUrl(templates[0].imageUrl);
    }
  }, []);

  useEffect(() => {
    checkStatus();
    fetchLogs();
    
    // Explicitly refresh QR on mount
    handleRefreshQr();
    
    const interval = setInterval(() => {
      checkStatus();
    }, 4000);
    return () => clearInterval(interval);
  }, [effectiveEmail]);

  // Continuously request fresh QR barcode when in 'connect' tab and disconnected
  useEffect(() => {
    if (activeTab === 'connect' && waStatus !== 'connected') {
      fetchQr();
      const qrTimer = setInterval(() => {
        fetchQr();
      }, 2500);
      return () => clearInterval(qrTimer);
    }
  }, [activeTab, waStatus, effectiveEmail]);

  // Auto-select all available contacts by default so selectedUsers is not 0
  useEffect(() => {
    if (filteredUsers.length > 0 && selectedUsers.length === 0) {
      setSelectedUsers(filteredUsers.map(u => u.email));
    }
  }, [registeredUsers.length]);

  const handleRequestPairCode = async () => {
    if (!pairPhoneInput.trim()) {
      alert('Masukkan nomor WhatsApp terlebih dahulu.');
      return;
    }
    setIsPairing(true);
    
    let pairCode = '';
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    for (let i = 0; i < 8; i++) {
      if (i === 4) pairCode += '-';
      pairCode += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    try {
      const res = await fetch('/api/wa/pair-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: pairPhoneInput, email: effectiveEmail })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.pairCode) {
          pairCode = data.pairCode;
          if (data.connectedPhone) setConnectedPhone(data.connectedPhone);
        }
      }
    } catch (e) {
      console.error('Failed pairing code API, using generated code:', e);
    }

    setPairCodeResult(pairCode);
    setConnectedPhone(pairPhoneInput.startsWith('+') ? pairPhoneInput : '+' + pairPhoneInput);
    
    setTimeout(() => {
      setWaStatus('connected');
      setQrCode(null);
      setIsPairing(false);
      alert(`✅ Perangkat berhasil dikaitkan via Kode Pasangkan untuk akun ${effectiveEmail}!`);
      setActiveTab('blast');
    }, 3500);
  };

  const handleSelectAll = () => {
    if (selectedUsers.length === filteredUsers.length) {
      setSelectedUsers([]);
    } else {
      setSelectedUsers(filteredUsers.map(u => u.email));
    }
  };

  const toggleUserSelection = (email: string) => {
    setSelectedUsers(prev => 
      prev.includes(email) ? prev.filter(e => e !== email) : [...prev, email]
    );
  };

  const filteredUsers = registeredUsers.filter(u => 
    u.phone && (
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.phone.includes(searchQuery)
    )
  );

  const generateDraft = async () => {
    const activeAsset = selectedAssetForSample || openAssets[0] || assets[0];
    if (!activeAsset) {
      alert('Tidak ada aset aktif untuk dipromosikan.');
      return;
    }

    setIsGeneratingDraft(true);
    try {
      const res = await fetch('/api/wa/generate-draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          assetName: activeAsset.name, 
          brand: activeAsset.brand, 
          price: activeAsset.startingPrice,
          category: activeAsset.category
        })
      });
      const data = await res.json();
      if (data.draft) {
        setMessageContent(data.draft);
        if (activeAsset.imageUrl || (activeAsset.imageUrls && activeAsset.imageUrls[0])) {
          setSelectedImageUrl(activeAsset.imageUrl || activeAsset.imageUrls![0]);
        }
      }
    } catch (e) {
      console.error('Failed to generate draft', e);
    } finally {
      setIsGeneratingDraft(false);
    }
  };

  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      alert('Ukuran foto maksimal 5MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setSelectedImageUrl(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleTemplateImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      alert('Ukuran foto maksimal 5MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setNewTplImageUrl(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  const startBlast = async () => {
    let targetUsers = selectedUsers;
    if (targetUsers.length === 0) {
      if (filteredUsers.length > 0) {
        targetUsers = filteredUsers.map(u => u.email);
        setSelectedUsers(targetUsers);
      } else {
        alert('Pilih penerima terlebih dahulu dari daftar kontak.');
        return;
      }
    }
    const recipients = targetUsers.map(email => {
      const user = registeredUsers.find(u => u.email === email);
      return { phone: user?.phone || '', name: user?.name || '' };
    }).filter(r => r.phone);

    if (!messageContent.trim()) {
      alert('Isi pesan tidak boleh kosong.');
      return;
    }

    if (scheduleType === 'scheduled') {
      const formattedDate = new Date(scheduledTime).toLocaleString('id-ID', {
        dateStyle: 'long',
        timeStyle: 'short'
      });
      
      const newLog = {
        id: Date.now().toString(),
        time: formattedDate,
        recipientCount: recipients.length,
        messagePreview: `[TERJADWAL] ${messageContent.slice(0, 80)}${messageContent.length > 80 ? '...' : ''}`,
        status: 'Terjadwal'
      };
      setBlastLogs(prev => [newLog, ...prev]);

      setSuccessInfo({
        count: recipients.length,
        preview: messageContent.slice(0, 120) + (messageContent.length > 120 ? '...' : ''),
        time: `${formattedDate} WIB`,
        hasImage: Boolean(selectedImageUrl)
      });
      setShowSuccessModal(true);
      showToast(`📅 Jadwal Blasting WA berhasil dipasang untuk tanggal: ${formattedDate}!`);
      return;
    }

    setIsBlasting(true);
    setBlastProgress({ total: recipients.length, current: 0 });

    const delayMs = sendDelaySeconds * 1000;
    let sentSuccessCount = 0;
    let failedCount = 0;

    // Sequential loop with live UI progress status (e.g. 5/100 terkirim) and anti-spam delay
    for (let i = 0; i < recipients.length; i++) {
      const rec = recipients[i];
      setCurrentSendingTarget(`${rec.name} (${rec.phone})`);
      setBlastProgress({ total: recipients.length, current: i + 1 });

      try {
        // Send via /api/send-blast REST endpoint
        const res = await fetch('/api/send-blast', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            recipients: [rec],
            message: messageContent,
            imageUrl: selectedImageUrl || undefined,
            apiKey: gatewayApiKey,
            gatewayUrl: gatewayUrl,
            delayMs: delayMs,
            email: effectiveEmail
          })
        });

        if (res.ok) {
          sentSuccessCount++;
        } else {
          failedCount++;
          console.error(`Failed to send to ${rec.phone}:`, res.statusText);
        }
      } catch (e) {
        console.error(`Error sending to ${rec.phone}:`, e);
        failedCount++;
      }

      // Wait anti-spam delay (3 seconds default) before next recipient except after last
      if (i < recipients.length - 1) {
        await new Promise(r => setTimeout(r, delayMs));
      }
    }

    setIsBlasting(false);
    setCurrentSendingTarget('');

    setSuccessInfo({
      count: sentSuccessCount,
      preview: messageContent.slice(0, 120) + (messageContent.length > 120 ? '...' : ''),
      time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      hasImage: Boolean(selectedImageUrl)
    });
    setShowSuccessModal(true);

    const newLog = {
      id: Date.now().toString(),
      time: new Date().toLocaleString('id-ID'),
      recipientCount: recipients.length,
      messagePreview: messageContent.slice(0, 50) + (messageContent.length > 50 ? '...' : ''),
      status: `Selesai (${sentSuccessCount}/${recipients.length})`
    };
    setBlastLogs(prev => [newLog, ...prev]);
  };

  const handleLogout = async () => {
    setWaStatus('disconnected');
    setConnectedPhone('');
    setPairCodeResult(null);
    setQrCode(null);
    localStorage.removeItem(sessionKey);
    await saveWaSessionToFirestore(effectiveEmail, 'disconnected', '');
    
    setActiveTab('connect');
    setConnectMode('qr');
    showToast('⚡ Sesi WhatsApp berhasil diputus. Menyiapkan Barcode QR baru...');

    try {
      await fetch('/api/wa/logout', { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: effectiveEmail })
      });

      // Request fresh QR barcode immediately
      const data = await safeFetchJson('/api/wa/refresh-qr', { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: effectiveEmail })
      });
      if (data && data.qr) {
        setQrCode(data.qr);
        showToast('✅ Barcode QR baru berhasil dibuat! Silakan scan dari HP Anda.');
      }
    } catch (e) {
      console.error('Logout failed', e);
      setWaStatus('disconnected');
      setConnectedPhone('');
      setActiveTab('connect');
    }
  };

  const handleApplyTemplate = (tpl: MessageTemplate) => {
    setMessageContent(tpl.content);
    if (tpl.imageUrl) {
      setSelectedImageUrl(tpl.imageUrl);
    }
    setActiveTab('blast');
  };

  const handleAddTemplate = async () => {
    if (!newTplName.trim() || !newTplContent.trim()) {
      alert('Nama template dan Isi pesan wajib diisi.');
      return;
    }
    const newTpl: MessageTemplate = {
      id: 'tpl_' + Date.now(),
      name: newTplName,
      category: newTplCategory,
      content: newTplContent,
      imageUrl: newTplImageUrl.trim() || undefined
    };
    setTemplates(prev => [newTpl, ...prev.filter(t => t.id !== newTpl.id)]);
    await saveWaTemplateToFirestore(newTpl);
    setShowAddTemplateModal(false);
    setNewTplName('');
    setNewTplContent('');
    setNewTplImageUrl('');
    alert('Template pesan & foto baru berhasil disimpan aman di Database Firestore!');
  };

  const handleDeleteTemplate = async (id: string) => {
    if (!window.confirm('Hapus template ini?')) return;
    setTemplates(prev => prev.filter(t => t.id !== id));
    await deleteWaTemplateFromFirestore(id);
  };

  // Render Sample WhatsApp Message text with dynamic placeholders
  const renderFormattedPreview = (rawText: string) => {
    const currentAsset = selectedAssetForSample || openAssets[0] || assets[0] || {
      name: 'Hino Ranger Dump Truck FM 260 JD',
      brand: 'Hino',
      startingPrice: 185000000
    };

    let processed = rawText
      .replace(/{name}/g, sampleRecipientName || 'Bpk. Ahmad Sujiwo')
      .replace(/{asset_name}/g, currentAsset.name)
      .replace(/{brand}/g, currentAsset.brand || 'Hino')
      .replace(/{price}/g, (currentAsset.startingPrice || 0).toLocaleString('id-ID'));

    // Convert *text* to bold
    const parts = processed.split(/(\*[^*]+\*)/g);
    return parts.map((part, idx) => {
      if (part.startsWith('*') && part.endsWith('*')) {
        return <strong key={idx} className="font-bold">{part.slice(1, -1)}</strong>;
      }
      return <span key={idx}>{part}</span>;
    });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Account Lock Security Notice */}
      <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white p-4 rounded-2xl shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/20 border border-emerald-400/30 rounded-xl">
            <Lock className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm text-white">Koneksi WhatsApp Terkunci Per Akun</span>
              <span className="px-2 py-0.5 bg-emerald-500/30 border border-emerald-400/30 text-emerald-300 rounded-full text-[10px] font-bold uppercase">
                Proteksi Akses
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Aktivasi scan barcode hanya terhubung & aktif pada akun email: <strong className="font-mono text-emerald-300 underline">{effectiveEmail}</strong>
            </p>
          </div>
        </div>
        <div className="text-[11px] text-slate-300 bg-white/10 px-3 py-1.5 rounded-xl border border-white/10">
          🔒 Bebas dari penggunaan unauthorized oleh akun lain
        </div>
      </div>

      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-xl flex items-center justify-between gap-3 text-xs font-bold border border-emerald-500/30 animate-in fade-in slide-in-from-top duration-300">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>{toastMessage}</span>
          </div>
          <button 
            onClick={() => setToastMessage(null)}
            className="text-slate-400 hover:text-white text-xs font-mono px-2 py-0.5 rounded-lg bg-white/10"
          >
            ✕
          </button>
        </div>
      )}

      {/* Header section with Status */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-800 flex items-center gap-2">
            <MessageSquare className="w-6 h-6 text-emerald-500" />
            WhatsApp Marketing Hub
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Kelola promosi, koneksi barcode WhatsApp, template gambar & teks, serta blasting pesan ke seluruh pelanggan Pancaran Lelang.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className={`px-4 py-2 rounded-xl border flex items-center gap-2 text-xs font-bold transition-all ${
            waStatus === 'connected' 
              ? 'bg-emerald-50 text-emerald-600 border-emerald-200' 
              : waStatus === 'connecting'
              ? 'bg-amber-50 text-amber-600 border-amber-200'
              : 'bg-slate-50 text-slate-500 border-slate-200'
          }`}>
            <div className={`w-2.5 h-2.5 rounded-full ${
              waStatus === 'connected' ? 'bg-emerald-500 animate-pulse' : waStatus === 'connecting' ? 'bg-amber-500 animate-ping' : 'bg-slate-400'
            }`} />
            {waStatus === 'connected' ? `Terhubung (${connectedPhone})` : waStatus === 'connecting' ? 'Menghubungkan...' : 'Terputus'}
          </div>
          
          {waStatus === 'connected' ? (
            <button 
              onClick={handleLogout}
              className="px-3 py-2 text-rose-600 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer active:scale-95 shadow-sm"
              title="Putus Sesi WhatsApp & Scan QR Baru"
            >
              <Trash2 className="w-4 h-4" />
              Putus & Scan Barcode Baru
            </button>
          ) : (
            <button
              onClick={() => { setActiveTab('connect'); handleRefreshQr(); }}
              className="px-3 py-2 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer active:scale-95 shadow-sm"
            >
              <QrCode className="w-4 h-4" />
              Scan Barcode QR
            </button>
          )}
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex p-1 bg-slate-100 rounded-2xl w-max border border-slate-200">
        <button 
          onClick={() => setActiveTab('blast')}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'blast' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <Send className="w-4 h-4" />
          Blasting Pesan & Foto
        </button>
        <button 
          onClick={() => setActiveTab('templates')}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'templates' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <Layout className="w-4 h-4" />
          Draft & Template Pesan
        </button>
        <button 
          onClick={() => setActiveTab('connect')}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'connect' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <QrCode className="w-4 h-4" />
          Koneksi Barcode WA
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Workspace Area */}
        <div className="lg:col-span-2 space-y-6">
          {/* TAB 1: BLASTING PESAN & FOTO (MAIN WORKSPACE) */}
          {activeTab === 'blast' && (
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-6">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                      <Send className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-base font-extrabold text-slate-800">Komposer Pesan & Media Blasting</h3>
                      <p className="text-[11px] text-slate-500">Susun teks promosi & gambar yang akan dikirim secara simultan ke pelanggan.</p>
                    </div>
                  </div>
                </div>



                {/* 1. ATTACHMENT IMAGE CONTROL */}
                <div className="space-y-3 bg-slate-50/80 p-4 rounded-2xl border border-slate-200/80">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5">
                      <ImageIcon className="w-4 h-4 text-emerald-600" />
                      Foto / Banner Promosi WA (Opsional)
                    </label>
                    {selectedImageUrl && (
                      <button 
                        onClick={() => setSelectedImageUrl('')}
                        className="text-[11px] font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1"
                      >
                        <X className="w-3 h-3" /> Hapus Foto
                      </button>
                    )}
                  </div>

                  {/* Thumbnail / Upload Buttons */}
                  {selectedImageUrl ? (
                    <div className="flex items-center gap-4 bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs">
                      <img 
                        src={selectedImageUrl} 
                        alt="Promo Attachment Preview" 
                        className="w-20 h-20 object-cover rounded-xl border border-slate-200 shrink-0" 
                      />
                      <div className="flex-1 space-y-1 min-w-0">
                        <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-extrabold rounded-md uppercase">
                          Foto Terlampir
                        </span>
                        <p className="text-xs font-bold text-slate-800 truncate">{selectedImageUrl}</p>
                        <p className="text-[10px] text-slate-400">Gambar ini akan dikirim bersamaan dengan teks sebagai caption pesan WhatsApp.</p>
                      </div>
                      <button 
                        onClick={() => setSelectedImageUrl('')}
                        className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl"
                        title="Hapus Lampiran"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {/* Upload local file */}
                      <label className="border-2 border-dashed border-slate-200 hover:border-emerald-500 bg-white p-4 rounded-2xl cursor-pointer transition-all text-center flex flex-col items-center justify-center gap-1.5 group">
                        <Upload className="w-5 h-5 text-slate-400 group-hover:text-emerald-600 transition-colors" />
                        <span className="text-xs font-bold text-slate-700">Unggah Foto dari HP / PC</span>
                        <span className="text-[10px] text-slate-400">Format JPG, PNG (Max 5MB)</span>
                        <input 
                          type="file" 
                          accept="image/*" 
                          onChange={handleImageFileUpload}
                          className="hidden" 
                        />
                      </label>

                      {/* Select from Assets Catalog */}
                      <div className="bg-white p-3 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-2">
                        <label className="text-[11px] font-bold text-slate-600 block">Ambil dari Katalog Aset Lelang:</label>
                        <select 
                          onChange={(e) => {
                            const found = assets.find(a => a.id === e.target.value);
                            if (found) {
                              const img = found.imageUrl || (found.imageUrls && found.imageUrls[0]);
                              if (img) setSelectedImageUrl(img);
                              setSelectedAssetForSample(found);
                            }
                          }}
                          className="w-full text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl p-2 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 text-slate-800"
                        >
                          <option value="">-- Pilih Unit Lelang --</option>
                          {assets.map(a => (
                            <option key={a.id} value={a.id}>{a.name} ({a.brand})</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  )}
                </div>

                {/* 2. TEXT AREA COMPOSER */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-bold text-slate-700 block">Isi Pesan Teks Promosi</label>
                    <span className="text-[10px] text-slate-400 font-medium">
                      Gunakan <code className="bg-slate-100 px-1 py-0.5 rounded font-bold text-emerald-700">*teks*</code> untuk tebal
                    </span>
                  </div>
                  
                  <textarea 
                    value={messageContent}
                    onChange={(e) => setMessageContent(e.target.value)}
                    placeholder="Tulis pesan promosi Anda di sini... Gunakan {name} untuk menyapa nama pelanggan."
                    className="w-full h-44 p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all text-sm outline-none resize-none font-medium text-slate-800 leading-relaxed"
                  />
                </div>

                {/* 2.5 JADWAL PENGIRIMAN (SCHEDULE BLAST) */}
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-emerald-600" />
                      Jadwal Pengiriman Pesan Blasting (Set Waktu & Jam)
                    </label>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 mb-1">Tipe Pengiriman</label>
                      <div className="flex bg-white border border-slate-200 rounded-xl p-1 text-xs font-bold">
                        <button
                          type="button"
                          onClick={() => setScheduleType('now')}
                          className={`flex-1 py-2 rounded-lg transition-all ${scheduleType === 'now' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-50'}`}
                        >
                          Kirim Sekarang (Instan)
                        </button>
                        <button
                          type="button"
                          onClick={() => setScheduleType('scheduled')}
                          className={`flex-1 py-2 rounded-lg transition-all ${scheduleType === 'scheduled' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-50'}`}
                        >
                          Jadwalkan (Atur Jam)
                        </button>
                      </div>
                    </div>

                    {scheduleType === 'scheduled' ? (
                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 mb-1">Pilih Tanggal & Jam Kirim</label>
                        <input
                          type="datetime-local"
                          value={scheduledTime}
                          onChange={(e) => setScheduledTime(e.target.value)}
                          className="w-full text-xs font-bold bg-white border border-slate-200 rounded-xl p-2 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 text-slate-800"
                        />
                      </div>
                    ) : (
                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 mb-1">Interval Jeda Anti-Spam (Detik)</label>
                        <div className="flex items-center gap-3 mt-1.5">
                          <input
                            type="range"
                            min="1"
                            max="15"
                            value={sendDelaySeconds}
                            onChange={(e) => setSendDelaySeconds(Number(e.target.value))}
                            className="flex-1 accent-emerald-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                          />
                          <span className="text-xs font-extrabold text-emerald-800 bg-emerald-50 border border-emerald-100 px-3 py-1 rounded-lg shrink-0">
                            {sendDelaySeconds} Detik
                          </span>
                        </div>
                      </div>
                    )}
                  </div>

                  {scheduleType === 'scheduled' && (
                    <div className="text-[10.5px] text-amber-800 bg-amber-50 border border-amber-200 p-3 rounded-xl font-medium leading-relaxed">
                      💡 <b>Info Penjadwalan:</b> Sistem WhatsApp Gateway akan otomatis menahan antrean pesan ini dan memproses blasting ke semua penerima secara aman tepat pada <b>{new Date(scheduledTime || Date.now()).toLocaleString('id-ID', { dateStyle: 'long', timeStyle: 'short' })} WIB</b>.
                    </div>
                  )}
                </div>

                {/* LIVE BLASTING PROGRESS BANNER */}
                {isBlasting && (
                  <div className="bg-emerald-950/90 border border-emerald-500/40 p-4 rounded-2xl text-white space-y-3 animate-fade-in shadow-xl">
                    <div className="flex justify-between items-center text-xs">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                        <span className="font-extrabold text-emerald-300">Status Progress Pengiriman WA:</span>
                      </div>
                      <span className="font-mono font-extrabold text-white bg-emerald-800/80 px-2.5 py-0.5 rounded-lg border border-emerald-500/30">
                        {blastProgress.current} / {blastProgress.total} Terkirim
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden border border-emerald-500/30">
                      <div
                        className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full transition-all duration-300 rounded-full"
                        style={{
                          width: `${blastProgress.total > 0 ? Math.round((blastProgress.current / blastProgress.total) * 100) : 0}%`
                        }}
                      />
                    </div>

                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center text-[11px] text-slate-300 gap-1 pt-1">
                      <span className="truncate">
                        Mengirim ke: <strong className="text-white font-mono">{currentSendingTarget || 'Memproses...'}</strong>
                      </span>
                      <span className="text-emerald-300 flex items-center gap-1 font-medium shrink-0">
                        <Clock className="w-3 h-3" /> Delay Anti-Spam: {sendDelaySeconds}s per nomor
                      </span>
                    </div>
                  </div>
                )}

                {/* 3. SUBMIT BLASTING BUTTON */}
                <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-3">
                  <div className="text-xs text-slate-500 flex items-center gap-2">
                    <span>Penerima Terpilih: <strong className="text-emerald-600 text-sm font-black">{selectedUsers.length}</strong> Kontak</span>
                    {selectedUsers.length === 0 && filteredUsers.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setSelectedUsers(filteredUsers.map(u => u.email))}
                        className="text-[11px] text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-lg font-bold hover:bg-emerald-100 transition-all cursor-pointer"
                      >
                        Pilih Semua ({filteredUsers.length})
                      </button>
                    )}
                  </div>

                  <button 
                    onClick={startBlast}
                    disabled={isBlasting}
                    className={`w-full sm:w-auto px-8 py-3.5 rounded-2xl font-extrabold text-xs shadow-lg transition-all flex items-center justify-center gap-2 ${
                      isBlasting
                        ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20 active:scale-95 cursor-pointer'
                    }`}
                  >
                    <Send className="w-4 h-4" />
                    {isBlasting 
                      ? `Sedang Blasting... (${blastProgress.current}/${blastProgress.total})` 
                      : scheduleType === 'scheduled'
                      ? `Jadwalkan Blasting WA (${selectedUsers.length > 0 ? selectedUsers.length : filteredUsers.length} Kontak)`
                      : `Mulai Blasting WA (${selectedUsers.length > 0 ? selectedUsers.length : filteredUsers.length} Kontak)`
                    }
                  </button>
                </div>
              </div>

              {/* 4. REAL-TIME WHATSAPP LIVE PREVIEW / CONTOH PESAN DAN GAMBAR */}
              <div className="bg-slate-900 rounded-3xl p-6 border border-slate-800 shadow-xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <Eye className="w-5 h-5 text-emerald-400" />
                    <div>
                      <h3 className="text-sm font-extrabold text-white">Contoh Visual Pesan & Gambar (Live Preview)</h3>
                      <p className="text-[11px] text-slate-400">Tampilan persis yang akan diterima oleh pelanggan di aplikasi WhatsApp.</p>
                    </div>
                  </div>
                </div>

                {/* Smartphone Screen Simulator */}
                <div className="max-w-md mx-auto bg-[#efeae2] rounded-2xl overflow-hidden shadow-2xl border-4 border-slate-800 relative">
                  {/* WhatsApp Header */}
                  <div className="bg-[#075e54] text-white p-3 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 font-extrabold text-xs flex items-center justify-center shrink-0 border border-white/20">
                      PL
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1">
                        <p className="text-xs font-bold truncate">Pancaran Lelang Official</p>
                        <CheckCircle className="w-3 h-3 text-emerald-300 fill-emerald-500 shrink-0" />
                      </div>
                      <p className="text-[9px] text-emerald-200">Online • Gateway Sesi Aktif</p>
                    </div>
                  </div>

                  {/* WhatsApp Chat Body */}
                  <div className="p-4 min-h-[220px] bg-[radial-gradient(#0000000a_1px,transparent_1px)] [background-size:12px_12px] flex flex-col justify-end">
                    {/* Chat Bubble */}
                    <div className="bg-white rounded-2xl rounded-tl-none p-3 shadow-md max-w-[90%] space-y-2 border border-slate-200/80 self-start animate-fade-in">
                      {/* Attached Photo Preview in Chat */}
                      {selectedImageUrl ? (
                        <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-100 group">
                          <img 
                            src={selectedImageUrl} 
                            alt="Sample WhatsApp Photo" 
                            className="w-full h-44 object-cover"
                          />
                          <span className="absolute bottom-1.5 right-1.5 bg-black/60 backdrop-blur-xs text-white text-[9px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1">
                            <ImageIcon className="w-3 h-3" /> Foto Promosi
                          </span>
                        </div>
                      ) : (
                        <div className="bg-amber-50 border border-amber-200 p-2 rounded-xl text-[10px] text-amber-800 flex items-center gap-1.5 italic">
                          <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          <span>Pesan dikirim tanpa foto (Teks saja).</span>
                        </div>
                      )}

                      {/* Message Content Preview with replaced tags */}
                      <div className="text-xs text-slate-800 leading-relaxed font-sans whitespace-pre-wrap break-words">
                        {renderFormattedPreview(messageContent || 'Tulis isi pesan Anda di atas...')}
                      </div>

                      {/* Timestamp & Double Checks */}
                      <div className="flex justify-end items-center gap-1 pt-1 text-[9px] text-slate-400 font-medium">
                        <span>{new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}</span>
                        <span className="text-blue-500 font-bold">✓✓</span>
                      </div>
                    </div>
                  </div>

                  {/* Simulated Input Bar */}
                  <div className="bg-[#f0f2f5] p-2 px-3 flex items-center gap-2 border-t border-slate-200">
                    <div className="flex-1 bg-white rounded-full px-3 py-1.5 text-[11px] text-slate-400">
                      Balas ke Pancaran Lelang...
                    </div>
                    <div className="w-7 h-7 rounded-full bg-[#128c7e] text-white flex items-center justify-center">
                      <Send className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: DRAFT & TEMPLATE PESAN & FOTO */}
          {activeTab === 'templates' && (
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <div>
                    <h3 className="text-base font-extrabold text-slate-800">Draft & Template Pesan + Foto</h3>
                    <p className="text-xs text-slate-500 mt-0.5">Pilih template siap pakai lengkap dengan pesan dan gambarnya untuk mempermudah promosi.</p>
                  </div>

                  <button 
                    onClick={() => setShowAddTemplateModal(true)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 shrink-0"
                  >
                    <Plus className="w-4 h-4" /> Tambah Template Baru
                  </button>
                </div>

                {/* Templates Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {templates.length === 0 ? (
                    <div className="col-span-full py-12 text-center bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl space-y-3">
                      <FileText className="w-10 h-10 text-slate-300 mx-auto" />
                      <div>
                        <p className="text-xs font-bold text-slate-700">Belum Ada Template Pesan</p>
                        <p className="text-[11px] text-slate-400 mt-0.5 max-w-md mx-auto">
                          Buat template pesan buatan Anda sendiri dengan mengklik tombol "Tambah Template Baru" di atas.
                        </p>
                      </div>
                      <button 
                        onClick={() => setShowAddTemplateModal(true)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all inline-flex items-center gap-1.5"
                      >
                        <Plus className="w-4 h-4" /> Buat Template Pertama
                      </button>
                    </div>
                  ) : (
                    templates.map(tpl => (
                      <div 
                        key={tpl.id} 
                        className="p-4 rounded-2xl border border-slate-200 bg-slate-50 hover:bg-white hover:border-emerald-300 hover:shadow-md transition-all group flex flex-col justify-between space-y-3"
                      >
                        <div className="space-y-2">
                          {/* Header Badge */}
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-extrabold px-2.5 py-0.5 bg-emerald-100 text-emerald-800 rounded-full uppercase">
                              {tpl.category}
                            </span>
                            <button 
                              onClick={() => handleDeleteTemplate(tpl.id)}
                              className="p-1 text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                              title="Hapus Template"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <h4 className="text-xs font-extrabold text-slate-800">{tpl.name}</h4>

                          {/* Template Photo Thumbnail if present */}
                          {tpl.imageUrl && (
                            <div className="relative rounded-xl overflow-hidden border border-slate-200 h-32 bg-slate-100">
                              <img 
                                src={tpl.imageUrl} 
                                alt={tpl.name} 
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                              />
                              <span className="absolute bottom-2 right-2 bg-black/60 text-white text-[9px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 backdrop-blur-xs">
                                <ImageIcon className="w-3 h-3" /> Termasuk Foto
                              </span>
                            </div>
                          )}

                          <p className="text-xs text-slate-600 line-clamp-4 leading-relaxed font-sans whitespace-pre-wrap bg-white p-2.5 rounded-xl border border-slate-100">
                            {tpl.content}
                          </p>
                        </div>

                        <button 
                          onClick={() => handleApplyTemplate(tpl)}
                          className="w-full py-2 bg-emerald-50 group-hover:bg-emerald-600 text-emerald-700 group-hover:text-white font-bold text-xs rounded-xl border border-emerald-200 group-hover:border-emerald-600 transition-all flex items-center justify-center gap-1.5 shadow-2xs"
                        >
                          <Check className="w-3.5 h-3.5" /> Gunakan Template & Foto
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Blast History Logs */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                <h3 className="text-base font-extrabold text-slate-800">Riwayat Blasting WhatsApp</h3>
                {blastLogs.length > 0 ? (
                  <div className="space-y-2">
                    {blastLogs.map(log => (
                      <div key={log.id} className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex justify-between items-center text-xs">
                        <div>
                          <p className="font-bold text-slate-800">{log.messagePreview}</p>
                          <p className="text-[10px] text-slate-400 mt-0.5">{log.time} • {log.recipientCount} Penerima</p>
                        </div>
                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 font-bold rounded-lg text-[10px]">
                          {log.status}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">Belum ada riwayat blasting terrekam.</p>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: KONEKSI BARCODE WA */}
          {activeTab === 'connect' && (
            <div className="bg-white p-8 sm:p-10 rounded-3xl border border-slate-200 shadow-sm flex flex-col items-center justify-center text-center space-y-6">
              {waStatus === 'connected' ? (
                <div className="space-y-6 max-w-md w-full">
                  <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto shadow-inner">
                    <CheckCircle className="w-10 h-10" />
                  </div>
                  <div className="space-y-2">
                    <span className="inline-block px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-extrabold uppercase tracking-widest">
                      Sesi Aktif
                    </span>
                    <h3 className="text-2xl font-extrabold text-slate-800">WhatsApp Terhubung</h3>
                    <p className="text-slate-500 text-xs leading-relaxed">
                      Perangkat terhubung dengan nomor <span className="font-bold text-slate-800">{connectedPhone}</span>. Anda dapat langsung mengirim pesan promosi & broadcast lelang.
                    </p>
                  </div>

                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 text-left space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500 font-medium">Status Sinyal:</span>
                      <span className="font-bold text-emerald-600 flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-emerald-500"></span> Baik (100%)
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500 font-medium">Server Engine:</span>
                      <span className="font-bold text-slate-700">Pancaran WA Gateway v2</span>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button 
                      onClick={() => setActiveTab('blast')}
                      className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-2"
                    >
                      <Send className="w-4 h-4" /> Mulai Blasting Pesan
                    </button>
                    <button 
                      onClick={handleLogout}
                      className="px-4 py-3 bg-rose-50 text-rose-600 border border-rose-100 rounded-xl font-bold text-xs hover:bg-rose-100 transition-all"
                    >
                      Putus Sesi
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-6 max-w-lg w-full">
                  <div>
                    <h3 className="text-2xl font-extrabold text-slate-800">Hubungkan WhatsApp</h3>
                    <p className="text-slate-500 text-xs mt-1">Scan kode QR barcode di bawah atau gunakan Kode Pasangkan untuk mengaktifkan WhatsApp Blasting.</p>
                  </div>



                  {/* Mode Selector */}
                  <div className="flex bg-slate-100 p-1 rounded-2xl w-max mx-auto text-xs font-bold border border-slate-200">
                    <button
                      onClick={() => setConnectMode('qr')}
                      className={`px-5 py-2 rounded-xl transition-all ${connectMode === 'qr' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500'}`}
                    >
                      Scan Barcode / QR
                    </button>
                    <button
                      onClick={() => setConnectMode('pairing')}
                      className={`px-5 py-2 rounded-xl transition-all ${connectMode === 'pairing' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500'}`}
                    >
                      Kode Pasangkan
                    </button>
                  </div>

                  {connectMode === 'qr' && (
                    <div className="space-y-6">
                      <div className="relative inline-block">
                        <div 
                          onClick={() => handleQuickConnect(pairPhoneInput)}
                          className="relative w-80 h-80 bg-white border border-emerald-400 rounded-[32px] p-3 flex items-center justify-center shadow-xl hover:shadow-2xl transition-all cursor-pointer group"
                          title="Klik barcode QR ini untuk menghubungkan instan"
                        >
                          {/* Green Corner Brackets - Matched with screenshot */}
                          <div className="absolute top-2 left-2 w-7 h-7 border-t-4 border-l-4 border-[#00c278] rounded-tl-lg"></div>
                          <div className="absolute top-2 right-2 w-7 h-7 border-t-4 border-r-4 border-[#00c278] rounded-tr-lg"></div>
                          <div className="absolute bottom-2 left-2 w-7 h-7 border-b-4 border-l-4 border-[#00c278] rounded-bl-lg"></div>
                          <div className="absolute bottom-2 right-2 w-7 h-7 border-b-4 border-r-4 border-[#00c278] rounded-br-lg"></div>

                          {qrCode ? (
                            <div className="w-full h-full bg-[#f8fafd] rounded-[24px] flex flex-col items-center justify-center p-4 relative">
                              <img 
                                src={qrCode} 
                                alt="WA Barcode QR" 
                                className="w-56 h-56 object-contain mx-auto group-hover:scale-105 transition-transform rounded-xl" 
                              />
                              {/* Central WhatsApp Badge Icon */}
                              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                <div className="bg-white p-2 rounded-2xl shadow-md border border-emerald-100">
                                  <div className="w-7 h-7 rounded-xl bg-[#00c278] flex items-center justify-center text-white font-extrabold text-xs">
                                    WA
                                  </div>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="w-full h-full bg-[#f8fafd] rounded-[24px] flex flex-col items-center justify-center p-6 gap-4">
                              {/* Green Circle Badge with QR Dot-Grid inside */}
                              <div className="w-16 h-16 bg-[#e6f7f0] text-[#00c278] rounded-full flex items-center justify-center shadow-inner border border-emerald-100">
                                <QrCode className="w-8 h-8" />
                              </div>
                              
                              {/* Rotating Refresh Indicator */}
                              <RefreshCw className="w-6 h-6 text-[#00c278] animate-spin" />
                              
                              {/* WhatsApp web label */}
                              <p className="text-[13px] text-slate-700 font-extrabold tracking-wide">
                                Membuat Barcode WhatsApp Web...
                              </p>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="space-y-4 max-w-md mx-auto">
                        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-left shadow-inner">
                          <label className="text-[11px] font-extrabold text-slate-700 block mb-1.5 uppercase tracking-wide">Nomor HP / WhatsApp Pengirim Anda:</label>
                          <input 
                            type="text" 
                            value={pairPhoneInput}
                            onChange={(e) => setPairPhoneInput(e.target.value)}
                            placeholder="Contoh: 081317469744"
                            className="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all shadow-sm"
                          />
                        </div>

                        <div className="bg-emerald-50/60 border border-emerald-200/80 p-4 rounded-2xl text-left space-y-2 text-xs text-slate-700">
                          <p className="font-extrabold text-emerald-900 flex items-center gap-1.5 text-xs">
                            <CheckCircle className="w-4 h-4 text-emerald-600" /> Petunjuk Scan Barcode WhatsApp Web:
                          </p>
                          <ol className="list-decimal list-inside space-y-1.5 text-slate-600 font-medium pl-1 text-[11px] leading-relaxed">
                            <li>Buka aplikasi <b>WhatsApp</b> di Smartphone Anda</li>
                            <li>Ketuk <b>Menu (⋮)</b> di Android atau <b>Pengaturan</b> di iPhone</li>
                            <li>Pilih <b>Perangkat Tertaut</b> &gt; ketuk <b>Tautkan Perangkat</b></li>
                            <li>Arahkan kamera HP ke <b>Barcode QR</b> di atas</li>
                          </ol>
                        </div>

                        <div className="pt-1 flex flex-col sm:flex-row gap-2 justify-center items-center">
                          <button 
                            onClick={handleRefreshQr}
                            className="w-full sm:w-auto px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-2xl transition-all flex items-center justify-center gap-1.5 shadow-md active:scale-95 cursor-pointer"
                          >
                            <RefreshCw className="w-3.5 h-3.5" />
                            Generate Barcode Baru
                          </button>
                          <button 
                            onClick={() => handleQuickConnect(pairPhoneInput)}
                            className="w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl shadow-lg shadow-emerald-600/25 transition-all flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer"
                          >
                            <CheckCircle className="w-4 h-4" />
                            Selesai Scan / Hubungkan Langsung
                          </button>
                          <button 
                            onClick={handleCheckStatusManual}
                            className="text-xs font-bold text-slate-600 hover:text-emerald-700 px-3 py-2 cursor-pointer transition-colors"
                          >
                            Cek Status
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {connectMode === 'pairing' && (
                    <div className="space-y-5 bg-slate-50 p-6 rounded-3xl border border-slate-100 text-left">
                      <div className="space-y-1.5">
                        <label className="text-xs font-extrabold text-slate-700 block">Nomor WhatsApp Anda</label>
                        <div className="flex gap-2">
                          <input 
                            type="text" 
                            value={pairPhoneInput}
                            onChange={(e) => setPairPhoneInput(e.target.value)}
                            placeholder="Contoh: 081317469744"
                            className="flex-1 px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                          />
                          <button
                            onClick={handleRequestPairCode}
                            disabled={isPairing}
                            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all shrink-0"
                          >
                            {isPairing ? 'Memproses...' : 'Dapatkan Kode'}
                          </button>
                        </div>
                      </div>

                      {pairCodeResult && (
                        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-2 animate-fade-in">
                          <p className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">Kode Pasangkan WhatsApp Anda</p>
                          <div className="text-2xl font-mono font-black text-emerald-900 tracking-widest bg-white py-2 px-4 rounded-xl border border-emerald-200 inline-block shadow-sm">
                            {pairCodeResult}
                          </div>
                          <p className="text-[10px] text-emerald-700">
                            Masukkan kode ini di HP Anda saat menghubungkan tautan perangkat. Sesi akan otomatis terhubung...
                          </p>
                        </div>
                      )}

                      <div className="pt-2 text-[11px] text-slate-500 space-y-1 leading-relaxed">
                        <p className="font-bold text-slate-700">Langkah Menautkan Kode:</p>
                        <ol className="list-decimal list-inside space-y-0.5">
                          <li>Buka WhatsApp &gt; Perangkat Tertaut</li>
                          <li>Pilih Tautkan Perangkat &gt; Tautkan dengan nomor telepon</li>
                          <li>Masukkan kode 8 karakter di atas</li>
                        </ol>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Sidebar: Recipient List */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col max-h-[750px]">
          <div className="space-y-4 mb-4">
            <h3 className="text-base font-extrabold text-slate-800 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-600" />
                Penerima Blasting
              </span>
              <span className="text-[10px] font-extrabold px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full">
                {selectedUsers.length} Terpilih
              </span>
            </h3>
            
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input 
                type="text" 
                placeholder="Cari nama/HP..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-medium text-slate-800"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <button 
                onClick={handleSelectAll}
                className="text-[11px] font-bold text-emerald-700 hover:underline"
              >
                {selectedUsers.length === filteredUsers.length ? 'Batalkan Semua' : 'Pilih Semua'}
              </button>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                {filteredUsers.length} Kontak Memiliki HP
              </span>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto pr-1 space-y-2 custom-scrollbar">
            {filteredUsers.map(user => (
              <div 
                key={user.email}
                onClick={() => toggleUserSelection(user.email)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center gap-3 ${
                  selectedUsers.includes(user.email)
                    ? 'bg-emerald-50 border-emerald-300 shadow-2xs'
                    : 'bg-white border-slate-100 hover:border-slate-200'
                }`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                  selectedUsers.includes(user.email) ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-400'
                }`}>
                  <Phone className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className={`text-xs font-bold truncate ${
                    selectedUsers.includes(user.email) ? 'text-emerald-800' : 'text-slate-800'
                  }`}>
                    {user.name}
                  </p>
                  <p className="text-[10px] text-slate-400 font-medium">{user.phone}</p>
                </div>
                
                {/* 1-Click Direct WA Link */}
                <a
                  href={`https://wa.me/${user.phone.replace(/[^0-9]/g, '').replace(/^0/, '62')}?text=${encodeURIComponent(
                    messageContent.replace(/{name}/g, user.name) + (selectedImageUrl ? `\n\n[Foto Promosi: ${selectedImageUrl}]` : '')
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  title="Kirim Langsung via WA Web / App"
                  className="p-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-xl text-[10px] font-bold flex items-center gap-1 transition-all"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>

                {selectedUsers.includes(user.email) && (
                  <div className="ml-1">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                  </div>
                )}
              </div>
            ))}
            
            {filteredUsers.length === 0 && (
              <div className="text-center py-12 text-slate-400 space-y-2">
                <AlertCircle className="w-8 h-8 mx-auto opacity-20" />
                <p className="text-xs">Tidak ada kontak dengan No HP.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* MODAL: TAMBAH TEMPLATE PESAN BARU */}
      {showAddTemplateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-slate-100 space-y-5 relative">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100">
              <h3 className="text-base font-extrabold text-slate-800 flex items-center gap-2">
                <Plus className="w-5 h-5 text-emerald-600" />
                Tambah Template Pesan & Foto Baru
              </h3>
              <button 
                onClick={() => setShowAddTemplateModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs font-medium text-slate-700">
              <div>
                <label className="font-bold block mb-1">Judul / Nama Template</label>
                <input 
                  type="text" 
                  placeholder="Contoh: Promo Diskon Bidding Spesial Weekend"
                  value={newTplName}
                  onChange={(e) => setNewTplName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="font-bold block mb-1">Kategori</label>
                <select 
                  value={newTplCategory}
                  onChange={(e) => setNewTplCategory(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 font-bold text-slate-800"
                >
                  <option value="Lelang Baru">Lelang Baru</option>
                  <option value="Promo Commercial">Promo Commercial</option>
                  <option value="Pengingat">Pengingat</option>
                  <option value="Greeting">Greeting</option>
                  <option value="Umum">Umum</option>
                </select>
              </div>

              <div>
                <label className="font-bold block mb-1">Foto / Banner Template (Upload)</label>
                {newTplImageUrl ? (
                  <div className="relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-50 p-2.5 flex items-center gap-3">
                    <img src={newTplImageUrl} alt="Preview" className="w-16 h-16 object-cover rounded-xl border border-slate-200 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <span className="text-emerald-700 font-extrabold text-[11px] block">✅ Foto Terlampir Siap Disimpan</span>
                      <p className="text-[10px] text-slate-500 truncate mt-0.5">{newTplImageUrl.startsWith('data:') ? 'Foto dari Unggahan Lokal' : newTplImageUrl}</p>
                    </div>
                    <button 
                      type="button" 
                      onClick={() => setNewTplImageUrl('')}
                      className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                      title="Hapus Foto"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <label className="border-2 border-dashed border-slate-200 hover:border-emerald-500 bg-slate-50 hover:bg-emerald-50/20 p-4 rounded-2xl cursor-pointer transition-all text-center flex flex-col items-center justify-center gap-1 group">
                      <Upload className="w-6 h-6 text-slate-400 group-hover:text-emerald-600 transition-colors" />
                      <span className="text-xs font-extrabold text-slate-700">Unggah Foto dari Perangkat (HP / PC)</span>
                      <span className="text-[10px] text-slate-400">Pilih file foto JPG, PNG (Maksimal 5MB)</span>
                      <input 
                        type="file" 
                        accept="image/*" 
                        onChange={handleTemplateImageUpload}
                        className="hidden" 
                      />
                    </label>

                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 flex items-center gap-2">
                      <span className="text-[11px] font-bold text-slate-600 shrink-0">Atau Foto Unit Lelang:</span>
                      <select 
                        onChange={(e) => {
                          const found = assets.find(a => a.id === e.target.value);
                          if (found) {
                            const img = found.imageUrl || (found.imageUrls && found.imageUrls[0]);
                            if (img) setNewTplImageUrl(img);
                          }
                        }}
                        className="w-full text-xs font-bold bg-white border border-slate-200 rounded-lg p-1.5 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 text-slate-800"
                      >
                        <option value="">-- Pilih dari Katalog Aset --</option>
                        {assets.map(a => (
                          <option key={a.id} value={a.id}>{a.name} ({a.brand})</option>
                        ))}
                      </select>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="font-bold block mb-1">Isi Pesan Template</label>
                <textarea 
                  rows={4}
                  placeholder="Tulis draf pesan... Gunakan {name}, {asset_name}, {brand}, {price}..."
                  value={newTplContent}
                  onChange={(e) => setNewTplContent(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 font-medium text-slate-800 leading-relaxed resize-none"
                />
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button 
                onClick={() => setShowAddTemplateModal(false)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all"
              >
                Batal
              </button>
              <button 
                onClick={handleAddTemplate}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all"
              >
                Simpan Template
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: SUCCESS BLASTING NOTIFICATION */}
      {showSuccessModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-emerald-100 text-center space-y-5 relative animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle className="w-10 h-10 animate-bounce" />
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-black text-slate-900">Blasting Pesan & Foto Berhasil!</h3>
              <p className="text-xs text-slate-500">Pesan WhatsApp telah terkirim melalui gateway server.</p>
            </div>

            {successInfo && (
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 text-left space-y-2 text-xs">
                <div className="flex justify-between items-center text-slate-600 font-medium pb-2 border-b border-slate-200/60">
                  <span>Jumlah Penerima:</span>
                  <span className="font-extrabold text-emerald-600 text-sm">{successInfo.count} Kontak</span>
                </div>
                <div className="flex justify-between items-center text-slate-600 font-medium">
                  <span>Lampiran Foto:</span>
                  <span className={`font-bold ${successInfo.hasImage ? 'text-emerald-600' : 'text-slate-400'}`}>
                    {successInfo.hasImage ? '✅ Terlampir' : 'Tanpa Foto'}
                  </span>
                </div>
                <div className="flex justify-between items-center text-slate-600 font-medium">
                  <span>Waktu Kirim:</span>
                  <span className="font-bold text-slate-800">{successInfo.time} WIB</span>
                </div>
                <div className="pt-1">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Pratinjau Pesan:</p>
                  <p className="text-slate-700 bg-white p-2.5 rounded-xl border border-slate-200/80 italic font-mono text-[11px] leading-relaxed">
                    "{successInfo.preview}"
                  </p>
                </div>
              </div>
            )}

            <button
              onClick={() => setShowSuccessModal(false)}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl shadow-lg shadow-emerald-600/25 transition-all active:scale-95"
            >
              Tutup & Lanjutkan
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
