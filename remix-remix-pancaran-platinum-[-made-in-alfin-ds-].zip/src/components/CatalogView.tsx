import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion } from 'motion/react';
import { Asset, Bid, MAIN_CATEGORIES, normalizeCategory, getGoogleMapsUrl, UsedPartItem, sortAssetsByNewest, getHighestBidBreakdown, isSubCategoryMatch, getCleanAssetName, normalizeUsedPartItem } from '../types';
import { useLanguage } from './LanguageContext';
import { MiniMapPreview } from './MiniMapPreview';
import { 
  Search, 
  Filter, 
  Tag, 
  MapPin, 
  Calendar, 
  Clock, 
  ChevronRight, 
  ChevronLeft,
  TrendingUp, 
  AlertCircle, 
  CheckCircle,
  Truck,
  ArrowUpRight,
  ShieldAlert,
  Info,
  CalendarCheck,
  User,
  Mail,
  Phone,
  DollarSign,
  X,
  ZoomIn,
  ZoomOut,
  Lock,
  GripHorizontal,
  Eye,
  Layers,
  CameraOff
} from 'lucide-react';

interface CatalogViewProps {
  assets: Asset[];
  onPlaceBid: (assetId: string, bidData: Omit<Bid, 'id' | 'timestamp'>) => void;
  selectedAssetId?: string | null;
  onSelectAsset?: (assetId: string | null) => void;
  isUserLoggedIn?: boolean;
  onOpenLoginModal?: () => void;
  loggedInUserEmail?: string;
  loggedInUserName?: string;
  loggedInUserPhone?: string;
  canBid?: boolean;
  onOpenGuideModal?: (guide: 'ikut' | 'titip' | 'online') => void;
  navigationTabs?: React.ReactNode;
  selectedBrand?: string;
  setSelectedBrand?: (brand: string) => void;
  selectedCategory?: string;
  setSelectedCategory?: (category: string) => void;
  searchQuery?: string;
  setSearchQuery?: (query: string) => void;
  userAllowedCategoryAccess?: string;
}

interface CatalogCardProps {
  key?: string | number;
  asset: Asset;
  onSelectAsset: (assetId: string) => void;
  formatIDR: (value: number) => string;
  onZoomImage?: (images: string[], index: number) => void;
  isUserLoggedIn?: boolean;
  onOpenLoginModal?: () => void;
  canBid?: boolean;
}

const stripMarkdown = (text: string) => {
  if (!text) return '';
  return text
    .replace(/^[\*\-\s#]+/gm, '')
    .replace(/\*\*+/g, '')
    .replace(/[\n\r]+/g, ' ')
    .trim();
};

function CountdownTimer({ targetDate, size = 'small' }: { targetDate: string; size?: 'small' | 'large' }) {
  const { t } = useLanguage();
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    isExpired: boolean;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0, isExpired: false });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = +new Date(targetDate) - +new Date();
      if (difference <= 0) {
        return { days: 0, hours: 0, minutes: 0, seconds: 0, isExpired: true };
      }
      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
        isExpired: false
      };
    };

    setTimeLeft(calculateTimeLeft());

    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(timer);
  }, [targetDate]);

  if (timeLeft.isExpired) {
    return (
      <span className={`font-bold text-rose-600 ${size === 'large' ? 'text-xs' : 'text-[10px]'}`}>
        {t('Close Bid')}
      </span>
    );
  }

  const parts = [];
  if (timeLeft.days > 0) parts.push(`${timeLeft.days}d`);
  if (timeLeft.hours > 0 || timeLeft.days > 0) parts.push(`${timeLeft.hours}h`);
  parts.push(`${timeLeft.minutes}m`);
  parts.push(`${timeLeft.seconds}s`);

  if (size === 'large') {
    return (
      <div className="flex items-center gap-1.5 font-mono">
        {timeLeft.days > 0 && (
          <div className="bg-amber-100/85 border border-amber-200 text-amber-950 px-2 py-1 rounded-xl text-center min-w-[32px]">
            <span className="text-sm font-bold block leading-none">{timeLeft.days}</span>
            <span className="text-[8px] font-extrabold uppercase text-amber-800 tracking-wider">Hari</span>
          </div>
        )}
        <div className="bg-amber-100/85 border border-amber-200 text-amber-950 px-2 py-1 rounded-xl text-center min-w-[32px]">
          <span className="text-sm font-bold block leading-none">{timeLeft.hours}</span>
          <span className="text-[8px] font-extrabold uppercase text-amber-800 tracking-wider">Jam</span>
        </div>
        <div className="bg-amber-100/85 border border-amber-200 text-amber-950 px-2 py-1 rounded-xl text-center min-w-[32px]">
          <span className="text-sm font-bold block leading-none">{timeLeft.minutes}</span>
          <span className="text-[8px] font-extrabold uppercase text-amber-800 tracking-wider">Menit</span>
        </div>
        <div className="bg-amber-100/85 border border-amber-200 text-amber-950 px-2 py-1 rounded-xl text-center min-w-[32px] animate-pulse">
          <span className="text-sm font-bold block leading-none text-rose-600">{timeLeft.seconds}</span>
          <span className="text-[8px] font-extrabold uppercase text-rose-500 tracking-wider">Detik</span>
        </div>
      </div>
    );
  }

  return (
    <span className="bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-md font-mono text-[10px] border border-amber-200 shadow-2xs font-extrabold">
      {parts.join(' ')}
    </span>
  );
}

function CatalogCard({ asset, onSelectAsset, formatIDR, onZoomImage, isUserLoggedIn, onOpenLoginModal, canBid = true }: CatalogCardProps) {
  const { t } = useLanguage();
  const [activeImgIdx, setActiveImgIdx] = useState(0);
  const [imageError, setImageError] = useState(false);

  const rawImages = asset.imageUrls && asset.imageUrls.length > 0
    ? asset.imageUrls
    : (asset.imageUrl ? [asset.imageUrl] : []);
  const images = rawImages.filter(url => url && typeof url === 'string' && url.trim() !== '');
  const hasImages = images.length > 0 && !imageError;

  const isUsedPart = normalizeCategory(asset.category) === 'Used part' || (asset.usedPartItems && asset.usedPartItems.length > 0) || (asset.category || '').toLowerCase().includes('part') || (asset.category || '').toLowerCase().includes('spare');
  const spareItems = (asset.usedPartItems && asset.usedPartItems.length > 0) 
    ? asset.usedPartItems.map(normalizeUsedPartItem) 
    : [{ id: '1', type: asset.name, qty: 1, unitPrice: asset.startingPrice, totalPrice: asset.startingPrice }];

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveImgIdx(prev => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveImgIdx(prev => (prev === images.length - 1 ? 0 : prev + 1));
  };

  const validBidPrices = (asset.bids || []).filter(b => b && typeof b.price === 'number' && !isNaN(b.price) && b.price < 1000000000).map(b => b.price);
  const highestOffer = Math.max(asset.startingPrice || 0, ...validBidPrices, 0);
  const isExpired = asset.closeBidDate ? new Date() > new Date(asset.closeBidDate) : false;

  return (
    <div className="bg-white rounded-3xl overflow-hidden border border-slate-200 hover:border-blue-200 hover:shadow-xl transition-all duration-300 flex flex-col justify-between group">
      {/* Image container: Smaller height for spare part (Used part), normal height for truck / other assets */}
      <div className={`relative ${isUsedPart ? 'h-24 bg-slate-900' : 'h-48 bg-slate-100'} overflow-hidden group/img-container transition-all duration-300 flex items-center justify-center`}>
        {hasImages ? (
          <img 
            src={images[activeImgIdx]} 
            alt={`${asset.name} - ${activeImgIdx + 1}`} 
            className={`w-full h-full ${isUsedPart ? 'object-contain' : 'object-cover'} group-hover:scale-105 transition-transform duration-500 cursor-zoom-in`} 
            referrerPolicy="no-referrer"
            onClick={(e) => {
              e.stopPropagation();
              if (onZoomImage) {
                onZoomImage(images, activeImgIdx);
              } else {
                if (isUserLoggedIn) {
                  onSelectAsset(asset.id);
                } else {
                  if (onOpenLoginModal) onOpenLoginModal();
                }
              }
            }}
            onError={() => {
              setImageError(true);
            }}
          />
        ) : (
          <div 
            onClick={(e) => {
              e.stopPropagation();
              if (isUserLoggedIn) {
                onSelectAsset(asset.id);
              } else {
                if (onOpenLoginModal) onOpenLoginModal();
              }
            }}
            className={`w-full h-full flex flex-col items-center justify-center gap-2 cursor-pointer select-none transition-colors ${
              isUsedPart 
                ? 'bg-slate-900 text-slate-400 hover:bg-slate-800' 
                : 'bg-slate-100/90 text-slate-400 hover:bg-slate-200/80'
            }`}
          >
            <div className={`p-2.5 rounded-2xl ${isUsedPart ? 'bg-slate-800 border border-slate-700' : 'bg-white/90 border border-slate-200/90 shadow-2xs'}`}>
              <CameraOff className="w-5 h-5 text-slate-400" />
            </div>
            <span className="text-[11px] font-bold tracking-wide text-slate-500">{t('Tidak Ada Foto')}</span>
          </div>
        )}

        {/* Navigation arrows overlay */}
        {hasImages && images.length > 1 && (
          <>
            <button
              onClick={handlePrev}
              className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white w-7 h-7 rounded-full flex items-center justify-center transition-all opacity-0 group-hover/img-container:opacity-100 z-10 text-xs font-bold"
              title={t('Gambar Sebelumnya')}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleNext}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white w-7 h-7 rounded-full flex items-center justify-center transition-all opacity-0 group-hover/img-container:opacity-100 z-10 text-xs font-bold"
              title={t('Gambar Berikutnya')}
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {/* Dotted indicators */}
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1 z-10 bg-black/40 backdrop-blur-xs px-2 py-1 rounded-full">
              {images.map((_, idx) => (
                <button
                   key={idx}
                   onClick={(e) => {
                     e.stopPropagation();
                     setActiveImgIdx(idx);
                   }}
                   className={`w-1.5 h-1.5 rounded-full transition-all ${idx === activeImgIdx ? 'bg-white scale-125' : 'bg-white/40'}`}
                />
              ))}
            </div>
          </>
        )}
        
        {/* Floating Info */}
        <div className="absolute top-3 left-3 z-10">
          <span className="text-[9px] font-mono font-bold bg-white/95 backdrop-blur-sm text-slate-800 px-2 py-1 rounded-md shadow-sm border border-slate-200">
            {asset.id}
          </span>
        </div>

        <div className="absolute top-3 right-3 z-10">
          {asset.status === 'Sold' && asset.bids && asset.bids.length > 0 ? (
            <span className="text-[9px] font-bold uppercase tracking-wider bg-emerald-600 text-white px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
              <CheckCircle className="w-3 h-3" />
              {t('TERJUAL')}
            </span>
          ) : isExpired ? (
            <span className="text-[9px] font-bold uppercase tracking-wider bg-rose-600 text-white px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-rose-300 rounded-full"></span>
              {t('Close Bid')}
            </span>
          ) : (
            <span className="text-[9px] font-bold uppercase tracking-wider bg-blue-600 text-white px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-ping"></span>
              {t('Terbuka')}
            </span>
          )}
        </div>

        <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-sm text-white text-[10px] font-semibold px-2.5 py-1 rounded-lg z-10 flex items-center gap-1">
          <Tag className="w-3 h-3 text-slate-300" />
          {asset.brand && normalizeCategory(asset.category) === 'Vehicle' ? `${asset.brand} • ` : ''}{t(asset.category)}
        </div>

        {isSubCategoryMatch(asset, 'Oli') && (
          <div className="absolute bottom-3 right-3 bg-black/60 backdrop-blur-sm text-white text-[9px] font-bold px-2.5 py-1 rounded-lg z-10">
            {asset.manifestStatus === 'Pake Manifest' ? (
              <span className="text-emerald-300 font-extrabold">{t('Pake Manifest')}</span>
            ) : (
              <span className="text-slate-300 font-medium">{t('Tidak Pake Manifest')}</span>
            )}
          </div>
        )}
      </div>

      {/* Info Body */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-3.5">
        <div className="space-y-1.5">
          <h3 className="font-bold text-slate-800 text-base leading-snug group-hover:text-blue-700 transition-colors">
            {getCleanAssetName(asset)}
          </h3>
          
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 font-medium">
            {asset.coordinates && getGoogleMapsUrl(asset.coordinates) ? (
              <a
                href={getGoogleMapsUrl(asset.coordinates)!}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="flex items-center gap-1 text-blue-600 hover:text-blue-800 font-bold hover:underline cursor-pointer group/loc"
              >
                <MapPin className="w-3.5 h-3.5 text-blue-500 shrink-0 group-hover/loc:scale-110 transition-transform" />
                <span>{asset.location.split(',')[1] || asset.location}</span>
                <ArrowUpRight className="w-3 h-3 opacity-60 group-hover/loc:opacity-100 group-hover/loc:translate-x-0.5 group-hover/loc:-translate-y-0.5 transition-all" />
              </a>
            ) : (
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" /> {asset.location.split(',')[1] || asset.location}
              </span>
            )}
            <span>•</span>
            {!isUsedPart && (
              <>
                <span>{t('Kondisi')}: <strong>{t(asset.condition)}</strong></span>
                <span>•</span>
              </>
            )}
            <span>{t('Th')}: <strong>{asset.modelYear}</strong></span>
          </div>

          {asset.closeBidDate && (
            <div className="flex flex-wrap items-center gap-1.5 mt-2">
              <div className="flex items-center gap-1 text-[10px] text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-100 w-fit">
                <Clock className="w-3.5 h-3.5 text-amber-500 animate-pulse-hover" />
                <span>{t('Tutup')}: {new Date(asset.closeBidDate).toLocaleString('id-ID', { dateStyle: 'short', timeStyle: 'short' })}</span>
              </div>
              <CountdownTimer targetDate={asset.closeBidDate} size="small" />
            </div>
          )}

          {/* Used Part Breakdown Table inside CatalogCard */}
          {isUsedPart ? (() => {
            const { highestBidObj, highestItemBids } = getHighestBidBreakdown(asset);
            return (
              <div className="pt-2 space-y-2" onClick={(e) => e.stopPropagation()}>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1">
                    <Layers className="w-3 h-3 text-blue-600" />
                    {t('Tabel Rincian Item / Tipe Suku Cadang')}
                  </span>
                </div>

                <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white shadow-2xs">
                  <table className="w-full text-left border-collapse text-[10px]">
                    <thead>
                      <tr className="bg-[#b8cce4] text-slate-900 font-bold border-b border-slate-300">
                        <th className="py-1 px-1.5 text-center w-6 border-r border-slate-300/70">{t('No.')}</th>
                        <th className="py-1 px-2 border-r border-slate-300/70">{t('Type / Nama Item')}</th>
                        <th className="py-1 px-2 border-r border-slate-300/70">{t('Spesifikasi / Ukuran')}</th>
                        <th className="py-1 px-1.5 text-center w-10 border-r border-slate-300/70">{t('QTY')}</th>
                        <th className="py-1 px-2 text-right border-r border-slate-300/70 bg-emerald-100/70 text-emerald-950 font-extrabold">{t('Highest Bid Satuan')}</th>
                        <th className="py-1 px-2 text-right bg-emerald-100/90 text-emerald-950 font-extrabold">{t('Total Highest Bid')}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {spareItems.map((item, idx) => {
                        const q = Number(item.qty) || 0;
                        const spec = item.spec || '-';

                        const hbItem = highestItemBids[idx];
                        const hbUnit = Number(hbItem?.unitPrice) || 0;
                        const hbTot = typeof hbItem?.totalPrice === 'number' ? hbItem.totalPrice : (q * hbUnit);
                        return (
                          <tr key={idx} className="hover:bg-slate-50">
                            <td className="py-1 px-1 text-center font-bold text-slate-500 bg-slate-50/50 border-r border-slate-100">{idx + 1}</td>
                            <td className="py-1 px-2 font-medium text-slate-800 border-r border-slate-100 truncate max-w-[130px]" title={item.type || item.name}>{item.type || item.name || '-'}</td>
                            <td className="py-1 px-2 text-slate-600 border-r border-slate-100 truncate max-w-[120px]" title={spec}>{spec}</td>
                            <td className="py-1 px-1 text-center font-mono font-bold text-blue-700 border-r border-slate-100">{q}</td>
                            <td className="py-1 px-2 text-right font-mono font-bold text-emerald-700 bg-emerald-50/40 border-r border-slate-100">{hbUnit > 0 ? formatIDR(hbUnit) : '-'}</td>
                            <td className="py-1 px-2 text-right font-mono font-bold text-emerald-800 bg-emerald-50/80">{hbTot > 0 ? formatIDR(hbTot) : '-'}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                    <tfoot>
                      <tr className="bg-slate-50 border-t border-slate-200 font-bold text-[10px]">
                        <td colSpan={3} className="py-1 px-2 text-right text-slate-700">{t('Grand Total:')}</td>
                        <td className="py-1 px-1 text-center font-mono text-blue-800 bg-blue-50/40 border-r border-slate-200">
                          {spareItems.reduce((acc, it) => acc + (Number(it.qty) || 0), 0)}
                        </td>
                        <td className="py-1 px-2 text-right text-emerald-900 font-bold bg-emerald-100/40 border-r border-slate-200">{t('Grand Total Bid')}</td>
                        <td className="py-1 px-2 text-right font-mono font-extrabold text-emerald-950 bg-emerald-100/90">
                          {formatIDR(highestBidObj ? highestBidObj.price : 0)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            );
          })() : (
            <p className="text-xs text-slate-500 line-clamp-2 mt-2 leading-relaxed">
              {stripMarkdown(asset.description)}
            </p>
          )}
        </div>

        {/* Price Status */}
        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase">{t('Harga Pembuka')}</span>
            {isUserLoggedIn ? (
              <p className="text-xs font-semibold text-slate-800">{formatIDR(asset.startingPrice)}</p>
            ) : (
              <p className="text-xs font-semibold text-slate-400 flex items-center gap-1">
                <Lock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                <span>Rp ••••••••</span>
              </p>
            )}
          </div>
          {isUserLoggedIn ? (
            <div className="text-right">
              <span className="text-[10px] text-blue-600 font-bold uppercase flex items-center justify-end gap-1">
                <TrendingUp className="w-3.5 h-3.5" /> {t('Penawaran Tertinggi')}
              </span>
              <p className="text-base font-bold text-slate-900">{formatIDR(highestOffer)}</p>
            </div>
          ) : (
            <button
              onClick={(e) => {
                e.stopPropagation();
                if (onOpenLoginModal) onOpenLoginModal();
              }}
              className="flex items-center gap-1.5 text-blue-600 hover:text-blue-700 font-bold text-xs bg-blue-50 px-2.5 py-1.5 rounded-xl border border-blue-100 hover:bg-blue-100 transition-all cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
              <span>{t('Masuk Menawar')}</span>
            </button>
          )}
        </div>

        {/* CTA Actions */}
        <div className="flex items-center justify-between text-xs font-semibold pt-1">
          <span className="text-slate-500 font-medium">
            {isUserLoggedIn ? `${asset.bids.length} ${t('Penawaran Masuk')}` : `🔒 ${t('Gabung untuk menawar')}`}
          </span>
          <button
            disabled={isExpired || asset.status === 'Sold'}
            onClick={(e) => {
              if (isExpired || asset.status === 'Sold') return;
              e.stopPropagation();
              if (isUserLoggedIn) {
                onSelectAsset(asset.id);
              } else {
                if (onOpenLoginModal) onOpenLoginModal();
              }
            }}
            className={`${
              isExpired || asset.status === 'Sold'
                ? 'bg-slate-300 text-slate-500 cursor-not-allowed border border-slate-200'
                : !canBid && isUserLoggedIn
                ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-md shadow-amber-500/10'
                : 'bg-blue-600 hover:bg-blue-700 text-white group-hover:shadow-md shadow-blue-500/10'
            } px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5`}
          >
            {asset.status === 'Sold' && asset.bids && asset.bids.length > 0 ? (
              <>
                <CheckCircle className="w-3.5 h-3.5" />
                <span>{t('Terjual')}</span>
              </>
            ) : isExpired ? (
              <>
                <Lock className="w-3.5 h-3.5" />
                <span>{t('Close Bid')}</span>
              </>
            ) : !canBid && isUserLoggedIn ? (
              <>
                <Eye className="w-3.5 h-3.5 shrink-0 text-amber-100" />
                <span>{t('Lihat Detail')}</span>
              </>
            ) : (
              <>
                <span>{t('Tawar Aset')}</span>
                <ArrowUpRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

const parseInlineMarkdown = (text: string) => {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, idx) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={idx} className="font-bold text-slate-800">{part.slice(2, -2)}</strong>;
    }
    return part;
  });
};

const renderDescription = (text: string) => {
  if (!text) return null;
  const lines = text.split('\n');
  return (
    <div className="space-y-2 text-left not-italic text-slate-600 font-sans">
      {lines.map((line, idx) => {
        const trimmed = line.trim();
        if (!trimmed) {
          return <div key={idx} className="h-1.5" />;
        }
        
        // Check if it's a heading
        if (trimmed.startsWith('##') || trimmed.startsWith('*##') || trimmed.startsWith('###') || trimmed.startsWith('*###')) {
          const cleanHeading = trimmed.replace(/^[\*\-\s#]+/, '').replace(/\*\*+/g, '');
          return (
            <h4 key={idx} className="font-bold text-slate-800 text-xs mt-3 mb-1 border-b border-slate-100 pb-1">
              {cleanHeading}
            </h4>
          );
        }

        // Check if it's a bullet point
        if (trimmed.startsWith('*') || trimmed.startsWith('-')) {
          const content = trimmed.replace(/^[\*\-\s]+/, '');
          return (
            <div key={idx} className="flex items-start gap-1.5 ml-2 text-[11px] leading-relaxed">
              <span className="text-blue-500 font-bold select-none">•</span>
              <span className="flex-1">{parseInlineMarkdown(content)}</span>
            </div>
          );
        }

        // Regular paragraph
        return (
          <p key={idx} className="text-[11px] leading-relaxed">
            {parseInlineMarkdown(trimmed)}
          </p>
        );
      })}
    </div>
  );
};

export default function CatalogView({ 
  assets, 
  onPlaceBid, 
  selectedAssetId: propSelectedAssetId, 
  onSelectAsset: propOnSelectAsset,
  isUserLoggedIn = false,
  onOpenLoginModal,
  loggedInUserEmail = '',
  loggedInUserName = '',
  loggedInUserPhone = '',
  canBid = true,
  onOpenGuideModal,
  navigationTabs,
  selectedBrand = 'all',
  setSelectedBrand,
  selectedCategory = 'all',
  setSelectedCategory,
  searchQuery = '',
  setSearchQuery,
  userAllowedCategoryAccess = 'All'
}: CatalogViewProps) {
  const { language, t } = useLanguage();
  const [internalSelectedAssetId, setInternalSelectedAssetId] = useState<string | null>(null);
  const [selectedManifest, setSelectedManifest] = useState<string>('all');

  const selectedAssetId = propSelectedAssetId !== undefined ? propSelectedAssetId : internalSelectedAssetId;
  const setSelectedAssetId = propOnSelectAsset !== undefined ? propOnSelectAsset : setInternalSelectedAssetId;
  
  const nameInputRef = useRef<HTMLInputElement>(null);

  // Helper to scroll smoothly to the form card
  const scrollToForm = () => {
    const formElement = document.getElementById('bid-form-card');
    if (formElement) {
      formElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  useEffect(() => {
    if (selectedAssetId) {
      setTimeout(() => {
        const scrollContainer = document.getElementById('bidding-modal-scroll-container');
        if (scrollContainer) {
          scrollContainer.scrollTop = 0;
        }
      }, 50);
    }
  }, [selectedAssetId]);

  // "Type to Focus" / "Ketik Langsung" feature
  useEffect(() => {
    if (!selectedAssetId) return;

    const handleTypeToFocus = (e: KeyboardEvent) => {
      // Ignore if user is already typing in an input, select, or textarea
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')) {
        return;
      }

      // Ignore standard modifier keys
      if (e.ctrlKey || e.metaKey || e.altKey) return;

      // Only handle printable single-character keys
      if (e.key.length === 1 && /[a-zA-Z0-9 ]/.test(e.key)) {
        scrollToForm();
        if (nameInputRef.current) {
          nameInputRef.current.focus();
        }
      }
    };

    window.addEventListener('keydown', handleTypeToFocus);
    return () => window.removeEventListener('keydown', handleTypeToFocus);
  }, [selectedAssetId]);

  // Bid form state
  const [bidForm, setBidForm] = useState({
    name: '',
    email: '',
    contact: '',
    price: '',
    requestSurvey: false,
    surveyDate: '',
    surveyTime: '09:00'
  });

  // State for per-item bidding when asset is Used Part / has usedPartItems
  const [itemBids, setItemBids] = useState<UsedPartItem[]>([]);

  // Auto-populate bid form fields for logged-in external users
  useEffect(() => {
    if (isUserLoggedIn && loggedInUserEmail) {
      setBidForm(prev => ({
        ...prev,
        email: loggedInUserEmail,
        name: loggedInUserName || prev.name,
        contact: loggedInUserPhone || prev.contact,
      }));
    }
  }, [isUserLoggedIn, loggedInUserEmail, loggedInUserName, loggedInUserPhone]);

  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState(false);
  const [isFormFocused, setIsFormFocused] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [showBidConfirmModal, setShowBidConfirmModal] = useState(false);

  // States for modal image carousel and fullscreen lightbox
  const [modalImageIdx, setModalImageIdx] = useState(0);
  const [lightboxImages, setLightboxImages] = useState<string[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [isZoomed, setIsZoomed] = useState(false);

  const [showFullDesc, setShowFullDesc] = useState(false);

  useEffect(() => {
    setIsZoomed(false);
  }, [lightboxIndex]);

  useEffect(() => {
    setModalImageIdx(0);
    setShowFullDesc(false);
    setAgreedToTerms(false);
  }, [selectedAssetId]);

  // Lock background body scroll when detail/bidding pop-up modal is open
  useEffect(() => {
    if (selectedAssetId) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [selectedAssetId]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setLightboxIndex(null);
      } else if (e.key === 'ArrowRight' && lightboxIndex !== null && lightboxImages.length > 1) {
        setLightboxIndex(prev => (prev === null ? null : (prev === lightboxImages.length - 1 ? 0 : prev + 1)));
      } else if (e.key === 'ArrowLeft' && lightboxIndex !== null && lightboxImages.length > 1) {
        setLightboxIndex(prev => (prev === null ? null : (prev === 0 ? lightboxImages.length - 1 : prev - 1)));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxIndex, lightboxImages]);

  // We only show "Open" assets in the public catalog
  const openAssets = (assets || []).filter(a => a && a.status === 'Open');

  // Dynamic manifest options from master data
  const manifestOptions = (() => {
    try {
      const saved = localStorage.getItem('pancaran_manifest_options');
      if (saved) return JSON.parse(saved) as string[];
    } catch (e) {
      console.error(e);
    }
    return ['Pake Manifest', 'Tidak Pake Manifest'];
  })();

  // Filter logic (sorted so newest posted is at the top)
  const filteredAssets = sortAssetsByNewest(openAssets.filter(asset => {
    if (!asset) return false;

    // Check user category access restriction
    if (userAllowedCategoryAccess && userAllowedCategoryAccess !== 'All') {
      const allowedNorm = normalizeCategory(userAllowedCategoryAccess);
      const assetNorm = normalizeCategory(asset.category);
      if (allowedNorm !== assetNorm) return false;
    }

    const matchesBrand = selectedBrand === 'all' || asset.brand === selectedBrand;
    const matchesCategory = selectedCategory === 'all' || asset.category === selectedCategory;
    const matchesManifest = selectedManifest === 'all' || 
      (asset.manifestStatus === selectedManifest) || 
      (selectedManifest === 'Tidak Pake Manifest' && (!asset.manifestStatus || asset.manifestStatus === 'Tidak Pake Manifest'));
    const q = (searchQuery || '').toLowerCase();
    const matchesSearch = 
      (asset.name || '').toLowerCase().includes(q) ||
      (asset.brand || '').toLowerCase().includes(q) ||
      (asset.category || '').toLowerCase().includes(q) ||
      (asset.description || '').toLowerCase().includes(q) ||
      (asset.id || '').toLowerCase().includes(q);

    return matchesBrand && matchesCategory && matchesManifest && matchesSearch;
  }));

  const uniqueBrands = Array.from(new Set(openAssets.map(a => a.brand || '').filter(Boolean)));
  const uniqueCategories = Array.from(new Set([...MAIN_CATEGORIES, ...openAssets.map(a => normalizeCategory(a.category || ''))]));

  const selectedAsset = (assets || []).find(a => a && a.id === selectedAssetId);
  const selectedAssetBids = (selectedAsset?.bids || []).filter(b => b && typeof b.price === 'number' && !isNaN(b.price) && b.price < 1000000000).map(b => b.price);
  const currentHighestBid = selectedAsset 
    ? Math.max(selectedAsset.startingPrice || 0, ...selectedAssetBids, 0)
    : 0;

  const formatIDR = (value: number | undefined | null) => {
    const num = typeof value === 'number' && !isNaN(value) ? value : (Number(value) || 0);
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(num);
  };

  const formatNumberWithDots = (numStr: string) => {
    const clean = numStr.replace(/\D/g, '');
    if (!clean) return '';
    return new Intl.NumberFormat('id-ID').format(Number(clean));
  };

  const formatDateIndonesian = (dateStr?: string) => {
    if (!dateStr) return '-';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      const locale = language === 'en' ? 'en-US' : 'id-ID';
      return d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
    } catch {
      return dateStr;
    }
  };

  const isTimeBooked = (time: string, date: string, targetCategory?: string) => {
    if (!date) return false;
    const catToCheck = targetCategory || selectedAsset?.category;
    const normTarget = normalizeCategory(catToCheck);
    return assets.some(asset => {
      // Area survei terpisah antara Kendaraan dan Used part (serta kategori lainnya)
      const normAssetCat = normalizeCategory(asset.category);
      if (normAssetCat !== normTarget) return false;

      return (asset.bids || []).some(b => 
        b.scheduleSurveyDate === date && 
        b.scheduleSurveyTime === time
      );
    });
  };

  const handleSelectAsset = (assetId: string) => {
    setSelectedAssetId(assetId);
    setFormError('');
    setFormSuccess(false);
    
    const asset = assets.find(a => a.id === assetId);
    if (asset) {
      let initialPrice = '';
      let initialItems: UsedPartItem[] = [];

      if (asset.usedPartItems && asset.usedPartItems.length > 0) {
        initialItems = asset.usedPartItems.map(item => {
          return {
            ...item,
            unitPrice: 0,
            totalPrice: 0
          };
        });
        initialPrice = '0';
      }

      setItemBids(initialItems);
      setBidForm({
        name: isUserLoggedIn ? loggedInUserName : '',
        email: isUserLoggedIn ? loggedInUserEmail : '',
        contact: isUserLoggedIn ? loggedInUserPhone : '',
        price: initialPrice,
        requestSurvey: false,
        surveyDate: '',
        surveyTime: '09:00'
      });
      setAgreedToTerms(false);
    }
  };

  // Helper to update unit price for an individual spare part item
  const handleItemUnitPriceChange = (index: number, newUnitPrice: number) => {
    setItemBids(prev => {
      const updated = [...prev];
      const target = updated[index];
      if (target) {
        const qty = Number(target.qty) || 1;
        const validPrice = Math.max(0, newUnitPrice);
        updated[index] = {
          ...target,
          unitPrice: validPrice,
          totalPrice: qty * validPrice
        };
      }
      const sum = updated.reduce((acc, it) => acc + (it.totalPrice || 0), 0);
      setBidForm(b => ({ ...b, price: String(sum) }));
      return updated;
    });
  };

  const handleItemQuickAdd = (index: number, delta: number) => {
    const currentPrice = Number(itemBids[index]?.unitPrice) || 0;
    handleItemUnitPriceChange(index, currentPrice + delta);
  };

  const isAuctionClosed = selectedAsset?.closeBidDate 
    ? new Date() > new Date(selectedAsset.closeBidDate) 
    : false;

  const handleBidSubmit = (e?: React.FormEvent, forceConfirm: boolean = false) => {
    if (e) e.preventDefault();
    setFormError('');
    setFormSuccess(false);

    if (!selectedAssetId || !selectedAsset) return;

    if (!canBid) {
      setFormError(t('Akun Anda saat ini diatur sebagai "Hanya Lihat". Anda tidak dapat melakukan penawaran lelang.'));
      return;
    }

    if (isAuctionClosed) {
      setFormError(t('Maaf, lelang untuk unit ini sudah ditutup karena telah melewati batas waktu penutupan.'));
      return;
    }

    const bidPriceNum = Number(bidForm.price);

    // 1. Validation
    if (!bidForm.name || !bidForm.email || !bidForm.contact || !bidForm.price || isNaN(bidPriceNum) || bidPriceNum <= 0) {
      setFormError(t('Mohon lengkapi semua data dan masukkan nominal penawaran (bid) yang valid.'));
      return;
    }

    // Per-item validation if asset is Used Part
    if (itemBids.length > 0) {
      const hasEmptyItem = itemBids.some(it => !it.unitPrice || it.unitPrice <= 0);
      if (hasEmptyItem) {
        setFormError(t('Mohon isi nominal penawaran harga satuan untuk setiap tipe suku cadang.'));
        return;
      }
    }

    if (!agreedToTerms) {
      setFormError(t('Anda wajib membaca dan menyetujui Syarat & Ketentuan Lelang.'));
      return;
    }

    // Starting price validation: bid price cannot be below starting price
    const startingPrice = selectedAsset.startingPrice || 0;
    if (startingPrice > 0 && bidPriceNum < startingPrice) {
      setFormError(
        t('Nominal penawaran tidak boleh lebih rendah dari harga awal (starting price) sebesar {price}.', {
          price: formatIDR(startingPrice)
        })
      );
      return;
    }

    // Existing bids validation: bid MUST be strictly higher than the current highest bid
    const existingValidBids = (selectedAsset.bids || [])
      .filter(b => b && typeof b.price === 'number' && !isNaN(b.price) && b.price < 1000000000)
      .map(b => b.price);
    const highestExistingBid = existingValidBids.length > 0 ? Math.max(...existingValidBids) : 0;

    if (highestExistingBid > 0 && bidPriceNum <= highestExistingBid) {
      setFormError(
        t('Penawaran gagal! Nominal penawaran Anda ({yourBid}) harus lebih tinggi dari penawaran tertinggi saat ini ({highestBid}). Silakan masukkan nominal penawaran yang lebih tinggi.', {
          yourBid: formatIDR(bidPriceNum),
          highestBid: formatIDR(highestExistingBid)
        })
      );
      return;
    }

    // Maximum bid validation: cannot be > 50% above starting price
    const maxAllowedBid = startingPrice > 0 ? startingPrice * 1.5 : 0;
    if (startingPrice > 0 && bidPriceNum > maxAllowedBid) {
      setFormError(
        t('Penawaran gagal! Nominal penawaran melebihi 50% dari harga awal. Mohon cek kembali nominal pengisian Anda.')
      );
      return;
    }

    // Survey Validation if checked
    if (bidForm.requestSurvey) {
      if (!bidForm.surveyDate) {
        setFormError(t('Mohon tentukan tanggal rencana survei fisik.'));
        return;
      }
      if (isTimeBooked(bidForm.surveyTime, bidForm.surveyDate, selectedAsset?.category)) {
        const isPart = normalizeCategory(selectedAsset?.category) === 'Used part';
        setFormError(
          t(`Jadwal survei pada tanggal dan jam tersebut untuk area ${isPart ? 'Gudang Suku Cadang' : 'Pool Kendaraan'} sudah di-booking oleh calon pembeli lain. Mohon pilih waktu atau hari lain.`)
        );
        return;
      }
    }

    // Check if bid price is 50% or more above the starting price or current highest bid
    const isHighBidThanStarting = startingPrice > 0 && bidPriceNum >= (startingPrice * 1.5);
    const isHighBidThanCurrent = currentHighestBid > 0 && bidPriceNum >= (currentHighestBid * 1.5);

    if ((isHighBidThanStarting || isHighBidThanCurrent) && !forceConfirm) {
      setShowBidConfirmModal(true);
      return;
    }

    // 2. Submit
    onPlaceBid(selectedAssetId, {
      name: bidForm.name,
      email: bidForm.email,
      contact: bidForm.contact,
      price: bidPriceNum,
      itemBids: itemBids.length > 0 ? itemBids : undefined,
      scheduleSurveyDate: bidForm.requestSurvey ? bidForm.surveyDate : undefined,
      scheduleSurveyTime: bidForm.requestSurvey ? bidForm.surveyTime : undefined,
    });

    setShowBidConfirmModal(false);
    setFormSuccess(true);
    setFormError('');

    // Reset bid form fields but keep values for success display
    setTimeout(() => {
      setSelectedAssetId(null);
      setFormSuccess(false);
    }, 4500);
  };

  return (
    <div id="catalog-view-root">
      <div className="space-y-8 animate-fade-in" id="public-catalog-container">
      

      {/* Premium Hero Banner for Public Bidders */}
      <div className="relative w-full overflow-hidden bg-slate-950 text-white border-t border-slate-800 pt-8 md:pt-12 pb-16 md:pb-24">
        {/* Subtle left-side text protection gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/85 via-slate-950/40 to-slate-950/10 pointer-events-none z-0"></div>
        
        {/* Banner Background Video - Bright & Normal Clarity */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover opacity-100"
            src="https://res.cloudinary.com/x6bejifd/video/upload/v1786613786/vidssave.com_Pancaran_Group_720P_uosct4.mp4"
          />
        </div>

        {/* Soft bottom edge transition */}
        <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-slate-50 via-slate-50/20 to-transparent pointer-events-none z-5"></div>

        {/* Navigation Tabs (Overlayed inside the hero background) */}
        {navigationTabs ? (
          <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 relative z-20 mb-8 md:mb-10">
            {navigationTabs}
          </div>
        ) : (
          /* Empty spacer to maintain identical banner size/height and background image layout before login */
          <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 relative z-20 mb-8 md:mb-10 h-[46px]"></div>
        )}

        {/* Content Container (Centered to match the site width) */}
        <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 relative z-10 flex flex-col lg:flex-row justify-between items-center gap-6">
          <div className="space-y-4 lg:max-w-xl xl:max-w-2xl">
            <span className="text-[10px] uppercase tracking-wider bg-blue-500/20 text-blue-300 font-bold px-3 py-1.5 rounded-full border border-blue-500/30">
              {t('Portal Penawaran Umum (External)')}
            </span>
            <h1 className="text-2xl md:text-3xl xl:text-4xl font-bold tracking-tight leading-tight text-white flex flex-col gap-1">
              <span className="text-3xl md:text-4xl xl:text-5xl font-black tracking-wider bg-gradient-to-r from-white via-slate-100 to-blue-200 bg-clip-text text-transparent">
                PLATINUM
              </span>
              <span className="text-xs md:text-sm font-semibold text-slate-300 tracking-wide mt-0.5 opacity-90 leading-normal max-w-lg block">
                ( Pancaran Lelang Angkutan Truk, Industri, & Niaga Utama Modern )
              </span>
              <span className="bg-gradient-to-r from-blue-400 to-blue-200 bg-clip-text text-transparent">
                {t('Truck & Heavy Equipment')}
              </span>
            </h1>
            <p className="text-slate-400 text-xs md:text-sm leading-relaxed">
              {t('Dapatkan truk tangki, wingbox, trailer, cargo van, dan alat berat kualitas terbaik langsung dari ekosistem operasional Pancaran Logistics. Transparan, terpercaya, dan aman dengan jadwal survei fisik mandiri.')}
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-1 text-xs text-slate-300 font-medium">
              <span className="flex items-center gap-1.5 bg-slate-900/90 px-3 py-1.5 rounded-xl border border-slate-800">
                <CheckCircle className="w-4 h-4 text-emerald-400" /> {t('KIR & STNK Lengkap')}
              </span>
              <span className="flex items-center gap-1.5 bg-slate-900/90 px-3 py-1.5 rounded-xl border border-slate-800">
                <CalendarCheck className="w-4 h-4 text-blue-400" /> {t('Bebas Atur Waktu Inspeksi')}
              </span>
            </div>
          </div>

          {/* Right Side: How It Works Card */}
          <div className="flex flex-col sm:flex-row items-stretch gap-4 shrink-0 w-full lg:w-auto lg:absolute lg:top-[62%] lg:-translate-y-[38%] lg:right-8 lg:z-20 lg:bottom-auto">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-transparent text-white rounded-3xl p-5 sm:p-6 border border-slate-800/60 shadow-none max-w-sm w-full sm:w-80 flex flex-col justify-between gap-3.5 z-30 select-none relative group"
              id="how-it-works-before-login-card"
            >
              <div className="space-y-2.5">
                <div className="flex items-center gap-2">
                  <span className="text-base sm:text-lg">💡</span>
                  <h3 className="text-white font-extrabold text-sm sm:text-base tracking-tight uppercase">
                    {t('Step By Step Lelang ?')}
                  </h3>
                </div>
                <p className="text-slate-300 font-medium text-[11px] sm:text-xs leading-relaxed">
                  {t('Pilih armada aktif di bawah, ajukan penawaran harga Anda, dan pilih waktu survei fisik untuk memeriksa kondisi mesin langsung di Pool kami sebelum lelang ditutup.')}
                </p>
              </div>
              
              <div className="flex items-center justify-between border-t border-slate-800/80 pt-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                <span>Pancaran Platinum</span>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 pb-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        
        {/* Left Side: Public Catalog Grid */}
        <div className="space-y-6 lg:col-span-3" id="public-catalog-catalog-col">
          
          {/* Mode Hanya Lihat Informational Banner */}
          {isUserLoggedIn && !canBid && (
            <div className="p-4 bg-amber-50/90 border border-amber-200/90 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-amber-900 shadow-2xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-700 shrink-0">
                  <Eye className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-extrabold text-xs uppercase tracking-wider text-amber-950">
                      {t('Akses Hanya Lihat (Katalog & Postingan Terbuka)')}
                    </h4>
                    <span className="bg-amber-200/80 text-amber-900 text-[9px] font-extrabold px-2 py-0.5 rounded-full border border-amber-300/60 uppercase">
                      {t('Akses Terbuka')}
                    </span>
                  </div>
                  <p className="text-xs text-amber-800 font-medium mt-0.5">
                    {t('Anda dapat menjelajahi seluruh katalog secara bebas. Untuk melakukan bidding, diperlukan deposit jaminan Rp10.000.000 (Refundable 100%).')}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => onOpenGuideModal && onOpenGuideModal('ikut')}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-[10px] font-extrabold rounded-xl transition shadow-sm shrink-0 uppercase tracking-wider"
              >
                {t('Pelajari Cara Ikut Lelang')}
              </button>
            </div>
          )}

          {/* Category Access Restriction Banner */}
          {userAllowedCategoryAccess && userAllowedCategoryAccess !== 'All' && (
            <div className="p-4 bg-indigo-50/90 border border-indigo-200/90 rounded-2xl flex items-center justify-between gap-3 text-indigo-900 shadow-2xs animate-fade-in">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-sm shrink-0">
                  {userAllowedCategoryAccess === 'Vehicle' ? '🚛' : userAllowedCategoryAccess === 'Used part' ? '⚙️' : userAllowedCategoryAccess === 'Property' ? '🏢' : '🔒'}
                </div>
                <div>
                  <h4 className="font-extrabold text-xs uppercase tracking-wider text-indigo-950 flex items-center gap-2">
                    {t('Akses Kategori Dibatasi')}
                    <span className="bg-indigo-200/80 text-indigo-900 text-[9px] font-extrabold px-2 py-0.5 rounded-full border border-indigo-300/60">
                      {userAllowedCategoryAccess === 'Vehicle' ? t('Kendaraan Saja') :
                       userAllowedCategoryAccess === 'Used part' ? t('Spare Part Saja') :
                       userAllowedCategoryAccess === 'Property' ? t('Property Saja') : userAllowedCategoryAccess}
                    </span>
                  </h4>
                  <p className="text-xs text-indigo-800 font-medium mt-0.5">
                    {t('Akun Anda saat ini diset oleh Admin untuk mengakses asset kategori')} <strong>{
                      userAllowedCategoryAccess === 'Vehicle' ? t('Kendaraan (Vehicle)') :
                      userAllowedCategoryAccess === 'Used part' ? t('Spare Part (Suku Cadang)') :
                      userAllowedCategoryAccess === 'Property' ? t('Property') : userAllowedCategoryAccess
                    }</strong>.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Public Filters Header */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-800">{t('Katalog Armada Tersedia')} ({filteredAssets.length})</h2>
              <p className="text-xs text-slate-500 mt-0.5">{t('Semua armada di bawah siap dilepas dengan penawaran harga terbaik.')}</p>
            </div>

            {/* Filter Controls */}
            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
              {/* Search */}
              <div className="flex items-center gap-2 w-full md:w-80 shrink-0">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    placeholder={t('Cari armada...')}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-8 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-xs font-medium bg-slate-50/50 focus:bg-white transition-all"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 p-0.5 rounded-full hover:bg-slate-100 cursor-pointer"
                      title={t('Hapus')}
                    >
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  )}
                </div>
                <button
                  type="button"
                  id="catalog-search-button"
                  className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-xs font-extrabold rounded-xl shadow-sm transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
                  onClick={() => {
                    // Clicking search button triggers a soft refresh or focuses input to indicate search action
                    const inputEl = document.querySelector('input[placeholder="Cari armada..."]') as HTMLInputElement;
                    if (inputEl) {
                      inputEl.focus();
                    }
                  }}
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>{t('Cari')}</span>
                </button>
              </div>

              {isUserLoggedIn && (
                <div className="flex gap-2 w-full sm:w-auto flex-1 sm:flex-initial">
                  {/* Brand Select */}
                  <select
                    value={selectedBrand}
                    onChange={(e) => setSelectedBrand && setSelectedBrand(e.target.value)}
                    className="flex-1 sm:flex-initial px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer"
                  >
                    <option value="all">{t('Semua Brand')}</option>
                    {uniqueBrands.map(b => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </select>

                  {/* Category Select */}
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory && setSelectedCategory(e.target.value)}
                    className="flex-1 sm:flex-initial px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer"
                  >
                    <option value="all">{t('Semua Kategori')}</option>
                    {uniqueCategories.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>

                  {/* Manifest Select */}
                  {(selectedCategory === 'all' || selectedCategory === 'Used part') && (
                    <select
                      value={selectedManifest}
                      onChange={(e) => setSelectedManifest(e.target.value)}
                      className="flex-1 sm:flex-initial px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer"
                    >
                      <option value="all">{t('Semua Manifest')}</option>
                      {manifestOptions.map(m => (
                        <option key={m} value={m}>{t(m)}</option>
                      ))}
                    </select>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Catalog Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAssets.map((asset) => (
              <CatalogCard
                key={asset.id}
                asset={asset}
                onSelectAsset={handleSelectAsset}
                formatIDR={formatIDR}
                onZoomImage={(imgs, idx) => {
                  setLightboxImages(imgs);
                  setLightboxIndex(idx);
                }}
                isUserLoggedIn={isUserLoggedIn}
                onOpenLoginModal={onOpenLoginModal}
                canBid={canBid}
              />
            ))}

            {filteredAssets.length === 0 && (
              <div className="col-span-full text-center py-16 bg-white border border-slate-100 rounded-3xl space-y-4 px-6 max-w-lg mx-auto shadow-sm">
                <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center mx-auto text-blue-600">
                  <Info className="w-6 h-6" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-base font-extrabold text-slate-800 tracking-tight">
                    {t('Belum Ada Unit Tersedia')}
                  </h3>
                  <p className="text-slate-500 text-xs leading-relaxed max-w-sm mx-auto font-medium">
                    {t('Saat ini Pancaran Lelang belum memiliki aset yang sedang dilelang. Nantikan pembaharuan unit terbaru kami dalam waktu dekat. Terima kasih atas perhatian Anda! 👋')}
                  </p>
                </div>
                {openAssets.length > 0 && (
                  <div className="pt-2">
                    <button 
                      onClick={() => { setSelectedBrand('all'); setSelectedCategory('all'); setSearchQuery(''); }}
                      className="inline-flex items-center justify-center px-4 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 hover:border-slate-300 text-xs text-blue-600 hover:text-blue-700 font-bold rounded-xl transition duration-150 cursor-pointer"
                    >
                      {t('Lihat Semua Koleksi')}
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
      </div>
      {/* Right Side Overlay: OLX-inspired Beautiful Detail Page View */}
      {selectedAsset && createPortal(
        <div 
          className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-[999999] flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-hidden animate-fade-in"
          id="bidding-modal-overlay"
          onClick={() => setSelectedAssetId(null)}
        >
          <div 
            className="bg-slate-50 rounded-3xl border border-slate-200/80 shadow-2xl w-full max-w-5xl h-full max-h-[90vh] sm:max-h-[92vh] flex flex-col overflow-hidden relative animate-scale-in my-auto focus:outline-none transition-all duration-300 shrink-0"
            id="bidding-survey-panel"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Persistent Top Floating Action Bar inside Modal */}
            <div className="absolute top-3 left-4 right-4 z-50 flex items-center justify-between pointer-events-none">
              <button 
                type="button"
                onClick={() => setSelectedAssetId(null)}
                className="pointer-events-auto flex items-center gap-1.5 bg-slate-900/85 hover:bg-slate-900 text-white px-3.5 py-1.5 rounded-full text-xs font-bold shadow-lg backdrop-blur-md transition-all cursor-pointer border border-white/10 active:scale-95"
                title={t('Kembali ke Katalog')}
              >
                <ChevronLeft className="w-4 h-4" />
                <span>{t('Kembali')}</span>
              </button>

              <button 
                type="button"
                onClick={() => setSelectedAssetId(null)}
                className="pointer-events-auto flex items-center justify-center bg-slate-900/85 hover:bg-slate-900 text-white w-9 h-9 rounded-full shadow-lg backdrop-blur-md transition-all cursor-pointer border border-white/10 active:scale-95"
                title={t('Tutup')}
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
             {/* Scrollable Container */}
             <div id="bidding-modal-scroll-container" className="overflow-y-auto flex-1 custom-scrollbar scrollbar-thin scrollbar-thumb-indigo-400 relative overscroll-contain">
               
               {/* Focus mode background dim overlay */}
               {isFormFocused && (
                 <div 
                   className="absolute inset-0 bg-slate-950/30 backdrop-blur-[0.5px] z-30 transition-all duration-300 cursor-pointer"
                   onClick={() => {
                     if (document.activeElement instanceof HTMLElement) {
                       document.activeElement.blur();
                     }
                     setIsFormFocused(false);
                   }}
                 />
               )}
              
              {/* Top Section: Immersive Dark Image Carousel */}
              <div className="relative bg-slate-950 h-[280px] sm:h-[320px] md:h-[380px] flex items-center justify-center group/modal-img border-b border-slate-800">
                {(() => {
                  const rawDetailImages = selectedAsset.imageUrls && selectedAsset.imageUrls.length > 0 
                    ? selectedAsset.imageUrls 
                    : (selectedAsset.imageUrl ? [selectedAsset.imageUrl] : []);
                  const detailImages = rawDetailImages.filter(url => url && typeof url === 'string' && url.trim() !== '');
                  const isUsedPartModal = normalizeCategory(selectedAsset.category) === 'Used part' || (selectedAsset.usedPartItems && selectedAsset.usedPartItems.length > 0);
                  
                  return (
                    <>
                {detailImages.length > 0 ? (
                  <img 
                    src={detailImages[modalImageIdx] || detailImages[0]} 
                    alt={`${selectedAsset.name} - ${modalImageIdx + 1}`} 
                    className="h-full w-auto max-w-full object-contain cursor-zoom-in hover:scale-[1.01] transition-transform duration-300" 
                    referrerPolicy="no-referrer"
                    onClick={() => {
                      setLightboxImages(detailImages);
                      setLightboxIndex(modalImageIdx);
                    }}
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                ) : (
                  <div className={`w-full h-full flex flex-col items-center justify-center gap-3 select-none py-16 ${isUsedPartModal ? 'bg-slate-900 text-slate-400' : 'bg-slate-100 text-slate-400'}`}>
                    <div className={`p-4 rounded-3xl ${isUsedPartModal ? 'bg-slate-800 border border-slate-700' : 'bg-white border border-slate-200 shadow-sm'}`}>
                      <CameraOff className="w-10 h-10 text-slate-400" />
                    </div>
                    <div className="text-center">
                      <p className="text-sm font-bold text-slate-600">{t('Tidak Ada Foto')}</p>
                      <p className="text-xs text-slate-400 mt-0.5">{t('Foto unit atau aset belum diunggah')}</p>
                    </div>
                  </div>
                )}
                
                {/* Zoom overlay button to see the image full */}
                {detailImages.length > 0 && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLightboxImages(detailImages);
                      setLightboxIndex(modalImageIdx);
                    }}
                    className="absolute bottom-4 left-4 z-20 flex items-center gap-1.5 bg-black/60 hover:bg-black/85 text-white px-3.5 py-2 rounded-xl text-xs font-bold border border-white/10 transition-all cursor-pointer shadow-lg hover:scale-105"
                    title={t('Lihat Gambar Full')}
                  >
                    <ZoomIn className="w-4 h-4" />
                    <span>{t('Lihat Gambar Full')}</span>
                  </button>
                )}

                {/* Prev/Next Overlay buttons */}
                {detailImages.length > 1 && (
                  <>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setModalImageIdx(prev => (prev === 0 ? detailImages.length - 1 : prev - 1));
                      }}
                      className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/60 hover:bg-black/85 text-white p-2.5 rounded-full transition-all group-hover/modal-img:scale-105 flex items-center justify-center w-10 h-10"
                      title={t('Sebelumnya')}
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setModalImageIdx(prev => (prev === detailImages.length - 1 ? 0 : prev + 1));
                      }}
                      className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/60 hover:bg-black/85 text-white p-2.5 rounded-full transition-all group-hover/modal-img:scale-105 flex items-center justify-center w-10 h-10"
                      title={t('Berikutnya')}
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                    
                    {/* Image position label */}
                    <span className="absolute bottom-4 right-4 bg-black/75 backdrop-blur-xs text-white text-[11px] px-3 py-1.5 rounded-lg font-mono font-bold border border-white/10">
                      {modalImageIdx + 1} / {detailImages.length}
                    </span>
                  </>
                )}
                    </>
                  );
                })()}
              </div>

              {/* Bottom Layout: Two-Column Responsive Grid */}
              <div className="p-4 sm:p-6 md:p-8 pb-14 sm:pb-16 md:pb-20 grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 items-start">
                
                {/* Left Side Content (lg:col-span-2) */}
                <div className="lg:col-span-2 space-y-6">
                  
                  {/* Title & Badge card */}
                  <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
                    <div className="flex flex-wrap gap-2">
                      <span className="bg-amber-500 text-white text-[10px] font-extrabold px-3 py-1 rounded-md shadow-xs tracking-wider uppercase">
                        ⭐ {t('UNIT PILIHAN')}
                      </span>
                      <span className="bg-emerald-500 text-white text-[10px] font-extrabold px-3 py-1 rounded-md shadow-xs tracking-wider uppercase">
                        {t('BOOKING AMAN')}
                      </span>
                      <span className="bg-blue-600 text-white text-[10px] font-extrabold px-3 py-1 rounded-md shadow-xs tracking-wider uppercase">
                        {t('VERIFIED SELLER')}
                      </span>
                    </div>

                    <div className="space-y-1">
                      <h1 className="text-2xl font-bold text-slate-800 tracking-tight leading-snug">
                        {getCleanAssetName(selectedAsset)}
                      </h1>
                      <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">
                        {selectedAsset.brand && normalizeCategory(selectedAsset.category) === 'Vehicle' ? `${selectedAsset.brand} • ` : ''}{t(selectedAsset.category)}{normalizeCategory(selectedAsset.category) === 'Vehicle' && selectedAsset.modelYear ? ` • ${t('Tahun')} ${selectedAsset.modelYear}` : ''}
                      </p>
                    </div>

                    {selectedAsset.closeBidDate && (
                      isAuctionClosed ? (
                        <div className="flex items-center gap-2.5 bg-rose-50 border border-rose-200 p-3.5 rounded-2xl text-rose-800">
                          <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
                          <div className="text-xs font-semibold">
                            <p className="font-bold uppercase tracking-wide text-rose-600 text-[10px]">{t('Lelang Ditutup')}</p>
                            <p>{t('Lelang untuk unit ini telah resmi ditutup pada')} {new Date(selectedAsset.closeBidDate).toLocaleString('id-ID', { dateStyle: 'long', timeStyle: 'short' })}</p>
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3.5 bg-amber-50/70 border border-amber-200/80 p-3.5 rounded-2xl text-amber-900">
                          <div className="flex items-start gap-2.5">
                            <Clock className="w-5 h-5 text-amber-500 shrink-0 mt-0.5 animate-pulse-hover" />
                            <div className="text-xs font-semibold">
                              <p className="font-bold uppercase tracking-wide text-amber-800 text-[10px]">{t('Batas Waktu Bidding')}</p>
                              <p className="leading-relaxed">{t('Lelang ini akan ditutup secara otomatis pada')} {new Date(selectedAsset.closeBidDate).toLocaleString('id-ID', { dateStyle: 'long', timeStyle: 'short' })}</p>
                            </div>
                          </div>
                          <div className="flex flex-col items-start sm:items-end shrink-0 pl-7 sm:pl-0">
                            <span className="text-[9px] font-bold text-amber-800 uppercase tracking-wider mb-1 block">{t('Sisa Waktu')}</span>
                            <CountdownTimer targetDate={selectedAsset.closeBidDate} size="large" />
                          </div>
                        </div>
                      )
                    )}

                    {/* Top Quick Attributes Bar */}
                    {normalizeCategory(selectedAsset.category) === 'Used part' ? (
                      <div className="border-t border-slate-100 pt-4 grid grid-cols-1 md:grid-cols-2 gap-3.5">
                        <div className="flex items-center gap-2.5 text-slate-600">
                          <div className="p-2 bg-slate-50 border border-slate-100 rounded-xl">
                            <Layers className="w-4 h-4 text-blue-600" />
                          </div>
                          <div className="text-xs font-semibold">
                            <p className="text-slate-400 text-[9px] uppercase tracking-wide">{t('Kategori / Suku Cadang')}</p>
                            <p className="text-slate-700 font-bold">{selectedAsset.usedPartCategory || selectedAsset.category} {selectedAsset.usedPartItems && selectedAsset.usedPartItems.length > 0 ? `(${selectedAsset.usedPartItems.length} Tipe Item)` : ''}</p>
                          </div>
                        </div>

                        {selectedAsset.coordinates && getGoogleMapsUrl(selectedAsset.coordinates) ? (
                          <a 
                            href={getGoogleMapsUrl(selectedAsset.coordinates)!}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2.5 text-slate-600 hover:text-blue-600 transition-colors group cursor-pointer"
                          >
                            <div className="p-2 bg-blue-50 border border-blue-100 group-hover:bg-blue-100 group-hover:border-blue-200 rounded-xl transition-all">
                              <MapPin className="w-4 h-4 text-blue-600" />
                            </div>
                            <div className="text-xs font-semibold">
                              <p className="text-slate-400 text-[9px] uppercase tracking-wide flex items-center gap-1">
                                {t('Lokasi Pool / Gudang')}
                                <ArrowUpRight className="w-3 h-3 text-blue-500 opacity-60 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                              </p>
                              <p className="text-blue-600 font-bold line-clamp-1 underline decoration-blue-200 hover:decoration-blue-600">{selectedAsset.location.split(',')[0]}</p>
                            </div>
                          </a>
                        ) : (
                          <div className="flex items-center gap-2.5 text-slate-600">
                            <div className="p-2 bg-slate-50 border border-slate-100 rounded-xl">
                              <MapPin className="w-4 h-4 text-blue-600" />
                            </div>
                            <div className="text-xs font-semibold">
                              <p className="text-slate-400 text-[9px] uppercase tracking-wide">{t('Lokasi Pool / Gudang')}</p>
                              <p className="text-slate-700 line-clamp-1">{selectedAsset.location.split(',')[0]}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="border-t border-slate-100 pt-4 grid grid-cols-1 md:grid-cols-3 gap-3.5">
                        <div className="flex items-center gap-2.5 text-slate-600">
                          <div className="p-2 bg-slate-50 border border-slate-100 rounded-xl">
                            <Tag className="w-4 h-4 text-blue-600" />
                          </div>
                          <div className="text-xs font-semibold">
                            <p className="text-slate-400 text-[9px] uppercase tracking-wide">{t('Bahan Bakar')}</p>
                            <p className="text-slate-700">SOLAR / DIESEL</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2.5 text-slate-600">
                          <div className="p-2 bg-slate-50 border border-slate-100 rounded-xl">
                            <Truck className="w-4 h-4 text-blue-600" />
                          </div>
                          <div className="text-xs font-semibold">
                            <p className="text-slate-400 text-[9px] uppercase tracking-wide">{t('No. Polisi')}</p>
                            <p className="text-slate-700 font-mono uppercase">{selectedAsset.plateNumber}</p>
                          </div>
                        </div>

                        {selectedAsset.coordinates && getGoogleMapsUrl(selectedAsset.coordinates) ? (
                          <a 
                            href={getGoogleMapsUrl(selectedAsset.coordinates)!}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2.5 text-slate-600 hover:text-blue-600 transition-colors group cursor-pointer"
                          >
                            <div className="p-2 bg-blue-50 border border-blue-100 group-hover:bg-blue-100 group-hover:border-blue-200 rounded-xl transition-all">
                              <MapPin className="w-4 h-4 text-blue-600" />
                            </div>
                            <div className="text-xs font-semibold">
                              <p className="text-slate-400 text-[9px] uppercase tracking-wide flex items-center gap-1">
                                {t('Lokasi Pool')}
                                <ArrowUpRight className="w-3 h-3 text-blue-500 opacity-60 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                              </p>
                              <p className="text-blue-600 font-bold line-clamp-1 underline decoration-blue-200 hover:decoration-blue-600">{selectedAsset.location.split(',')[0]}</p>
                            </div>
                          </a>
                        ) : (
                          <div className="flex items-center gap-2.5 text-slate-600">
                            <div className="p-2 bg-slate-50 border border-slate-100 rounded-xl">
                              <MapPin className="w-4 h-4 text-blue-600" />
                            </div>
                            <div className="text-xs font-semibold">
                              <p className="text-slate-400 text-[9px] uppercase tracking-wide">{t('Lokasi Pool')}</p>
                              <p className="text-slate-700 line-clamp-1">{selectedAsset.location.split(',')[0]}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Ikhtisar Card */}
                  <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-5">
                    <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-2.5">
                      <Info className="w-4 h-4 text-blue-600" />
                      <span>{t('Ikhtisar Spesifikasi')}</span>
                    </h3>
                    
                    {/* Part A: Main Specifications - NOT shown for Used Part / Spare Part */}
                    {normalizeCategory(selectedAsset.category) !== 'Used part' && (
                      <div className="space-y-2">
                        <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{t('Spesifikasi Utama')}</h4>
                        <div className="grid grid-cols-3 gap-3 text-xs font-semibold">
                          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                            <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Merek / Brand')}</span>
                            <strong className="text-slate-900 font-bold text-sm">{selectedAsset.brand}</strong>
                          </div>
                          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                            <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Kategori')}</span>
                            <strong className="text-slate-900 font-bold text-sm">{selectedAsset.category}</strong>
                          </div>
                          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                            <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Tahun Registrasi')}</span>
                            <strong className="text-slate-900 font-bold text-sm">{selectedAsset.modelYear}</strong>
                          </div>
                          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                            <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('No Polisi')}</span>
                            <strong className="text-slate-900 font-bold text-sm font-mono uppercase">{selectedAsset.plateNumber || '-'}</strong>
                          </div>
                          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                            <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Kondisi Fisik')}</span>
                            <strong className="text-slate-900 font-bold text-sm">{t(selectedAsset.condition)}</strong>
                          </div>
                          {selectedAsset.usedPartCategory === 'Oli' && (
                            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                              <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Status Manifest')}</span>
                              <strong className={`font-bold text-sm ${selectedAsset.manifestStatus === 'Pake Manifest' ? 'text-emerald-700 font-extrabold' : 'text-slate-900 font-bold'}`}>
                                {t(selectedAsset.manifestStatus || 'Tidak Pake Manifest')}
                              </strong>
                            </div>
                          )}
                          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                            <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Lokasi Detail')}</span>
                            <strong className="text-slate-900 font-bold text-sm line-clamp-1">{selectedAsset.location}</strong>
                          </div>
                          {selectedAsset.coordinates && (
                            <div className="col-span-3 mt-1.5">
                              <MiniMapPreview 
                                coordinates={selectedAsset.coordinates} 
                                t={t} 
                              />
                            </div>
                          )}
                          
                          {/* Property specifications fields - Only show for Property category */}
                          {normalizeCategory(selectedAsset.category) === 'Property' && (
                            <>
                              {selectedAsset.propertyType && (
                                <div className="bg-blue-50/60 p-3 rounded-xl border border-blue-100/80">
                                  <span className="text-blue-600 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Tipe Properti')}</span>
                                  <strong className="text-slate-900 font-bold text-sm">{selectedAsset.propertyType}</strong>
                                </div>
                              )}
                              {selectedAsset.auctionType && (
                                <div className="bg-blue-50/60 p-3 rounded-xl border border-blue-100/80">
                                  <span className="text-blue-600 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Tipe Lelang')}</span>
                                  <strong className="text-blue-700 font-bold text-sm">{selectedAsset.auctionType}</strong>
                                </div>
                              )}
                              {selectedAsset.landArea && (
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                                  <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Luas Tanah')}</span>
                                  <strong className="text-slate-900 font-bold text-sm">{selectedAsset.landArea}</strong>
                                </div>
                              )}
                              {selectedAsset.buildingArea && (
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                                  <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Luas Bangunan')}</span>
                                  <strong className="text-slate-900 font-bold text-sm">{selectedAsset.buildingArea}</strong>
                                </div>
                              )}
                            </>
                          )}

                          {/* Vehicle specific specifications - Only show for Vehicle category */}
                          {normalizeCategory(selectedAsset.category) === 'Vehicle' && (
                            <>
                              {selectedAsset.model && (
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                                  <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Model')}</span>
                                  <strong className="text-slate-900 font-bold text-sm">{selectedAsset.model}</strong>
                                </div>
                              )}
                              {selectedAsset.series && (
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                                  <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Series')}</span>
                                  <strong className="text-slate-900 font-bold text-sm">{selectedAsset.series}</strong>
                                </div>
                              )}
                              {selectedAsset.axels && (
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                                  <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Axels')}</span>
                                  <strong className="text-slate-900 font-bold text-sm">{selectedAsset.axels}</strong>
                                </div>
                              )}
                              {selectedAsset.vehicleColour && (
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                                  <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Warna')}</span>
                                  <strong className="text-slate-900 font-bold text-sm">{t(selectedAsset.vehicleColour)}</strong>
                                </div>
                              )}
                              {selectedAsset.fuelType && (
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                                  <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Bahan Bakar')}</span>
                                  <strong className="text-slate-900 font-bold text-sm">{t(selectedAsset.fuelType)}</strong>
                                </div>
                              )}
                              {selectedAsset.horsepower && (
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                                  <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Horsepower (HP)')}</span>
                                  <strong className="text-slate-900 font-bold text-sm">{selectedAsset.horsepower}</strong>
                                </div>
                              )}
                              {selectedAsset.odometer && (
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                                  <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('KM Spidometer')}</span>
                                  <strong className="text-slate-900 font-bold text-sm">{selectedAsset.odometer}</strong>
                                </div>
                              )}
                              {selectedAsset.dimensions && (
                                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100/85">
                                  <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Dimensi Unit')}</span>
                                  <strong className="text-slate-900 font-bold text-sm font-mono">{selectedAsset.dimensions}</strong>
                                </div>
                              )}
                            </>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Used Part Dedicated Section */}
                    {normalizeCategory(selectedAsset.category) === 'Used part' && (
                      <div className="space-y-4">
                        {/* Itemized Table for Used Part Asset */}
                        {normalizeCategory(selectedAsset.category) === 'Used part' && selectedAsset.usedPartItems && selectedAsset.usedPartItems.length > 0 && (() => {
                          const { highestBidObj, highestItemBids } = getHighestBidBreakdown(selectedAsset);
                          const totalQty = selectedAsset.usedPartItems.reduce((acc, it) => acc + (Number(it.qty) || 0), 0);
                          const grandTotalAwal = selectedAsset.usedPartItems.reduce((acc, it) => {
                            const q = Number(it.qty) || 0;
                            const p = Number(it.unitPrice) || 0;
                            return acc + (typeof it.totalPrice === 'number' ? it.totalPrice : (q * p));
                          }, 0);

                          return (
                            <div className="space-y-2 pt-2">
                              <div className="flex items-center justify-between gap-2 flex-wrap">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-[11px] text-slate-700 font-bold uppercase tracking-wider flex items-center gap-1.5">
                                    <Layers className="w-4 h-4 text-blue-600" />
                                    {t('Tabel Rincian Item / Tipe Suku Cadang')}
                                  </span>
                                </div>
                              </div>
                              
                              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-xs">
                                {(() => {
                                  return (
                                    <table className="w-full text-left text-xs border-collapse">
                                      <thead>
                                        <tr className="bg-[#b8cce4] text-slate-900 font-bold border-b border-slate-300 text-[11px]">
                                          <th className="py-2.5 px-2 text-center min-w-[40px] border-r border-slate-300/70">{t('No.')}</th>
                                          <th className="py-2.5 px-3 min-w-[170px] border-r border-slate-300/70">{t('Nama Barang / Type')}</th>
                                          <th className="py-2.5 px-3 min-w-[200px] border-r border-slate-300/70">{t('Spesifikasi / Ukuran')}</th>
                                          <th className="py-2.5 px-2 text-center min-w-[75px] border-r border-slate-300/70">{t('QTY')}</th>
                                          <th className="py-2.5 px-2 text-center min-w-[85px] border-r border-slate-300/70">{t('UOM')}</th>
                                          <th className="py-2.5 px-3 min-w-[180px] border-r border-slate-300/70 text-left">{t('Keterangan')}</th>
                                          <th className="py-2.5 px-3 text-right min-w-[145px] border-r border-slate-300/70 bg-emerald-100/70 text-emerald-950 font-extrabold">{t('Highest Bid Satuan')}</th>
                                          <th className="py-2.5 px-3 text-right min-w-[145px] bg-emerald-100/90 text-emerald-950 font-extrabold">{t('Total Highest Bid')}</th>
                                        </tr>
                                      </thead>
                                      <tbody className="divide-y divide-slate-100 text-[11px]">
                                        {selectedAsset.usedPartItems.map((item, idx) => {
                                          const q = Number(item.qty) || 0;
                                          const hbItem = highestItemBids[idx];
                                          const hbUnit = Number(hbItem?.unitPrice) || 0;
                                          const hbTot = typeof hbItem?.totalPrice === 'number' ? hbItem.totalPrice : (q * hbUnit);

                                          return (
                                            <tr key={idx} className="hover:bg-slate-50">
                                              <td className="py-2 px-2 text-center font-bold text-slate-500 bg-slate-50/50 border-r border-slate-100">{idx + 1}</td>
                                              <td className="py-2 px-3 font-semibold text-slate-800 border-r border-slate-100">{item.name || item.type || '-'}</td>
                                              <td className="py-2 px-3 text-slate-600 border-r border-slate-100">{item.spec || '-'}</td>
                                              <td className="py-2 px-2 text-center font-mono font-bold text-blue-700 border-r border-slate-100">{item.qty || 0}</td>
                                              <td className="py-2 px-2 text-center text-slate-600 border-r border-slate-100">{item.uom || 'Pcs'}</td>
                                              <td className="py-2 px-3 text-slate-600 italic border-r border-slate-100">{item.notes || '-'}</td>
                                              <td className="py-2 px-3 text-right font-mono text-emerald-800 font-bold bg-emerald-50/40 border-r border-slate-100">{hbUnit > 0 ? formatIDR(hbUnit) : '-'}</td>
                                              <td className="py-2 px-3 text-right font-mono text-emerald-800 font-bold bg-emerald-50/80">{hbTot > 0 ? formatIDR(hbTot) : '-'}</td>
                                            </tr>
                                          );
                                        })}
                                      </tbody>
                                      <tfoot>
                                        <tr className="bg-slate-50 border-t-2 border-slate-200 font-bold text-[11px]">
                                          <td colSpan={3} className="py-2.5 px-3 text-right text-slate-700">{t('Total Keseluruhan:')}</td>
                                          <td className="py-2.5 px-2 text-center font-mono text-blue-800 bg-blue-50/40 border-r border-slate-200">{totalQty}</td>
                                          <td colSpan={2} className="py-2.5 px-3 text-right text-slate-400"></td>
                                          <td className="py-2.5 px-3 text-right text-emerald-900 font-bold bg-emerald-100/40 border-r border-slate-200">{t('Grand Total Bid')}</td>
                                          <td className="py-2.5 px-3 text-right font-mono text-xs text-emerald-900 bg-emerald-100/90 font-extrabold">{formatIDR(highestBidObj ? highestBidObj.price : 0)}</td>
                                        </tr>
                                      </tfoot>
                                    </table>
                                  );
                                })()}
                              </div>
                            </div>
                          );
                        })()}

                        {/* Location Detail & MiniMap for Used Part */}
                        <div className="pt-3 border-t border-slate-100 space-y-2">
                          <div className="flex items-center gap-2 text-xs">
                            <MapPin className="w-4 h-4 text-blue-600 shrink-0" />
                            <span className="text-slate-400 font-bold uppercase text-[10px]">{t('Lokasi Gudang / Pool')}:</span>
                            <span className="font-semibold text-slate-800">{selectedAsset.location}</span>
                          </div>
                          {selectedAsset.coordinates && (
                            <div className="mt-2">
                              <MiniMapPreview 
                                coordinates={selectedAsset.coordinates} 
                                t={t} 
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Part A.5: Documents & Legality */}
                    {(selectedAsset.keurValidUntil || selectedAsset.stnkPlateValidUntil || selectedAsset.stnkTaxValidUntil) && (
                      <div className="space-y-2 pt-3 border-t border-slate-100">
                        <h4 className="text-[10px] font-bold text-teal-600 uppercase tracking-wider">{t('Dokumen & Legalitas')}</h4>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-semibold">
                          {selectedAsset.keurValidUntil && (
                            <div className="bg-teal-50/40 p-3 rounded-xl border border-teal-100/60">
                              <span className="text-teal-600 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('KEUR Berlaku Hingga')}</span>
                              <strong className="text-slate-900 font-bold text-sm">{formatDateIndonesian(selectedAsset.keurValidUntil)}</strong>
                            </div>
                          )}
                          {selectedAsset.stnkPlateValidUntil && (
                            <div className="bg-teal-50/40 p-3 rounded-xl border border-teal-100/60">
                              <span className="text-teal-600 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Plat STNK Berlaku Hingga')}</span>
                              <strong className="text-slate-900 font-bold text-sm">{formatDateIndonesian(selectedAsset.stnkPlateValidUntil)}</strong>
                            </div>
                          )}
                          {selectedAsset.stnkTaxValidUntil && (
                            <div className="bg-teal-50/40 p-3 rounded-xl border border-teal-100/60">
                              <span className="text-teal-600 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Pajak STNK Berlaku Hingga')}</span>
                              <strong className="text-slate-900 font-bold text-sm">{formatDateIndonesian(selectedAsset.stnkTaxValidUntil)}</strong>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Part B: Attachment Specifications */}
                    {selectedAsset.haveAttachment && (
                      <div className="space-y-3 pt-3 border-t border-slate-100">
                        <div className="flex items-center justify-between">
                          <h4 className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider">{t('Spesifikasi Attachment')}</h4>
                          <span className="bg-indigo-50 text-indigo-700 text-[8px] font-bold px-2 py-0.5 rounded-md border border-indigo-100 uppercase">
                            {selectedAsset.attachmentCategory || 'Trailer'}
                          </span>
                        </div>

                        {/* Attachment Photo Display if available */}
                        {((selectedAsset.attachmentImageUrls && selectedAsset.attachmentImageUrls.length > 0) || selectedAsset.attachmentImageUrl) && (
                          <div className="flex gap-2 pb-2 overflow-x-auto">
                            {(selectedAsset.attachmentImageUrls || (selectedAsset.attachmentImageUrl ? [selectedAsset.attachmentImageUrl] : [])).map((imgUrl, idx) => (
                              <div key={idx} className="relative w-28 h-20 rounded-lg overflow-hidden border border-slate-200 shrink-0 bg-slate-100">
                                <img
                                  src={imgUrl}
                                  alt={`${t('Attachment Photo')} ${idx + 1}`}
                                  className="w-full h-full object-cover cursor-zoom-in hover:opacity-90 transition"
                                  referrerPolicy="no-referrer"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    const attImages = selectedAsset.attachmentImageUrls || [selectedAsset.attachmentImageUrl || ''];
                                    setLightboxImages(attImages);
                                    setLightboxIndex(idx);
                                  }}
                                />
                              </div>
                            ))}
                          </div>
                        )}

                        <div className="grid grid-cols-3 gap-3 text-xs font-semibold bg-indigo-50/20 p-4 rounded-xl border border-indigo-100/30">
                          {selectedAsset.attachmentType && (
                            <div className="bg-white p-3 rounded-xl border border-slate-100/85">
                              <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Tipe')}</span>
                              <strong className="text-slate-900 font-bold text-sm">{selectedAsset.attachmentType}</strong>
                            </div>
                          )}
                          {selectedAsset.attachmentAxels && (
                            <div className="bg-white p-3 rounded-xl border border-slate-100/85">
                              <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Axels')}</span>
                              <strong className="text-slate-900 font-bold text-sm">{selectedAsset.attachmentAxels}</strong>
                            </div>
                          )}
                          {selectedAsset.attachmentYearBuilt && (
                            <div className="bg-white p-3 rounded-xl border border-slate-100/85">
                              <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Tahun Produksi')}</span>
                              <strong className="text-slate-900 font-bold text-sm">{selectedAsset.attachmentYearBuilt}</strong>
                            </div>
                          )}
                          {selectedAsset.attachmentValidUntil && (
                            <div className="bg-white p-3 rounded-xl border border-slate-100/85">
                              <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('KEUR BERLAKU HINGGA')}</span>
                              <strong className="text-slate-900 font-bold text-sm">{formatDateIndonesian(selectedAsset.attachmentValidUntil)}</strong>
                            </div>
                          )}

                          {/* Attachment Dimensions */}
                          {(selectedAsset.attachmentLength || selectedAsset.attachmentWidth || selectedAsset.attachmentHeight) && (
                            <div className="col-span-3 mt-1 pt-2 border-t border-indigo-100/40">
                              <span className="text-slate-400 text-[9px] block uppercase mb-1.5 font-bold tracking-wider">{t('Dimensi Attachment')}</span>
                              <div className="grid grid-cols-3 gap-2">
                                {selectedAsset.attachmentLength && (
                                  <div className="bg-white p-3 rounded-xl border border-slate-100/85">
                                    <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Panjang Total')}</span>
                                    <strong className="text-slate-900 font-bold text-sm font-mono">{selectedAsset.attachmentLength}</strong>
                                  </div>
                                )}
                                {selectedAsset.attachmentWidth && (
                                  <div className="bg-white p-3 rounded-xl border border-slate-100/85">
                                    <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Lebar Total')}</span>
                                    <strong className="text-slate-900 font-bold text-sm font-mono">{selectedAsset.attachmentWidth}</strong>
                                  </div>
                                )}
                                {selectedAsset.attachmentHeight && (
                                  <div className="bg-white p-3 rounded-xl border border-slate-100/85">
                                    <span className="text-slate-400 text-[9px] block uppercase mb-0.5 font-bold tracking-wider">{t('Tinggi Total')}</span>
                                    <strong className="text-slate-900 font-bold text-sm font-mono">{selectedAsset.attachmentHeight}</strong>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Deskripsi (OLX-style Truncated preview + "Selengkapnya" modal link) */}
                  <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
                    <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-2.5">
                      <Info className="w-4 h-4 text-blue-600" />
                      <span>{t('Deskripsi Lengkap')}</span>
                    </h3>
                    <div className="text-xs leading-relaxed text-slate-600 space-y-2 relative">
                      <div className="line-clamp-3 overflow-hidden text-slate-600 font-sans">
                        {stripMarkdown(selectedAsset.description)}
                      </div>
                      
                      <div className="pt-2">
                        <button 
                          type="button" 
                          onClick={() => setShowFullDesc(true)}
                          className="text-blue-600 hover:text-blue-800 text-xs font-bold hover:underline inline-flex items-center gap-1.5 transition-all cursor-pointer"
                        >
                          <span>{t('Selengkapnya')}</span>
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>

                </div>

                {/* Right Side Content (sticky info + pricing + buttons + interactive booking form) */}
                <div className="space-y-6">
                  
                  {/* Price & CTA Trigger Card */}
                  {isUserLoggedIn ? (
                    <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                        <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">{t('Detail Harga')}</span>
                        <span className="bg-blue-50 text-blue-700 text-[9px] font-extrabold px-2 py-0.5 rounded-md border border-blue-100 uppercase">
                          {(selectedAsset.bids || []).length} {t('Penawaran Masuk')}
                        </span>
                      </div>
                      
                      <div className="space-y-4">
                        <div className="space-y-1">
                          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">{t('Penawaran Tertinggi')}</p>
                          <h2 className="text-lg md:text-xl font-bold text-slate-900 tracking-tight">
                            {formatIDR(currentHighestBid)}
                          </h2>
                        </div>
                        
                        <div className="border-t border-slate-100 pt-3 space-y-1">
                          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">{t('Harga Awal')}</p>
                          <h2 className="text-lg md:text-xl font-bold text-slate-900 tracking-tight">
                            {formatIDR(selectedAsset.startingPrice)}
                          </h2>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
                      <div className="space-y-1 pb-2 border-b border-slate-100">
                        <p className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">{t('Harga Awal')}</p>
                        <h2 className="text-xl md:text-2xl font-bold text-slate-400 tracking-tight flex items-center gap-1.5">
                          <Lock className="w-5 h-5 text-amber-500 shrink-0" />
                          <span>Rp ••••••••</span>
                        </h2>
                      </div>
                      <div className="flex flex-col items-center py-2 text-center space-y-2">
                        <Lock className="w-6 h-6 text-amber-500 animate-pulse" />
                        <h4 className="font-bold text-slate-800 text-sm">{t('Gabung untuk Menawar')}</h4>
                        <p className="text-xs text-slate-500 max-w-[240px] leading-relaxed">
                          {t('Silakan masuk atau daftar akun baru untuk mengajukan penawaran lelang unit ini.')}
                        </p>
                      </div>
                      <button 
                        type="button" 
                        onClick={() => { if (onOpenLoginModal) onOpenLoginModal(); }}
                        className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all shadow-md shadow-indigo-500/10 hover:shadow-indigo-500/25 flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span>{t('Masuk / Daftar Sekarang')}</span>
                      </button>
                    </div>
                  )}

          {/* Interactive Bidding & Survey Scheduler Form */}
                  <div 
                    id="bid-form-card"
                      className={`bg-white p-6 rounded-2xl border transition-all duration-300 space-y-4 cursor-pointer ${
                        isFormFocused 
                          ? 'relative z-40 border-blue-500 shadow-2xl ring-2 ring-blue-500/20 scale-[1.02] bg-white cursor-default' 
                          : 'relative z-10 border-slate-200/80 shadow-xs hover:border-blue-300'
                      }`}
                      onClick={(e) => {
                        if (!isFormFocused) {
                          setIsFormFocused(true);
                          if (nameInputRef.current) {
                            nameInputRef.current.focus();
                          }
                        }
                      }}
                    >
                      {!isUserLoggedIn ? (
                      <div className="py-6 text-center space-y-3.5">
                        <Lock className="w-8 h-8 text-amber-500 mx-auto animate-bounce" />
                        <h4 className="font-bold text-slate-800 text-sm">{t('Formulir Penawaran Terkunci')}</h4>
                        <p className="text-xs text-slate-500 max-w-[240px] mx-auto leading-relaxed">
                          {t('Silakan masuk atau daftar menggunakan akun lelang terverifikasi Anda untuk mengajukan penawaran lelang.')}
                        </p>
                        <button
                          type="button"
                          onClick={() => { if (onOpenLoginModal) onOpenLoginModal(); }}
                          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2.5 rounded-xl text-xs font-bold transition-all shadow-md shadow-indigo-500/10 hover:shadow-indigo-500/25 cursor-pointer uppercase tracking-wider"
                        >
                          {t('Masuk / Daftar Sekarang')}
                        </button>
                      </div>
                    ) : (
                      <>
                        <div className="border-b border-slate-100 pb-3">
                          <span className="text-[9px] font-mono font-bold bg-blue-50 text-blue-700 px-2.5 py-1 rounded-md border border-blue-100 uppercase">
                            {t('FORM PENAWARAN')}
                          </span>
                          <h3 className="font-bold text-slate-800 text-sm mt-1.5">
                            {bidForm.requestSurvey ? t('Ajukan Tawaran & Survei') : t('Kirim Penawaran')}
                          </h3>
                        </div>

                    {isAuctionClosed ? (
                      <div className="py-6 text-center space-y-3.5">
                        <div className="w-12 h-12 bg-rose-50 border border-rose-100 rounded-2xl flex items-center justify-center mx-auto text-rose-500">
                          <AlertCircle className="w-6 h-6" />
                        </div>
                        <h4 className="font-bold text-slate-800 text-sm">{t('Lelang Ditutup')}</h4>
                        <p className="text-xs text-slate-500 max-w-[240px] mx-auto leading-relaxed">
                          {t('Penawaran untuk unit ini telah ditutup karena melewati batas waktu penutupan lelang.')}
                        </p>
                      </div>
                    ) : !formSuccess ? (
                      <form 
                        onSubmit={handleBidSubmit}
                        onFocusCapture={() => setIsFormFocused(true)}
                        onBlurCapture={(e) => {
                          if (!e.currentTarget.contains(e.relatedTarget as Node)) {
                            setIsFormFocused(false);
                          }
                        }}
                        className="space-y-4"
                      >
                        {!canBid && (
                          <div className="p-3.5 bg-amber-50/80 border border-amber-200/80 text-amber-800 rounded-2xl text-xs font-semibold flex items-start gap-2.5 shadow-2xs">
                            <Eye className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
                            <div className="space-y-1">
                              <p className="font-extrabold text-[10px] uppercase tracking-wider text-amber-900">{t('Mode Hanya Lihat (Katalog Terbuka)')}</p>
                              <p className="text-[10px] font-medium text-amber-800 leading-normal">
                                {t('Akun Anda saat ini diatur sebagai "Hanya Lihat". Anda dapat melihat spesifikasi lengkap unit dan postingan, namun tidak dapat melakukan penawaran lelang.')}
                              </p>
                              <p className="text-[10px] text-amber-900/80 font-bold pt-1 border-t border-amber-200/40">
                                {t('Hubungi Administrator jika membutuhkan akses menawar.')}
                              </p>
                            </div>
                          </div>
                        )}
                        {formError && (
                          <div className="p-3.5 bg-rose-50 border border-rose-100 text-rose-600 rounded-2xl text-xs font-semibold flex items-start gap-2 animate-shake">
                            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                            <span>{formError}</span>
                          </div>
                        )}

                        {/* Name */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-slate-600 uppercase">{t('Nama Lengkap Anda *')}</label>
                          <div className="relative">
                            <User className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                            <input
                              type="text"
                              ref={nameInputRef}
                              required
                              disabled={!canBid}
                              placeholder={t('Contoh: PT Samudera Transport')}
                              value={bidForm.name}
                              onChange={(e) => setBidForm(prev => ({ ...prev, name: e.target.value }))}
                              onFocus={(e) => {
                                setIsFormFocused(true);
                                e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                              }}
                              className="w-full pl-9 pr-4 py-2.5 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed"
                            />
                          </div>
                        </div>

                        {/* Email */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-slate-600 uppercase">{t('Alamat Email Kontak *')}</label>
                          <div className="relative">
                            <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                            <input
                              type="email"
                              required
                              disabled={!canBid}
                              placeholder="name@company.co.id"
                              value={bidForm.email}
                              onChange={(e) => setBidForm(prev => ({ ...prev, email: e.target.value }))}
                              onFocus={(e) => {
                                setIsFormFocused(true);
                                e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                              }}
                              className="w-full pl-9 pr-4 py-2.5 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono font-medium disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed"
                            />
                          </div>
                        </div>

                        {/* Contact (Phone) */}
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-slate-600 uppercase">{t('No. Handphone / WhatsApp *')}</label>
                          <div className="relative">
                            <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                            <input
                              type="tel"
                              required
                              disabled={!canBid}
                              placeholder={t('Contoh: 0812XXXXXXXX')}
                              value={bidForm.contact}
                              onChange={(e) => setBidForm(prev => ({ ...prev, contact: e.target.value }))}
                              onFocus={(e) => {
                                setIsFormFocused(true);
                                e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                              }}
                              className="w-full pl-9 pr-4 py-2.5 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed"
                            />
                          </div>
                        </div>

                        {/* Bid Price or Itemized Bidding */}
                        {selectedAsset.usedPartItems && selectedAsset.usedPartItems.length > 0 ? (() => {
                          const { highestBidObj, highestItemBids } = getHighestBidBreakdown(selectedAsset);
                          return (
                          <div className="space-y-3 pt-1">
                            <div className="flex items-center justify-between">
                              <label className="text-[10px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                                <Layers className="w-3.5 h-3.5 text-blue-600" />
                                {t('Penawaran Per Tipe Item ({count} Tipe)', { count: itemBids.length })}
                              </label>
                              <span className="text-[9px] bg-blue-50 text-blue-700 font-bold px-2 py-0.5 rounded-full border border-blue-200">
                                {t('Bid Masing-Masing')}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-400 leading-tight">
                              {t('Tentukan harga penawaran satuan untuk setiap tipe barang di bawah:')}
                            </p>

                            <div className="space-y-2.5">
                              {itemBids.map((item, idx) => {
                                const qty = Number(item.qty) || 1;
                                const unitPrice = Number(item.unitPrice) || 0;
                                const subtotal = qty * unitPrice;
                                const origItem = selectedAsset.usedPartItems?.[idx];
                                const origUnitPrice = origItem?.unitPrice || 0;
                                const highestItem = highestItemBids[idx];
                                const highestUnitPrice = Number(highestItem?.unitPrice) || 0;

                                return (
                                  <div key={idx} className="p-3 rounded-2xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors space-y-2">
                                    <div className="flex items-start justify-between gap-2">
                                      <div className="space-y-1 w-full">
                                        <div className="flex items-center justify-between gap-2 flex-wrap">
                                          {/* Highest Bid button removed per user request */}
                                          <div className="flex items-center gap-1.5">
                                            <span className="bg-[#b8cce4] text-slate-900 text-[9px] font-extrabold px-1.5 py-0.5 rounded">
                                              {t('Tipe')} {idx + 1}
                                            </span>
                                            <span className="text-xs font-bold text-slate-800 line-clamp-1">{item.type}</span>
                                          </div>
                                        </div>
                                        <div className="text-[10px] text-slate-500 flex items-center gap-2 flex-wrap">
                                          <span>{t('Jumlah:')} <strong className="text-blue-700 font-mono">{qty} Unit</strong></span>
                                          <span>•</span>
                                          <span>{t('Starting Price:')} <strong className="text-slate-700 font-mono">{formatIDR(Number(origUnitPrice) || 0)}</strong>/unit</span>
                                          {highestUnitPrice > 0 ? (
                                            <>
                                              <span>•</span>
                                              <span className="text-emerald-700 font-semibold">{t('Highest Bid:')} <strong className="text-emerald-900 font-mono">{formatIDR(highestUnitPrice)}</strong>/unit</span>
                                            </>
                                          ) : (
                                            <>
                                              <span>•</span>
                                              <span className="text-slate-400 italic">{t('Highest Bid: Belum Ada')}</span>
                                            </>
                                          )}
                                        </div>
                                      </div>
                                    </div>

                                    {/* Input Unit Bid Price */}
                                    <div className="space-y-1">
                                      <div className="flex justify-between items-center text-[10px]">
                                        <span className="font-bold text-slate-600">{t('Harga Bid Satuan (IDR/Unit) *')}</span>
                                        <span className="font-mono text-slate-500 text-[9px]">
                                          Subtotal: <strong className="text-emerald-700">{formatIDR(Number(subtotal) || 0)}</strong>
                                        </span>
                                      </div>
                                      <div className="relative">
                                        <span className="absolute left-3 top-2 font-bold text-xs text-slate-400">Rp</span>
                                        <input
                                          type="text"
                                          inputMode="numeric"
                                          required
                                          disabled={!canBid}
                                          placeholder="0"
                                          value={unitPrice === 0 ? '0' : formatNumberWithDots(String(unitPrice))}
                                          onChange={(e) => {
                                            let raw = e.target.value.replace(/\D/g, '');
                                            if (raw.length > 1 && raw.startsWith('0')) {
                                              raw = raw.replace(/^0+/, '');
                                            }
                                            handleItemUnitPriceChange(idx, Number(raw) || 0);
                                          }}
                                          onFocus={(e) => {
                                            setIsFormFocused(true);
                                            if (unitPrice === 0) {
                                              e.target.select();
                                            }
                                            e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                          }}
                                          className="w-full pl-8 pr-3 py-2 border border-slate-200 rounded-xl text-xs font-bold text-blue-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>

                            {/* Grand Total Bid Summary */}
                            <div className="p-3 bg-gradient-to-r from-blue-50 to-indigo-50/50 rounded-2xl border border-blue-200/80 flex items-center justify-between">
                              <div>
                                <span className="text-[10px] font-bold text-blue-900 uppercase tracking-wider block">
                                  {t('Total Keseluruhan Bid')}
                                </span>
                                <span className="text-[9px] text-blue-600 font-medium">
                                  {itemBids.reduce((acc, it) => acc + (Number(it.qty) || 0), 0)} {t('Total Unit')} ({itemBids.length} {t('Tipe')})
                                </span>
                              </div>
                              <div className="text-right">
                                <span className="text-base font-extrabold text-blue-800 font-mono">
                                  {formatIDR(Number(bidForm.price))}
                                </span>
                              </div>
                            </div>
                          </div>
                          );
                        })() : (
                          /* Standard Single Asset Bid Price (Trucks/Vehicles) */
                          <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-slate-600 uppercase">{t('Harga Bid Anda (IDR) *')}</label>
                            <div className="relative">
                              <span className="absolute left-3 top-2.5 font-bold text-xs text-slate-400">Rp</span>
                              <input
                                type="text"
                                inputMode="numeric"
                                required
                                disabled={!canBid}
                                placeholder={formatNumberWithDots(String(currentHighestBid + 5000000))}
                                value={formatNumberWithDots(bidForm.price)}
                                onChange={(e) => {
                                  let raw = e.target.value.replace(/\D/g, '');
                                  if (raw.length > 1 && raw.startsWith('0')) {
                                    raw = raw.replace(/^0+/, '');
                                  }
                                  setBidForm(prev => ({ ...prev, price: raw }));
                                }}
                                onFocus={(e) => {
                                  setIsFormFocused(true);
                                  e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                }}
                                className="w-full pl-8 pr-4 py-2.5 border border-slate-200 rounded-xl text-sm font-bold text-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed"
                              />
                            </div>
                            <div className="flex items-center justify-between mt-1">
                              <p className="text-[10px] text-slate-400">
                                {t('Penawaran Tertinggi:')} <strong className="text-slate-600">{formatIDR(currentHighestBid)}</strong>
                              </p>
                              <button
                                type="button"
                                disabled={!canBid}
                                onClick={() => setBidForm(prev => ({ ...prev, price: String(currentHighestBid) }))}
                                className={`text-[9px] font-bold px-2 py-0.5 rounded-md transition-all ${
                                  !canBid
                                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                                    : 'text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 cursor-pointer'
                                }`}
                              >
                                {t('Gunakan')}
                              </button>
                            </div>
                          </div>
                        )}

                        {/* Request Survey Toggle */}
                        <div className="pt-2 border-t border-slate-100">
                          <label className="flex items-center gap-2.5 cursor-pointer select-none">
                            <input
                              type="checkbox"
                              disabled={!canBid}
                              checked={bidForm.requestSurvey}
                              onChange={(e) => {
                                const isChecked = e.target.checked;
                                const todayStr = new Date().toISOString().split('T')[0];
                                setBidForm(prev => ({
                                  ...prev,
                                  requestSurvey: isChecked,
                                  surveyDate: isChecked && !prev.surveyDate ? todayStr : prev.surveyDate
                                }));
                                if (isChecked) {
                                  setTimeout(() => {
                                    const grid = document.getElementById('visit-sessions-grid');
                                    if (grid) {
                                      grid.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                                    }
                                  }, 150);
                                }
                              }}
                              className="w-4.5 h-4.5 text-blue-600 border-slate-300 rounded focus:ring-blue-500 disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed"
                            />
                            <div className="text-xs">
                              <p className="font-bold text-slate-800">{t('Booking Jadwal Survei Fisik')}</p>
                              <p className="text-slate-400 text-[10px]">{t('Ingin cek kondisi mesin langsung di Pool?')}</p>
                            </div>
                          </label>
                        </div>

                        {/* Survey Scheduler Details */}
                        {bidForm.requestSurvey && (
                          <div className="p-4 bg-gradient-to-br from-blue-50/60 to-indigo-50/20 rounded-2xl border border-blue-100/80 space-y-3.5 relative overflow-hidden shadow-xs">
                            <div className="flex items-center justify-between relative z-10 flex-wrap gap-1">
                              <p className="text-[11px] font-bold text-slate-700 flex items-center gap-1.5">
                                <CalendarCheck className="w-4 h-4 text-blue-600" /> {t('Tentukan Waktu Kunjungan Survei')}
                              </p>
                              <span className="text-[9.5px] px-2 py-0.5 rounded-full font-bold bg-blue-100/80 text-blue-800 border border-blue-200/60">
                                {normalizeCategory(selectedAsset?.category) === 'Used part' ? t('Area: Gudang Suku Cadang') : t('Area: Pool Kendaraan')}
                              </span>
                            </div>
                            
                            <div className="space-y-3 relative z-10">
                              {/* Select Date */}
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-slate-400 uppercase">{t('Pilih Tanggal Kunjungan')}</label>
                                <input
                                  type="date"
                                  disabled={!canBid}
                                  min={new Date().toISOString().split('T')[0]}
                                  value={bidForm.surveyDate}
                                  onChange={(e) => {
                                    const newDate = e.target.value;
                                    setBidForm(prev => {
                                      let nextTime = prev.surveyTime;
                                      if (isTimeBooked(nextTime, newDate, selectedAsset?.category)) {
                                        const slots = ["09:00", "11:00", "13:30", "15:30"];
                                        const available = slots.find(slot => !isTimeBooked(slot, newDate, selectedAsset?.category));
                                        if (available) {
                                          nextTime = available;
                                        }
                                      }
                                      return { ...prev, surveyDate: newDate, surveyTime: nextTime };
                                    });
                                  }}
                                  className="w-full p-2.5 border border-slate-200 rounded-xl text-xs bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-semibold text-slate-700 disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed"
                                  required={bidForm.requestSurvey}
                                />
                              </div>

                              {/* Sesi Jam list */}
                              <div className="space-y-1.5">
                                <div className="flex justify-between items-center">
                                  <label className="text-[10px] font-bold text-slate-400 uppercase">{t('Pilih Sesi Jam Kunjungan')}</label>
                                  <span className="text-[9px] text-slate-400 font-medium">
                                    {normalizeCategory(selectedAsset?.category) === 'Used part' ? t('Jadwal Area Gudang') : t('Jadwal Area Pool')}
                                  </span>
                                </div>

                                <div className="grid grid-cols-1 gap-2" id="visit-sessions-grid">
                                  {[
                                    { id: "09:00", label: t('Pagi Sesi 1 (09:00 WIB)'), time: "09:00 WIB", desc: t('Sesi Pagi I') },
                                    { id: "11:00", label: t('Pagi Sesi 2 (11:00 WIB)'), time: "11:00 WIB", desc: t('Sesi Pagi II') },
                                    { id: "13:30", label: t('Siang Sesi 1 (13:30 WIB)'), time: "13:30 WIB", desc: t('Sesi Siang I') },
                                    { id: "15:30", label: t('Sore Sesi 2 (15:30 WIB)'), time: "15:30 WIB", desc: t('Sesi Sore II') }
                                  ].map((session) => {
                                    const booked = isTimeBooked(session.id, bidForm.surveyDate, selectedAsset?.category);
                                    const selected = bidForm.surveyTime === session.id;

                                    return (
                                      <button
                                        key={session.id}
                                        type="button"
                                        disabled={booked || !canBid}
                                        onClick={() => setBidForm(prev => ({ ...prev, surveyTime: session.id }))}
                                        className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all relative ${
                                          booked || !canBid
                                            ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed opacity-60'
                                            : selected
                                            ? 'bg-blue-50 border-blue-600 ring-2 ring-blue-500/10 text-blue-950'
                                            : 'bg-white border-slate-200 text-slate-800 hover:border-slate-300 hover:bg-slate-50'
                                        }`}
                                      >
                                        <div className="flex justify-between items-center w-full">
                                          <span className="text-[11px] font-bold">
                                            {session.time}
                                          </span>
                                          {booked ? (
                                            <span className="bg-red-50 text-red-500 border border-red-100 text-[8px] font-extrabold px-1 py-0.5 rounded tracking-wide uppercase">
                                              {t('Booked')}
                                            </span>
                                          ) : (
                                            <span className={`text-[8px] font-extrabold px-1 py-0.5 rounded tracking-wide uppercase ${
                                              selected ? 'bg-blue-600 text-white' : 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                                            }`}>
                                              {selected ? t('Selected') : t('Ready')}
                                            </span>
                                          )}
                                        </div>
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Terms and Conditions (Syarat dan Ketentuan) */}
                        <div className="pt-3 border-t border-slate-100 space-y-2">
                          <label className="text-[10px] font-bold text-slate-600 uppercase tracking-wider block">
                            {t('Syarat & Ketentuan Lelang *')}
                          </label>
                          <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3 max-h-[120px] overflow-y-auto text-[10px] text-slate-500 leading-relaxed custom-scrollbar whitespace-pre-wrap">
                            {selectedAsset.tnc ? (
                              selectedAsset.tnc
                            ) : (
                              <span className="italic text-slate-400">{t('Tidak ada Syarat & Ketentuan khusus (Kosong)')}</span>
                            )}
                          </div>
                          
                          <label className="flex items-start gap-2.5 cursor-pointer select-none py-1">
                            <input
                              type="checkbox"
                              required
                              disabled={!canBid}
                              checked={agreedToTerms}
                              onChange={(e) => setAgreedToTerms(e.target.checked)}
                              className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500 mt-0.5 cursor-pointer disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed"
                            />
                            <span className="text-[11px] text-slate-600 leading-normal">
                              {t('Saya telah membaca, memahami, dan menyetujui seluruh Syarat dan Ketentuan Lelang yang berlaku.')}
                            </span>
                          </label>
                        </div>

                        {/* Submit Bid Button */}
                        <button
                          type="submit"
                          disabled={!canBid}
                          className={`w-full py-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 uppercase tracking-wider ${
                            !canBid
                              ? 'bg-slate-300 text-slate-500 cursor-not-allowed border-none shadow-none hover:bg-slate-300 hover:shadow-none'
                              : 'bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/15 hover:shadow-blue-500/30 cursor-pointer'
                          }`}
                        >
                          {!canBid ? (
                            <Lock className="w-4 h-4 shrink-0 text-slate-400" />
                          ) : (
                            <ArrowUpRight className="w-4 h-4" />
                          )}
                          <span>
                            {!canBid
                              ? t('Akses Bidding Terkunci')
                              : (bidForm.requestSurvey ? t('Kirim Penawaran & Booking') : t('Kirim Penawaran'))}
                          </span>
                        </button>
                      </form>
                    ) : (
                      // Success feedback panel
                      <div className="py-6 text-center space-y-4 animate-fade-in" id="bid-success-panel">
                        <div className="w-14 h-14 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mx-auto border border-emerald-100 shadow-xs">
                          <CheckCircle className="w-8 h-8" />
                        </div>
                        <div className="space-y-1">
                          <h3 className="font-bold text-slate-800 text-sm">{t('Penawaran Berhasil!')}</h3>
                          <p className="text-[10px] text-slate-400">{t('Harga penawaran Anda telah dicatat.')}</p>
                        </div>
                        <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-xs text-left space-y-1.5 font-medium font-sans">
                          <div className="flex justify-between">
                            <span className="text-slate-400">{t('Armada / Aset:')}</span>
                            <span className="text-slate-800 font-bold text-[11px] line-clamp-1">{selectedAsset.name}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">{t('Total Harga Bid:')}</span>
                            <span className="text-blue-700 font-bold">{formatIDR(Number(bidForm.price))}</span>
                          </div>

                          {/* Itemized breakdown if spare parts */}
                          {itemBids.length > 0 && (
                            <div className="mt-2 pt-2 border-t border-slate-200/80 space-y-1">
                              <span className="text-[10px] font-bold text-slate-600 block uppercase">
                                {t('Rincian Bid Per Tipe ({count}):', { count: itemBids.length })}
                              </span>
                              <div className="space-y-1 text-[10px]">
                                {itemBids.map((it, i) => (
                                  <div key={i} className="flex justify-between items-center bg-white p-1.5 rounded-lg border border-slate-200/60">
                                    <span className="text-slate-700 font-medium truncate max-w-[170px]">{i + 1}. {it.type}</span>
                                    <span className="font-mono font-bold text-emerald-700">{it.qty} × {formatIDR(it.unitPrice)}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {bidForm.requestSurvey && (
                            <div className="flex justify-between border-t border-dashed border-slate-200 pt-1.5 mt-1.5 text-blue-700">
                              <span className="flex items-center gap-1 font-bold">
                                <Calendar className="w-3.5 h-3.5" /> {t('Survei:')}
                              </span>
                              <span className="font-bold">{bidForm.surveyDate} @ {bidForm.surveyTime} WIB</span>
                            </div>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400 italic">{t('Menutup halaman...')}</p>
                      </div>
                    )}

                    {/* Shield / Safety warning */}
                    <div className="pt-3 border-t border-slate-100 flex items-start gap-2 text-[10px] text-slate-400 leading-normal">
                      <ShieldAlert className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                      <span>
                        {t('Setiap pengiriman penawaran dijamin aman & tunduk pada Syarat Ketentuan Lelang Pancaran.')}
                      </span>
                    </div>
                    </>
                  )}

                  {/* Extra mobile focus bottom spacer inside form card to prevent virtual keyboard occlusion */}
                  {isFormFocused && (
                    <div className="h-[20vh] md:hidden" />
                  )}
                </div>
            </div>
          </div>
        </div>
      </div>
            {!formSuccess && !isFormFocused && (
              <div className="md:hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-[55] animate-bounce">
                <button
                  type="button"
                  onClick={() => {
                    const formElement = document.getElementById('bid-form-card');
                    if (formElement) {
                      formElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                    if (nameInputRef.current) {
                      nameInputRef.current.focus();
                    }
                  }}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs px-5 py-3.5 rounded-full shadow-2xl border border-blue-500/20 flex items-center gap-2 uppercase tracking-wider whitespace-nowrap cursor-pointer"
                >
                  <ArrowUpRight className="w-4 h-4" />
                  <span>{t('Tulis Penawaran')}</span>
                </button>
              </div>
            )}
        {showFullDesc && (
          <div 
            className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[60] flex items-center justify-center p-4 animate-fade-in"
            id="full-description-overlay"
            onClick={() => setShowFullDesc(false)}
          >
            <div 
              className="bg-white rounded-3xl border border-slate-200/80 shadow-2xl w-full max-w-2xl overflow-hidden relative animate-zoom-in my-auto max-h-[85vh] flex flex-col focus:outline-none"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div>
                  <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider bg-blue-50 px-2.5 py-1 rounded-md border border-blue-100">
                    {t('Detail Deskripsi')}
                  </span>
                  <h3 className="font-bold text-slate-800 text-base mt-2">{selectedAsset.name}</h3>
                </div>
                <button 
                  onClick={() => setShowFullDesc(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 p-2 rounded-full transition-all cursor-pointer flex items-center justify-center"
                  title={t('Tutup')}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Scrollable Description Container */}
              <div className="p-6 md:p-8 overflow-y-auto flex-1 custom-scrollbar space-y-4">
                <div className="text-sm leading-relaxed text-slate-600 font-sans">
                  {renderDescription(selectedAsset.description)}
                </div>
              </div>

              {/* Modal Footer */}
              <div className="p-6 border-t border-slate-100 bg-slate-50/50 flex justify-end">
                <button
                  onClick={() => setShowFullDesc(false)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-xl text-xs font-bold transition-all shadow-md shadow-blue-500/10 hover:shadow-blue-500/25 cursor-pointer uppercase tracking-wider"
                >
                  {t('Selesai')}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>,
      document.body
    )}

      {/* Immersive Fullscreen Lightbox Zoom Overlay */}
      {lightboxIndex !== null && lightboxImages.length > 0 && createPortal(
        <div 
          className="fixed inset-0 bg-slate-950/95 backdrop-blur-md z-[999999] flex flex-col items-center justify-center p-4 md:p-8 select-none animate-fade-in"
          id="image-lightbox-overlay"
          onClick={() => setLightboxIndex(null)}
        >
          {/* Controls Bar */}
          <div className="absolute top-4 right-4 flex items-center gap-2 z-[110]">
            {/* Zoom Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsZoomed(prev => !prev);
              }}
              className="bg-slate-900/80 hover:bg-slate-800 text-white p-2.5 rounded-full border border-slate-800 hover:border-slate-700 hover:scale-105 transition-all shadow-xl flex items-center justify-center cursor-pointer"
              title={isZoomed ? t('Zoom Out') : t('Zoom In')}
            >
              {isZoomed ? <ZoomOut className="w-5 h-5" /> : <ZoomIn className="w-5 h-5" />}
            </button>

            {/* Close button */}
            <button
              onClick={() => setLightboxIndex(null)}
              className="bg-slate-900/80 hover:bg-slate-800 text-white p-2.5 rounded-full border border-slate-800 hover:border-slate-700 hover:scale-105 transition-all shadow-xl flex items-center justify-center cursor-pointer"
              title={t('Tutup')}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Prev button */}
          {lightboxImages.length > 1 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                setLightboxIndex(prev => (prev === null ? 0 : (prev === 0 ? lightboxImages.length - 1 : prev - 1)));
              }}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-slate-900/80 hover:bg-slate-800 text-white p-3 rounded-full border border-slate-800 hover:border-slate-700 hover:scale-105 transition-all shadow-xl z-[110] flex items-center justify-center w-12 h-12 cursor-pointer"
              title={t('Sebelumnya')}
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
          )}

          {/* Next button */}
          {lightboxImages.length > 1 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                setLightboxIndex(prev => (prev === null ? 0 : (prev === lightboxImages.length - 1 ? 0 : prev + 1)));
              }}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-slate-900/80 hover:bg-slate-800 text-white p-3 rounded-full border border-slate-800 hover:border-slate-700 hover:scale-105 transition-all shadow-xl z-[110] flex items-center justify-center w-12 h-12 cursor-pointer"
              title={t('Berikutnya')}
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          )}

          {/* Image Container with Smooth Animation & Zoom Scroll Support */}
          <div 
            className={`relative w-full max-w-6xl max-h-[85vh] flex items-center justify-center animate-zoom-in transition-all duration-300 ${
              isZoomed ? "overflow-auto cursor-zoom-out p-4 justify-start items-start bg-slate-950/40 rounded-2xl border border-slate-900" : ""
            }`}
            onClick={(e) => {
              e.stopPropagation();
              if (isZoomed) {
                setIsZoomed(false);
              }
            }}
          >
            <img
              src={lightboxImages[lightboxIndex] || ""}
              alt={`Zoomed Asset - ${lightboxIndex + 1}`}
              className={`select-none transition-all duration-300 ${
                isZoomed 
                  ? "w-[200%] md:w-[150%] max-w-none max-h-none object-contain cursor-zoom-out rounded-lg shadow-2xl" 
                  : "w-full max-w-full max-h-[85vh] object-contain rounded-2xl shadow-2xl border border-slate-800 cursor-zoom-in hover:scale-[1.01]"
              }`}
              referrerPolicy="no-referrer"
              onClick={(e) => {
                e.stopPropagation();
                setIsZoomed(prev => !prev);
              }}
            />
          </div>

          {/* Position indicator & Close hint */}
          <div className="mt-4 flex flex-col items-center gap-1.5 text-center">
            {lightboxImages.length > 1 && (
              <span className="text-xs text-slate-300 font-mono font-bold bg-slate-900/60 px-3 py-1 rounded-full border border-slate-800">
                {lightboxIndex + 1} / {lightboxImages.length}
              </span>
            )}
            <p className="text-[10px] text-slate-400 font-semibold tracking-wider uppercase mt-1">
              {isZoomed 
                ? t('Klik gambar untuk memperkecil • Geser untuk menjelajah detail') 
                : t('Klik gambar untuk memperbesar • Klik di luar untuk kembali')}
            </p>
          </div>
        </div>,
        document.body
      )}

      {showBidConfirmModal && selectedAsset && createPortal(
        <div className="fixed inset-0 z-[9999999] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-amber-100 space-y-5 animate-zoom-in relative">
            <button
              onClick={() => setShowBidConfirmModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1.5 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-14 h-14 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto border border-amber-200/80 shadow-xs">
              <ShieldAlert className="w-8 h-8 animate-pulse" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-base font-bold text-slate-900 uppercase tracking-wide">
                {t('Konfirmasi Penawaran')}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {t('Penawaran Anda terdeteksi 50% atau lebih di atas harga dasar unit. Mohon pastikan nominal penawaran sudah benar untuk menghindari kesalahan ketik.')}
              </p>
            </div>

            <div className="bg-amber-50/60 border border-amber-200/60 rounded-2xl p-4 space-y-2 text-xs">
              <div className="flex justify-between items-center text-slate-600">
                <span className="font-medium">{t('Unit Lelang')}:</span>
                <span className="font-bold text-slate-800 truncate max-w-[200px]">{selectedAsset.name}</span>
              </div>
              <div className="flex justify-between items-center text-slate-600">
                <span className="font-medium">{t('Harga Starting')}:</span>
                <span className="font-semibold text-slate-700">{formatIDR(selectedAsset.startingPrice)}</span>
              </div>

              {/* Itemized breakdown in confirmation modal if spare parts */}
              {itemBids.length > 0 && (
                <div className="border-t border-amber-200/60 pt-2 space-y-1.5">
                  <span className="text-[10px] font-bold text-amber-900 block uppercase">
                    {t('Penawaran Per Tipe ({count} Tipe):', { count: itemBids.length })}
                  </span>
                  <div className="space-y-1 text-[10px] max-h-32 overflow-y-auto custom-scrollbar">
                    {itemBids.map((it, i) => (
                      <div key={i} className="flex justify-between items-center bg-white/80 p-1.5 rounded-lg border border-amber-200/50">
                        <span className="text-slate-800 font-medium truncate max-w-[170px]">{i + 1}. {it.type}</span>
                        <span className="font-mono font-bold text-blue-800">{it.qty} × {formatIDR(it.unitPrice)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="border-t border-amber-200/60 pt-2 flex justify-between items-center text-amber-900 font-bold">
                <span>{t('Total Nominal Penawaran')}:</span>
                <span className="text-sm font-extrabold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200/80">
                  {formatIDR(Number(bidForm.price))}
                </span>
              </div>
            </div>

            <p className="text-[11px] text-center font-medium text-slate-600">
              {t('Anda yakin sudah benar dengan penawaran sebesar')} <strong className="text-blue-700 font-extrabold">{formatIDR(Number(bidForm.price))}</strong>?
            </p>

            {/* Super Admin Inbox Notice */}
            <div className="bg-blue-50/90 border border-blue-200/80 rounded-xl p-2.5 text-[10px] text-blue-900 font-medium text-center flex items-center justify-center gap-1.5 shadow-xs">
              <span className="text-blue-600 text-xs">📬</span>
              <span>{t('Setelah menekan "Ya, Saya Yakin", penawaran akan langsung terkirim & tercatat di Inbox Super Admin.')}</span>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                type="button"
                onClick={() => setShowBidConfirmModal(false)}
                className="w-full py-2.5 px-4 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-xs transition-all cursor-pointer"
              >
                {t('Periksa Kembali')}
              </button>
              <button
                type="button"
                onClick={() => handleBidSubmit(undefined, true)}
                className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-500/20 transition-all cursor-pointer"
              >
                {t('Ya, Saya Yakin')}
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}

    </div>
    </div>
  );
}
