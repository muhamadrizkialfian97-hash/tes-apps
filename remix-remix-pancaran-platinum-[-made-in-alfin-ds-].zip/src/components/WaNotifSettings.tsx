import React, { useState, useEffect } from 'react';
import { FonnteSettings, DEFAULT_FONNTE_SETTINGS, Asset } from '../types';
import { 
  getFonnteSettings, 
  saveFonnteSettings, 
  checkFonnteDevice, 
  sendFonnteMessage, 
  getFonnteLogs, 
  FonnteLogItem,
  fetchFonnteGroups,
  FonnteGroup,
  askAiAuctionAssistant
} from '../utils/fonnteService';
import { useLanguage } from './LanguageContext';
import { 
  Phone, 
  Key, 
  Save, 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  BellRing, 
  ShieldCheck, 
  Smartphone, 
  MessageSquare, 
  Check, 
  Info, 
  Clock, 
  Sparkles, 
  Users, 
  Eye, 
  FileText,
  Link as LinkIcon,
  ExternalLink,
  UserPlus,
  Power,
  Bot,
  MessageCircle,
  HelpCircle,
  Copy,
  CheckCheck
} from 'lucide-react';

interface WaNotifSettingsProps {
  assets?: Asset[];
}

export const WaNotifSettings: React.FC<WaNotifSettingsProps> = ({ assets = [] }) => {
  const { t } = useLanguage();
  const [settings, setSettings] = useState<FonnteSettings>(DEFAULT_FONNTE_SETTINGS);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'settings' | 'ai_responder' | 'test' | 'logs'>('settings');
  
  // Test message states
  const [testNumber, setTestNumber] = useState('');
  const [testMessageText, setTestMessageText] = useState(
    '📢 *TES NOTIFIKASI REAL-TIME KE GRUP NOTED / WA*\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nHalo! Integrasi Fonnte WhatsApp Gateway untuk grup Noted telah berhasil aktif dan siap menerima notifikasi lelang secara otomatis. 🚀'
  );
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  // Device check states
  const [isCheckingDevice, setIsCheckingDevice] = useState(false);
  const [deviceStatus, setDeviceStatus] = useState<{ checked: boolean; success: boolean; message: string; raw?: any } | null>(null);

  // Groups list from Fonnte
  const [groups, setGroups] = useState<FonnteGroup[]>([]);
  const [isLoadingGroups, setIsLoadingGroups] = useState(false);
  const [groupFetchMessage, setGroupFetchMessage] = useState<string | null>(null);

  // Preview tab
  const [previewTemplate, setPreviewTemplate] = useState<'new_asset' | 'new_bid' | 'survey' | 'winner'>('new_asset');

  // Logs state
  const [logs, setLogs] = useState<FonnteLogItem[]>([]);

  // AI Auto-Responder states
  const [aiQuestion, setAiQuestion] = useState('Halo admin, ada unit dump truck atau tronton apa saja yang sedang buka lelang dan bagaimana cara ikut lelangnya?');
  const [aiAnswer, setAiAnswer] = useState('');
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);
  const [isSendingAiToWa, setIsSendingAiToWa] = useState(false);
  const [isSimulatingWa, setIsSimulatingWa] = useState(false);
  const [copiedWebhook, setCopiedWebhook] = useState(false);

  useEffect(() => {
    loadSettings();
    loadLogs();
    handleCheckDevice();
    handleFetchGroups();
  }, []);

  const loadSettings = async () => {
    const data = await getFonnteSettings();
    setSettings(data);
    if (data.targetNumbers && !testNumber) {
      setTestNumber(data.targetNumbers.split(',')[0].trim());
    } else if (!testNumber) {
      setTestNumber('https://chat.whatsapp.com/G0ptrOfAe7S5vZH2oGkmP8');
    }
  };

  const loadLogs = () => {
    setLogs(getFonnteLogs());
  };

  const handleFetchGroups = async () => {
    setIsLoadingGroups(true);
    setGroupFetchMessage(null);
    try {
      const res = await fetchFonnteGroups(settings.apiKey);
      if (res.success && res.groups.length > 0) {
        setGroups(res.groups);
        setGroupFetchMessage(`Ditemukan ${res.groups.length} grup WhatsApp dari akun Fonnte Anda.`);
      } else {
        setGroupFetchMessage(res.message || 'Belum ada grup yang terhubung di nomor WhatsApp gateway ini.');
      }
    } catch (err: any) {
      setGroupFetchMessage(err.message || 'Gagal memuat grup');
    } finally {
      setIsLoadingGroups(false);
    }
  };

  const handleSelectGroup = (group: FonnteGroup) => {
    const currentTargets = settings.targetNumbers ? settings.targetNumbers.split(',').map(s => s.trim()) : [];
    if (!currentTargets.includes(group.id) && !currentTargets.includes(group.name)) {
      const updated = currentTargets.length > 0 ? `${settings.targetNumbers}, ${group.id}` : group.id;
      setSettings({ ...settings, targetNumbers: updated });
      setTestNumber(group.id);
    }
  };

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSaving(true);
    setSaveSuccess(false);
    try {
      await saveFonnteSettings(settings);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 4000);
    } catch (err) {
      console.error('Error saving settings:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggleAll = (enable: boolean) => {
    const updated: FonnteSettings = {
      ...settings,
      isEnabled: enable,
      notifyOnNewAsset: enable,
      notifyOnNewBid: enable,
      notifyOnSurveyBooking: enable,
      notifyOnAuctionWon: enable,
      notifyOnUserRegister: enable,
      notifyOnNplDeposit: enable,
      notifyOnAssetUpdate: enable
    };
    setSettings(updated);
    saveFonnteSettings(updated);
  };

  const handleCheckDevice = async () => {
    setIsCheckingDevice(true);
    try {
      const res = await checkFonnteDevice(settings.apiKey);
      setDeviceStatus({
        checked: true,
        success: res.success,
        message: res.message,
        raw: res.raw
      });
    } catch (err: any) {
      setDeviceStatus({
        checked: true,
        success: false,
        message: err.message || 'Gagal menghubungi Fonnte API'
      });
    } finally {
      setIsCheckingDevice(false);
    }
  };

  const handleSendTest = async (e: React.FormEvent) => {
    e.preventDefault();
    const target = testNumber || settings.targetNumbers || settings.groupLink || 'https://chat.whatsapp.com/G0ptrOfAe7S5vZH2oGkmP8';
    if (!target) {
      setTestResult({ success: false, message: 'Harap masukkan nomor WhatsApp atau ID grup tujuan.' });
      return;
    }

    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await sendFonnteMessage(target, testMessageText, settings.apiKey, settings.countryCode);
      setTestResult({
        success: res.success,
        message: res.message
      });
      loadLogs();
      handleFetchGroups();
    } catch (err: any) {
      setTestResult({
        success: false,
        message: err.message || 'Terjadi kesalahan saat mengirim pesan tes.'
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleTestAiQuery = async (promptText?: string) => {
    const q = promptText || aiQuestion;
    if (!q.trim()) return;
    setIsGeneratingAi(true);
    setAiAnswer('');
    try {
      const assetContext = assets.slice(0, 15).map(a => ({
        id: a.id,
        name: a.name,
        brand: a.brand,
        category: a.category,
        year: a.modelYear,
        startingPrice: a.startingPrice,
        status: a.status,
        location: a.location,
        bidsCount: a.bids?.length || 0
      }));

      const res = await askAiAuctionAssistant(q, assetContext, settings.aiCustomKnowledge);
      if (res.success) {
        setAiAnswer(res.answer);
      } else {
        setAiAnswer('Gagal memproses pertanyaan: ' + res.answer);
      }
    } catch (err: any) {
      setAiAnswer('Terjadi kesalahan: ' + (err.message || 'Koneksi AI gagal'));
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const handleSendAiAnswerToWhatsApp = async () => {
    if (!aiAnswer) return;
    const target = settings.targetNumbers || settings.groupLink || 'https://chat.whatsapp.com/G0ptrOfAe7S5vZH2oGkmP8';
    setIsSendingAiToWa(true);
    try {
      await sendFonnteMessage(target, aiAnswer, settings.apiKey, settings.countryCode);
      loadLogs();
      alert('Jawaban AI berhasil dikirimkan ke grup / nomor WhatsApp!');
    } catch (err) {
      alert('Gagal mengirim ke WhatsApp.');
    } finally {
      setIsSendingAiToWa(false);
    }
  };

  const handleSimulateIncomingWa = async () => {
    if (!aiQuestion) return;
    const target = settings.targetNumbers || 'https://chat.whatsapp.com/G0ptrOfAe7S5vZH2oGkmP8';
    setIsSimulatingWa(true);
    try {
      const res = await fetch('/api/wa/simulate-incoming', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: aiQuestion,
          target: target,
          apiKey: settings.apiKey,
          countryCode: settings.countryCode
        })
      });
      const data = await res.json();
      if (data.status) {
        setAiAnswer(data.aiReply);
        alert('Simulasi berhasil! AI telah membalas dan mengirim pesan ke WhatsApp.');
        loadLogs();
      } else {
        alert('Gagal simulasi: ' + (data.error || 'Unknown error'));
      }
    } catch (err: any) {
      alert('Gagal menghubungi server: ' + err.message);
    } finally {
      setIsSimulatingWa(false);
    }
  };

  const webhookUrl = typeof window !== 'undefined' ? `${window.location.origin}/api/fonnte/webhook` : '/api/fonnte/webhook';

  const handleCopyWebhook = () => {
    navigator.clipboard.writeText(webhookUrl);
    setCopiedWebhook(true);
    setTimeout(() => setCopiedWebhook(false), 3000);
  };

  const botNumber = deviceStatus?.raw?.device || '08987976541';

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 rounded-3xl p-6 md:p-8 text-white shadow-xl border border-emerald-800/40 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-10 -translate-y-10 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-extrabold uppercase tracking-wider border border-emerald-400/30 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
                WhatsApp Gateway & AI Gemini Auto-Responder
              </span>
              <span className="px-3 py-1 rounded-full bg-pink-500/20 text-pink-300 text-[10px] font-extrabold uppercase tracking-wider border border-pink-400/30 flex items-center gap-1">
                <span>🎯</span> Grup Noted Aktif
              </span>
            </div>
            
            <h1 className="text-xl md:text-3xl font-black tracking-tight text-white flex items-center gap-2.5">
              <Phone className="w-7 h-7 text-emerald-400" />
              {t('Notifikasi WhatsApp & AI Tanya Jawab Lelang')}
            </h1>
            <p className="text-xs md:text-sm text-emerald-100/80 max-w-2xl leading-relaxed">
              Kendalikan status notifikasi real-time lelang (ON/OFF) serta aktifkan <strong>Asisten AI Otomatis</strong> untuk melayani tanya-jawab seputar unit lelang di grup WhatsApp <strong>Noted</strong>!
            </p>
          </div>

          {/* Master ON / OFF Switch Widget */}
          <div className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center justify-center gap-3 shrink-0 shadow-lg ${
            settings.isEnabled 
              ? 'bg-emerald-900/60 border-emerald-400/60 text-emerald-100 shadow-emerald-950/50' 
              : 'bg-rose-950/60 border-rose-500/50 text-rose-100 shadow-rose-950/50'
          }`}>
            <div className="text-center">
              <span className="text-[10px] font-black uppercase tracking-wider block opacity-75">STATUS SISTEM WA</span>
              <div className="flex items-center gap-2 mt-0.5">
                <span className={`w-3 h-3 rounded-full animate-pulse ${settings.isEnabled ? 'bg-emerald-400 shadow-lg shadow-emerald-400/50' : 'bg-rose-500 shadow-lg shadow-rose-500/50'}`} />
                <span className="text-base font-black tracking-wide">
                  {settings.isEnabled ? 'AKTIF (ON)' : 'MATI (OFF)'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                const nextState = !settings.isEnabled;
                setSettings({ ...settings, isEnabled: nextState });
                saveFonnteSettings({ ...settings, isEnabled: nextState });
              }}
              className={`w-full px-5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                settings.isEnabled 
                  ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-600/30' 
                  : 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-500/30'
              }`}
            >
              <Power className="w-4 h-4" />
              <span>{settings.isEnabled ? 'Matikan Notifikasi (OFF)' : 'Nyalakan Notifikasi (ON)'}</span>
            </button>
          </div>
        </div>

        {/* Live Device Status Bar */}
        {deviceStatus && (
          <div className="mt-5 p-3.5 rounded-2xl border bg-emerald-950/90 border-emerald-500/40 text-emerald-200 text-xs font-semibold flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <p className="font-bold">
                  Koneksi WhatsApp Gateway: <span className="text-white font-mono">{deviceStatus.raw?.name || 'ALFIN'} ({botNumber})</span>
                </p>
                <p className="text-[11px] text-emerald-300/80 mt-0.5">
                  Sisa Kuota: {deviceStatus.raw?.quota || '998'} Pesan | Status: Terhubung ke Server WhatsApp Fonnte
                </p>
              </div>
            </div>

            <button
              onClick={handleCheckDevice}
              disabled={isCheckingDevice}
              className="px-3 py-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-200 border border-emerald-400/30 rounded-xl text-[11px] font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isCheckingDevice ? 'animate-spin' : ''}`} />
              <span>{isCheckingDevice ? 'Mengecek...' : 'Refresh Sinyal'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        <button
          type="button"
          onClick={() => setActiveTab('settings')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'settings' 
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20' 
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <BellRing className="w-4 h-4" />
          <span>Pengaturan & Kategori Notif (ON/OFF)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('ai_responder')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'ai_responder' 
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-indigo-600/20' 
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Bot className="w-4 h-4 text-purple-400" />
          <span>🤖 AI Tanya Jawab Otomatis (Grup Noted)</span>
          <span className="bg-purple-200 text-purple-900 text-[9px] font-black px-1.5 py-0.5 rounded-full uppercase">
            AI GEMINI
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('test')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'test' 
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20' 
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Send className="w-4 h-4" />
          <span>Tes Kirim Manual</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('logs')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'logs' 
              ? 'bg-slate-800 text-white shadow-md' 
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Riwayat Log ({logs.length})</span>
        </button>
      </div>

      {/* TAB 1: SETTINGS & ON/OFF TOGGLES */}
      {activeTab === 'settings' && (
        <div className="space-y-6">
          {/* Quick On/Off Master Controls */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-800 flex items-center gap-2">
                  <Power className="w-5 h-5 text-emerald-600" />
                  Saklar Kontrol Notifikasi WhatsApp
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Nyalakan atau matikan jenis pesan lelang yang ingin diteruskan otomatis ke grup WhatsApp.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleToggleAll(true)}
                  className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  🟢 Nyalakan Semua
                </button>
                <button
                  type="button"
                  onClick={() => handleToggleAll(false)}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  🔴 Matikan Semua
                </button>
              </div>
            </div>

            {/* Individual Event Toggle Switches */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 1. New Asset Upload */}
              <div className={`p-4 rounded-2xl border-2 transition-all flex items-start justify-between gap-3 ${
                settings.notifyOnNewAsset ? 'bg-emerald-50/40 border-emerald-300' : 'bg-slate-50 border-slate-200 opacity-60'
              }`}>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-bold text-slate-800">🚚 Unit Lelang Baru Di-posting</p>
                    <span className="bg-emerald-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded">UTAMA</span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1">Kirim rincian spesifikasi, foto, dan harga open bid saat ada unit baru.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
                  <input
                    type="checkbox"
                    checked={settings.notifyOnNewAsset}
                    onChange={(e) => setSettings({ ...settings, notifyOnNewAsset: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* 2. New Bid Received */}
              <div className={`p-4 rounded-2xl border-2 transition-all flex items-start justify-between gap-3 ${
                settings.notifyOnNewBid ? 'bg-emerald-50/40 border-emerald-300' : 'bg-slate-50 border-slate-200 opacity-60'
              }`}>
                <div>
                  <p className="text-xs font-bold text-slate-800">💰 Penawaran / Bidding Baru Masuk</p>
                  <p className="text-[11px] text-slate-600 mt-1">Kirim update harga tawaran baru dari peserta lelang.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
                  <input
                    type="checkbox"
                    checked={settings.notifyOnNewBid}
                    onChange={(e) => setSettings({ ...settings, notifyOnNewBid: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* 3. Survey Booking */}
              <div className={`p-4 rounded-2xl border-2 transition-all flex items-start justify-between gap-3 ${
                settings.notifyOnSurveyBooking ? 'bg-emerald-50/40 border-emerald-300' : 'bg-slate-50 border-slate-200 opacity-60'
              }`}>
                <div>
                  <p className="text-xs font-bold text-slate-800">📅 Booking Jadwal Survei Fisik</p>
                  <p className="text-[11px] text-slate-600 mt-1">Kirim tanggal dan jam kunjungan inspeksi armada di pool.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
                  <input
                    type="checkbox"
                    checked={settings.notifyOnSurveyBooking}
                    onChange={(e) => setSettings({ ...settings, notifyOnSurveyBooking: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* 4. Auction Won / Close Bid */}
              <div className={`p-4 rounded-2xl border-2 transition-all flex items-start justify-between gap-3 ${
                settings.notifyOnAuctionWon ? 'bg-emerald-50/40 border-emerald-300' : 'bg-slate-50 border-slate-200 opacity-60'
              }`}>
                <div>
                  <p className="text-xs font-bold text-slate-800">🏆 Pemenang Unit Lelang (Sold Out)</p>
                  <p className="text-[11px] text-slate-600 mt-1">Kirim konfirmasi unit ditutup dan pemenang lelang diumumkan.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
                  <input
                    type="checkbox"
                    checked={settings.notifyOnAuctionWon}
                    onChange={(e) => setSettings({ ...settings, notifyOnAuctionWon: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* 5. User Registration */}
              <div className={`p-4 rounded-2xl border-2 transition-all flex items-start justify-between gap-3 ${
                settings.notifyOnUserRegister ? 'bg-emerald-50/40 border-emerald-300' : 'bg-slate-50 border-slate-200 opacity-60'
              }`}>
                <div>
                  <p className="text-xs font-bold text-slate-800">👤 Registrasi Peserta Lelang Baru</p>
                  <p className="text-[11px] text-slate-600 mt-1">Kirim notifikasi saat ada akun bidder baru yang mendaftar.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
                  <input
                    type="checkbox"
                    checked={settings.notifyOnUserRegister}
                    onChange={(e) => setSettings({ ...settings, notifyOnUserRegister: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* 6. Deposit NPL & Refund */}
              <div className={`p-4 rounded-2xl border-2 transition-all flex items-start justify-between gap-3 ${
                settings.notifyOnNplDeposit ? 'bg-emerald-50/40 border-emerald-300' : 'bg-slate-50 border-slate-200 opacity-60'
              }`}>
                <div>
                  <p className="text-xs font-bold text-slate-800">💳 Pengajuan Deposit NPL & Refund</p>
                  <p className="text-[11px] text-slate-600 mt-1">Kirim konfirmasi pembayaran jaminan lelang atau pengajuan refund.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
                  <input
                    type="checkbox"
                    checked={settings.notifyOnNplDeposit}
                    onChange={(e) => setSettings({ ...settings, notifyOnNplDeposit: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
            </div>

            {/* Target Numbers & Group Configuration */}
            <div className="pt-4 border-t border-slate-100 space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                  <span>Target Link Grup Noted / ID Grup / Nomor WhatsApp:</span>
                  <span className="text-[10px] text-pink-700 font-bold bg-pink-50 px-2 py-0.5 rounded border border-pink-200">
                    Target Siaran Aktif
                  </span>
                </label>
                <input
                  type="text"
                  value={settings.targetNumbers}
                  onChange={(e) => setSettings({ ...settings, targetNumbers: e.target.value })}
                  placeholder="https://chat.whatsapp.com/G0ptrOfAe7S5vZH2oGkmP8"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Fonnte API Token / Key:</label>
                <input
                  type="text"
                  value={settings.apiKey}
                  onChange={(e) => setSettings({ ...settings, apiKey: e.target.value })}
                  placeholder="Token Fonnte..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-semibold text-slate-800 focus:bg-white focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition outline-none"
                />
              </div>
            </div>

            {/* Save Button */}
            <div className="pt-4 flex items-center justify-between border-t border-slate-100">
              <div>
                {saveSuccess && (
                  <div className="flex items-center gap-1.5 text-xs text-emerald-600 font-bold">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Pengaturan Berhasil Disimpan & Diterapkan!</span>
                  </div>
                )}
              </div>

              <button
                type="button"
                onClick={handleSave}
                disabled={isSaving}
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-400 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/20 transition-all flex items-center gap-2 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Menyimpan...' : 'Simpan Semua Pengaturan'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: AI AUTO-RESPONDER KHUSUS GRUP NOTED */}
      {activeTab === 'ai_responder' && (
        <div className="space-y-6">
          {/* AI Banner Card */}
          <div className="bg-gradient-to-r from-purple-950 via-indigo-950 to-slate-900 border-2 border-indigo-500/40 rounded-3xl p-6 text-white shadow-xl space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="p-3 bg-purple-500/20 border border-purple-400/40 text-purple-300 rounded-2xl shrink-0">
                  <Bot className="w-7 h-7" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base md:text-lg font-black text-white">
                      🤖 AI Tanya Jawab Otomatis WhatsApp (Grup Noted)
                    </h2>
                    <span className="bg-purple-500 text-white text-[9px] font-black px-2 py-0.5 rounded-full uppercase">
                      Gemini 3.8 Flash
                    </span>
                  </div>
                  <p className="text-xs text-purple-200/80 mt-1 max-w-2xl leading-relaxed">
                    Asisten AI cerdas yang otomatis menjawab pertanyaan peserta seputar katalog unit lelang, lokasi pool Cakung, jadwal survei fisik, dan cara setor deposit jaminan NPL Rp 5.000.000 secara instan di WhatsApp!
                  </p>
                </div>
              </div>

              {/* AI Master Toggle */}
              <div className="flex items-center gap-3 bg-white/10 px-4 py-2.5 rounded-2xl border border-white/10 shrink-0">
                <span className="text-xs font-bold text-purple-200">
                  {settings.aiAutoResponderEnabled ? 'AI Aktif 🟢' : 'AI Nonaktif 🔴'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.aiAutoResponderEnabled}
                    onChange={(e) => {
                      const updated = { ...settings, aiAutoResponderEnabled: e.target.checked };
                      setSettings(updated);
                      saveFonnteSettings(updated);
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-500"></div>
                </label>
              </div>
            </div>

            {/* Webhook Connection Box */}
            <div className="bg-white/5 border border-white/10 p-4 rounded-2xl text-xs space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <span className="font-bold text-purple-300 flex items-center gap-1.5">
                  <LinkIcon className="w-3.5 h-3.5" />
                  URL Webhook Fonnte untuk Balas Pesan Otomatis:
                </span>
                <button
                  type="button"
                  onClick={handleCopyWebhook}
                  className="text-[11px] bg-purple-500/30 hover:bg-purple-500/50 text-purple-200 border border-purple-400/30 px-3 py-1 rounded-lg font-bold flex items-center gap-1 cursor-pointer"
                >
                  {copiedWebhook ? <CheckCheck className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedWebhook ? 'Tersalin!' : 'Salin URL Webhook'}</span>
                </button>
              </div>
              <p className="font-mono text-[11px] text-emerald-300 bg-black/40 p-2 rounded-lg break-all select-all">
                {webhookUrl}
              </p>
              <p className="text-[10px] text-purple-200/70">
                💡 Masukkan URL webhook di atas ke menu <strong>Webhook</strong> di dashboard akun <a href="https://fonnte.com" target="_blank" rel="noopener noreferrer" className="underline text-purple-300 font-bold">Fonnte.com</a> agar bot langsung membalas chat peserta WhatsApp secara otomatis.
              </p>
            </div>
          </div>

          {/* AI Knowledge Base Editor & Live Tester */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Knowledge Base Editor */}
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
                <div className="p-2 bg-purple-50 text-purple-700 rounded-xl">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-800">Basis Pengetahuan AI (Knowledge Base)</h3>
                  <p className="text-[10px] text-slate-500">Kustomisasi aturan lelang dan SOP yang dijawab oleh AI.</p>
                </div>
              </div>

              <div className="space-y-2">
                <textarea
                  rows={8}
                  value={settings.aiCustomKnowledge}
                  onChange={(e) => setSettings({ ...settings, aiCustomKnowledge: e.target.value })}
                  placeholder="Tuliskan informasi khusus seputar lelang, aturan penawaran, lokasi pool, dan kontak admin..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:border-purple-500 focus:ring-2 focus:ring-purple-200 transition outline-none resize-none leading-relaxed"
                />

                <div className="p-3 bg-slate-50 rounded-xl text-[10px] text-slate-600 space-y-1">
                  <p className="font-bold text-slate-700">📌 AI Otomatis Mengetahui Data Real-Time:</p>
                  <p>• Seluruh daftar unit lelang aktif ({assets.length} unit di database saat ini).</p>
                  <p>• Harga open bid, tahun pembuatan, brand truk, dan status penawaran.</p>
                  <p>• Lokasi Pool Utama Cakung & jadwal survei fisik.</p>
                </div>

                <button
                  type="button"
                  onClick={handleSave}
                  disabled={isSaving}
                  className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 disabled:bg-purple-400 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-600/20 transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{isSaving ? 'Menyimpan...' : 'Simpan Basis Pengetahuan AI'}</span>
                </button>
              </div>
            </div>

            {/* Interactive Live AI Simulator */}
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl">
                    <MessageCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-800">Simulator AI Tanya Jawab (Uji Coba Langsung)</h3>
                    <p className="text-[10px] text-slate-500">Ketik pertanyaan peserta untuk melihat respon AI WhatsApp.</p>
                  </div>
                </div>

                <span className="bg-emerald-100 text-emerald-800 text-[9px] font-black px-2 py-0.5 rounded-full">
                  LIVE TESTER
                </span>
              </div>

              {/* Quick Prompt Chips */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-bold text-slate-500">Contoh Pertanyaan Cepat:</span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      const q = 'Halo, ada unit dump truck apa saja yang buka lelang saat ini?';
                      setAiQuestion(q);
                      handleTestAiQuery(q);
                    }}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-purple-100 hover:text-purple-900 text-slate-700 rounded-lg text-[10px] font-semibold transition cursor-pointer"
                  >
                    🚚 Unit Dump Truck
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const q = 'Bagaimana syarat ikut lelang dan berapa uang jaminan NPL?';
                      setAiQuestion(q);
                      handleTestAiQuery(q);
                    }}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-purple-100 hover:text-purple-900 text-slate-700 rounded-lg text-[10px] font-semibold transition cursor-pointer"
                  >
                    💰 Syarat & Deposit NPL
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const q = 'Kapan jadwal survei fisik dan di mana lokasi pool unitnya?';
                      setAiQuestion(q);
                      handleTestAiQuery(q);
                    }}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-purple-100 hover:text-purple-900 text-slate-700 rounded-lg text-[10px] font-semibold transition cursor-pointer"
                  >
                    📅 Lokasi & Survei Fisik
                  </button>
                </div>
              </div>

              {/* Input Form */}
              <div className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={aiQuestion}
                    onChange={(e) => setAiQuestion(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleTestAiQuery()}
                    placeholder="Tulis pertanyaan seputar lelang..."
                    className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:border-purple-500 outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => handleTestAiQuery()}
                    disabled={isGeneratingAi}
                    className="px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-purple-400 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <Sparkles className={`w-3.5 h-3.5 ${isGeneratingAi ? 'animate-spin' : ''}`} />
                    <span>{isGeneratingAi ? 'Memproses...' : 'Tanya AI'}</span>
                  </button>
                </div>

                {/* AI Result Box */}
                {aiAnswer && (
                  <div className="mt-3 p-4 bg-slate-900 text-emerald-400 rounded-2xl border border-slate-800 font-mono text-xs whitespace-pre-wrap leading-relaxed space-y-3">
                    <p>{aiAnswer}</p>

                    <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <span className="text-[10px] text-slate-400 font-sans">Format Pesan WhatsApp Resmi</span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={handleSimulateIncomingWa}
                          disabled={isSimulatingWa}
                          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer font-sans"
                        >
                          <Sparkles className={`w-3 h-3 ${isSimulatingWa ? 'animate-spin' : ''}`} />
                          <span>{isSimulatingWa ? 'Memproses...' : '🧪 Simulasi Masuk & Kirim ke WA'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={handleSendAiAnswerToWhatsApp}
                          disabled={isSendingAiToWa}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer font-sans"
                        >
                          <Send className="w-3 h-3" />
                          <span>{isSendingAiToWa ? 'Mengirim...' : 'Kirim ke WhatsApp'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MANUAL TEST */}
      {activeTab === 'test' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-6 max-w-2xl mx-auto">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Tes Kirim Pesan Langsung ke WhatsApp / Grup Noted</h3>
              <p className="text-xs text-slate-500">Uji coba konektivitas server Fonnte ke nomor atau grup tujuan.</p>
            </div>
          </div>

          <form onSubmit={handleSendTest} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Tujuan (Link Grup Noted / Nomor WhatsApp):</label>
              <input
                type="text"
                value={testNumber}
                onChange={(e) => setTestNumber(e.target.value)}
                placeholder="https://chat.whatsapp.com/G0ptrOfAe7S5vZH2oGkmP8"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:border-blue-500 outline-none"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Teks Pesan Uji Coba:</label>
              <textarea
                rows={5}
                value={testMessageText}
                onChange={(e) => setTestMessageText(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:border-blue-500 outline-none resize-none font-mono leading-relaxed"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isTesting}
              className="w-full py-3 bg-pink-600 hover:bg-pink-700 disabled:bg-pink-400 text-white rounded-xl text-xs font-bold shadow-md shadow-pink-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send className={`w-4 h-4 ${isTesting ? 'animate-pulse' : ''}`} />
              <span>{isTesting ? 'Mengirim ke WhatsApp...' : 'Kirim Pesan Uji Coba Sekarang'}</span>
            </button>

            {testResult && (
              <div className={`p-4 rounded-xl text-xs font-semibold flex items-start gap-2.5 ${
                testResult.success ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200'
              }`}>
                {testResult.success ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                )}
                <div>
                  <p className="font-bold">{testResult.success ? 'Pesan Berhasil Terkirim ke WhatsApp!' : 'Gagal Mengirim Pesan'}</p>
                  <p className="text-[11px] mt-0.5 opacity-90">{testResult.message}</p>
                </div>
              </div>
            )}
          </form>
        </div>
      )}

      {/* TAB 4: DISPATCH LOGS */}
      {activeTab === 'logs' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-800">Riwayat Pengiriman Real-Time WhatsApp / Grup Noted</h3>
                <p className="text-[10px] text-slate-500">Log pesan notifikasi yang telah diteruskan ke target WhatsApp.</p>
              </div>
            </div>

            <button
              onClick={loadLogs}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh Log</span>
            </button>
          </div>

          {logs.length > 0 ? (
            <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
              {logs.map((log) => (
                <div key={log.id} className="py-3 flex flex-col md:flex-row md:items-center justify-between gap-2 text-xs">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[9px] font-extrabold uppercase tracking-wider ${
                        log.status === 'success' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {log.status === 'success' ? 'TERKIRIM' : 'GAGAL'}
                      </span>
                      <span className="font-bold text-slate-800">{log.title}</span>
                      <span className="text-[10px] text-slate-400 font-mono">Ke: {log.target}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 line-clamp-1">{log.preview}</p>
                  </div>
                  <div className="text-right shrink-0 text-[10px] text-slate-400 font-mono">
                    {new Date(log.timestamp).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' })} WIB
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-12 text-center text-slate-400 text-xs flex flex-col items-center justify-center gap-2">
              <Smartphone className="w-10 h-10 text-slate-300" />
              <p className="font-medium">Belum ada riwayat pengiriman notifikasi WhatsApp.</p>
              <p className="text-[10px]">Pesan akan tercatat saat ada aksi lelang di website atau saat Anda melakukan tes kirim.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
