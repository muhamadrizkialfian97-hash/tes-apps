export interface Bid {
  id: string;
  name: string;
  email: string;
  contact: string;
  price: number;
  timestamp: string;
  scheduleSurveyDate?: string;
  scheduleSurveyTime?: string;
  itemBids?: UsedPartItem[];
}

export type AssetStatus = 'Open' | 'Sold';

export const MAIN_CATEGORIES = ['Vehicle', 'Used part', 'Property', 'Miscellaneous'] as const;

export function normalizeCategory(category?: string): string {
  if (!category) return 'Vehicle';
  const matched = MAIN_CATEGORIES.find(c => c.toLowerCase() === category.trim().toLowerCase());
  return matched || 'Vehicle';
}

export function getCleanAssetName(asset: { name?: string; brand?: string; category?: string } | null | undefined): string {
  if (!asset) return '';
  const normCat = normalizeCategory(asset.category);
  let name = (asset.name || '').trim();
  if (normCat === 'Used part' || normCat === 'Property' || normCat === 'Miscellaneous') {
    // Strip accidental leading truck brand like "Hino "
    name = name.replace(/^(Hino|Isuzu|Fuso|Scania|Toyota|Caterpillar|Komatsu)\s+/i, '').trim() || name;
  }
  return name || asset.name || '';
}

export function isSubCategoryMatch(
  asset: { usedPartCategory?: string; usedPartCategories?: string[] } | null | undefined,
  target: string
): boolean {
  if (!asset) return false;
  const targetLower = target.trim().toLowerCase();
  if (asset.usedPartCategories && Array.isArray(asset.usedPartCategories) && asset.usedPartCategories.length > 0) {
    return asset.usedPartCategories.some(c => c.trim().toLowerCase() === targetLower);
  }
  if (!asset.usedPartCategory) return false;
  const parts = asset.usedPartCategory.split(',').map(s => s.trim().toLowerCase());
  return parts.includes(targetLower) || asset.usedPartCategory.toLowerCase() === targetLower;
}

export function getGoogleMapsUrl(input?: string): string | null {
  if (!input || !input.trim()) return null;
  const val = input.trim();
  if (val.startsWith('http://') || val.startsWith('https://')) {
    return val;
  }
  const coordRegex = /^\s*[-+]?([1-8]?\d(\.\d+)?|90(\.0+)?)\s*,\s*[-+]?(180(\.0+)?|((1[0-7]\d)|([1-9]?\d))(\.\d+)?)\s*$/;
  if (coordRegex.test(val)) {
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(val)}`;
  }
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(val)}`;
}

export interface UsedPartItem {
  id?: string;
  type: string;
  name?: string;
  spec?: string;
  qty: number | string;
  uom?: string;
  unitPrice: number | string;
  totalPrice?: number | string;
  notes?: string;
}

export function normalizeUsedPartItem(it: UsedPartItem): UsedPartItem {
  let q = Number(it.qty) || 0;
  let spec = String(it.spec || '').trim();

  // If qty is 0 or missing, but spec is numeric (e.g. "93"), then qty is that number and spec becomes '-'
  if (q <= 0 && spec !== '' && !isNaN(Number(spec)) && Number(spec) > 0) {
    q = Number(spec);
    spec = '-';
  } else if (q > 0 && spec !== '' && !isNaN(Number(spec)) && Number(spec) === q) {
    spec = '-';
  }

  return {
    ...it,
    qty: q > 0 ? q : (Number(it.qty) || 0),
    spec: spec === '' ? '-' : spec
  };
}

export function getHighestBidBreakdown(asset: Asset): { highestBidObj: Bid | null; highestItemBids: UsedPartItem[] } {
  const bids = asset.bids || [];
  const validBids = bids.filter(b => Number(b.price) > 0 && Number(b.price) < 1000000000);
  const highestBidObj = validBids.length > 0 
    ? [...validBids].sort((a, b) => Number(b.price) - Number(a.price))[0] 
    : null;

  const rawBaseItems = asset.usedPartItems || [];
  const baseItems = rawBaseItems.map(normalizeUsedPartItem);

  if (!highestBidObj) {
    return {
      highestBidObj: null,
      highestItemBids: baseItems.map(it => ({
        ...it,
        unitPrice: 0,
        totalPrice: 0
      }))
    };
  }

  if (highestBidObj.itemBids && highestBidObj.itemBids.length > 0) {
    return {
      highestBidObj,
      highestItemBids: highestBidObj.itemBids.map((it, idx) => {
        const normIt = normalizeUsedPartItem(it);
        const q = Number(normIt.qty) || Number(baseItems[idx]?.qty) || 0;
        const p = Number(normIt.unitPrice) || 0;
        return {
          ...normIt,
          type: normIt.type || baseItems[idx]?.type || '-',
          qty: q,
          unitPrice: p,
          totalPrice: typeof normIt.totalPrice === 'number' ? normIt.totalPrice : (q * p)
        };
      })
    };
  }

  const totalBasePrice = baseItems.reduce((sum, it) => {
    const q = Number(it.qty) || 0;
    const p = Number(it.unitPrice) || 0;
    return sum + (typeof it.totalPrice === 'number' ? it.totalPrice : (q * p));
  }, 0);

  const ratio = totalBasePrice > 0 ? (highestBidObj.price / totalBasePrice) : 1;

  const highestItemBids = baseItems.map(it => {
    const q = Number(it.qty) || 0;
    const p = Number(it.unitPrice) || 0;
    const computedUnitPrice = Math.round(p * ratio);
    return {
      ...it,
      unitPrice: computedUnitPrice,
      totalPrice: q * computedUnitPrice
    };
  });

  return {
    highestBidObj,
    highestItemBids
  };
}

export interface Asset {
  id: string;
  name: string;
  brand: string;
  category: string;
  modelYear: number | string;
  plateNumber: string;
  condition: string;
  location: string;
  description: string;
  startingPrice: number;
  highestBid: number;
  status: AssetStatus;
  imageUrl: string;
  imageUrls?: string[];
  images?: string[];
  bids: Bid[];
  paymentStatus?: 'Lunas' | 'Belum Lunas';
  manifestStatus?: 'Pake Manifest' | 'Tidak Pake Manifest';
  dimensions?: string;
  propertyType?: string;
  auctionType?: string;
  landArea?: string;
  buildingArea?: string;
  // Used Part specific fields
  usedPartCategory?: 'Ban' | 'Aki' | 'Besi' | 'Oli' | 'Lainnya' | string;
  usedPartCategories?: string[];
  quantity?: string;
  salesSystem?: string;
  openHouseSchedule?: string;
  useItemTableMode?: boolean;
  usedPartItems?: UsedPartItem[];
  hiddenItemColumns?: string[];
  otherPartsNotes?: string;
  // Ban fields
  tireBrand?: string;
  tireSize?: string;
  tireType?: string;
  tireRimType?: string;
  tireTreadDepth?: string;
  tireCondition?: string;
  tireDotCode?: string;
  // Aki fields
  batteryBrand?: string;
  batteryTypeCode?: string;
  batteryCapacity?: string;
  batteryType?: string;
  batteryCondition?: string;
  batteryElectrolyteStatus?: string;
  // Besi fields
  metalType?: string;
  metalSalesMethod?: string;
  metalEstimatedWeight?: string;
  metalCondition?: string;
  metalHandlingFacility?: string;
  // Oli fields
  oilBrand?: string;
  oilType?: string;
  oilCondition?: string;
  oilVolume?: string;
  model?: string;
  series?: string;
  axels?: string;
  vehicleColour?: string;
  fuelType?: string;
  horsepower?: string;
  odometer?: string;
  keurValidUntil?: string;
  stnkPlateValidUntil?: string;
  stnkTaxValidUntil?: string;
  haveAttachment?: boolean;
  attachmentCategory?: string;
  attachmentImageUrl?: string;
  attachmentImageUrls?: string[];
  attachmentType?: string;
  attachmentAxels?: string;
  attachmentYearBuilt?: string;
  attachmentKeurNo?: string;
  attachmentValidUntil?: string;
  attachmentLength?: string;
  attachmentWidth?: string;
  attachmentHeight?: string;
  attachmentExtension?: string;
  tnc?: string;
  closeBidDate?: string;
  coordinates?: string;
  createdAt?: string;
  winnerEmail?: string;
  winnerName?: string;
}

export function getAssetPostTime(asset: Asset): number {
  if (!asset) return 0;
  
  if (asset.createdAt) {
    const t = new Date(asset.createdAt).getTime();
    if (!isNaN(t) && t > 0) {
      return t;
    }
  }
  return 0;
}

export function sortAssetsByNewest(assets: Asset[]): Asset[] {
  if (!Array.isArray(assets)) return [];
  return [...assets].sort((a, b) => {
    const timeA = getAssetPostTime(a);
    const timeB = getAssetPostTime(b);
    if (timeA !== timeB) {
      return timeB - timeA; // Descending time
    }
    // Fallback to numeric ID parsing
    const getNum = (id: string) => {
      const matches = (id || '').match(/\d+/g);
      if (matches && matches.length > 0) {
        return parseInt(matches[matches.length - 1], 10) || 0;
      }
      return 0;
    };
    return getNum(b.id) - getNum(a.id); // Descending ID
  });
}

export interface AdminUser {
  email: string;
  name: string;
  role: string;
  createdAt: string;
  password?: string;
}

export interface Brand {
  id: string;
  name: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  createdAt: string;
}

export interface Condition {
  id: string;
  name: string;
  createdAt: string;
}

export interface Series {
  id: string;
  name: string;
  createdAt: string;
}

export interface VehicleColour {
  id: string;
  name: string;
  createdAt: string;
}

export interface FuelType {
  id: string;
  name: string;
  createdAt: string;
}

export interface AttachmentCategory {
  id: string;
  name: string;
  createdAt: string;
}

export interface AttachmentType {
  id: string;
  name: string;
  createdAt: string;
}

export interface RegisteredUser {
  email: string;
  name: string;
  phone: string;
  password?: string;
  company?: string;
  address?: string;
  status: 'Menunggu Verifikasi' | 'Menunggu Persetujuan' | 'Disetujui' | 'Ditolak';
  emailVerified: boolean;
  verificationCode: string;
  createdAt: string;
  canBid?: boolean; // Default true when approved. If false, user cannot place bids (View Only)
  allowedCategoryAccess?: 'All' | 'Vehicle' | 'Used part' | 'Property' | string; // Category access permission filter
  userType?: 'internal' | 'external'; // New field
  approvedBy?: string;
  approvedAt?: string;
}

export interface ToastNotification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'bid' | 'sync';
  title: string;
  message: string;
  timestamp: Date;
  assetId?: string;
  read?: boolean;
}

export interface BiddingRequest {
  id: string;
  email: string;
  userName: string;
  phone?: string;
  requestType: string;
  proofUrl: string; // Base64 image
  status: 'Pending' | 'Approved' | 'Rejected';
  createdAt: string;
  updatedAt?: string;
  notes?: string;
  approvedBy?: string;
  approvedAt?: string;
}

export interface RefundRequest {
  id: string;
  email: string;
  userName: string;
  phone: string;
  purpose: string; // Keperluan refund
  proofUrl: string; // Base64 image upload
  status: 'Pending' | 'Approved' | 'Rejected';
  createdAt: string;
  updatedAt?: string;
  amount?: number;
  bankName?: string;
  accountNumber?: string;
  accountHolder?: string;
  registerEntryName?: string;
  approvedBy?: string;
  approvedAt?: string;
}

export interface WaSessionData {
  id: string; // user email
  email: string;
  status: 'disconnected' | 'connecting' | 'connected';
  connectedPhone: string;
  updatedAt: string;
}

export interface WaTemplateData {
  id: string;
  name: string;
  category: string;
  content: string;
  imageUrl?: string;
  createdAt?: string;
}

export type PopupTargetCategory = 'all' | 'vehicle' | 'sparepart' | 'property';

export interface PopupItem {
  id: string;
  title: string;
  subtitle?: string;
  layoutType?: 'simple' | 'detailed';
  imageUrl?: string;
  mainDescription?: string;
  depositHighlight?: string;
  descriptionSuffix?: string;
  securityTitle?: string;
  securityDescription?: string;
  cancellationTitle?: string;
  cancellationDescription?: string;
  closingSlogan?: string;
  ppnDisclaimer?: string;
  ctaButtonText?: string;
  ctaButtonUrl?: string;
  surveyDate?: string;
  surveyTime?: string;
  surveyLocation?: string;
  biddingDate?: string;
  biddingTime?: string;
  additionalNote?: string;
  targetCategory?: PopupTargetCategory;
  showBeforeLogin: boolean;
  showAfterLogin: boolean;
  isActive: boolean;
  createdAt: string;
}

export interface PopupConfig {
  popups: PopupItem[];
}

export const DEFAULT_POPUP_ITEM: PopupItem = {
  id: 'default_bidding_rules_popup',
  title: 'Syarat & Ketentuan Akses Bidding - Lelang Truck Pancaran Platinum',
  subtitle: 'Informasi Resmi Deposit & Akses Penawaran',
  layoutType: 'detailed',
  imageUrl: 'https://lh3.googleusercontent.com/d/19rthCmJjo1yZlT94ce5xY_mcwGnyaqjN',
  mainDescription: 'Untuk menjaga kualifikasi dan kelancaran proses penawaran, setiap peserta diwajibkan melakukan',
  depositHighlight: 'deposit jaminan sebesar Rp10.000.000,- di Rekening Resmi Kantor Pancaran.',
  descriptionSuffix: 'sebagai syarat aktif untuk melakukan penawaran (Bidding) khusus Lelang kendaraan.',
  securityTitle: 'Jaminan Keamanan Dana:',
  securityDescription: 'Bagi peserta yang belum berkesempatan menjadi pemenang, dana deposit sebesar Rp10.000.000,- akan dikembalikan penuh (100%) Maximal 5 hari kerja setelah pengumuman pemenang resmi dan memasuki tahapan acara selanjutnya.',
  cancellationTitle: 'Syarat & Ketentuan Pembatalan:',
  cancellationDescription: 'Deposit akan dianggap hangus seluruhnya 100% apabila pemenang mengundurkan diri atau tidak menyelesaikan proses transaksi dalam jangka waktu maksimal 7 (tujuh) hari.',
  closingSlogan: 'Mari bergabung dan dapatkan unit impian Anda di ajang eksklusif Pancaran Platinum!',
  ppnDisclaimer: '*Harga belum termasuk PPN',
  ctaButtonText: 'Hubungi Panitia untuk Akses Bidding',
  ctaButtonUrl: 'https://wa.me/6281317469744?text=Halo%20Panitia%20Lelang%20Pancaran%20Platinum,%20saya%20ingin%20mengkonfirmasi%20deposit%20jaminan%20Rp10.000.000%20untuk%20akses%20bidding%20lelang.',
  targetCategory: 'vehicle',
  showBeforeLogin: false,
  showAfterLogin: true,
  isActive: true,
  createdAt: '2026-01-01T00:00:00.000Z',
};

export const DEFAULT_SCHEDULE_POPUP_ITEM: PopupItem = {
  id: 'default_schedule_popup',
  title: 'Pengumuman Jadwal Lelang & Survey Fisik Unit',
  subtitle: 'Informasi Resmi Waktu Pelaksanaan Lelang Pancaran Platinum',
  layoutType: 'simple',
  imageUrl: 'https://lh3.googleusercontent.com/d/17N7xTwx4PcaqLK3NN6nq04x0yATldWaU',
  surveyDate: '18 - 22 Agustus 2026',
  surveyTime: '09.00 - 16.00 WIB',
  surveyLocation: 'Pool & Gudang Logistik Pancaran Utama',
  biddingDate: '25 Agustus 2026',
  biddingTime: '10.00 WIB s/d Selesai',
  additionalNote: 'Penting: Peserta wajib hadir tepat waktu untuk survey fisik dan membawa KTP asli serta bukti transfer deposit.',
  mainDescription: 'Pastikan Anda telah melengkapi deposit jaminan dan bersiap mengikuti bidding online.',
  targetCategory: 'all',
  showBeforeLogin: true,
  showAfterLogin: true,
  isActive: true, // active by default
  createdAt: '2026-01-02T00:00:00.000Z',
};

export const DEFAULT_POPUP_CONFIG: PopupConfig = {
  popups: [DEFAULT_POPUP_ITEM, DEFAULT_SCHEDULE_POPUP_ITEM],
};

export const EMPTY_POPUP_CONFIG: PopupConfig = {
  popups: [],
};

export interface ApprovalLog {
  id: string;
  timestamp: string;
  actionType: 'MARK_SOLD' | 'APPROVE_USER' | 'REJECT_USER' | 'APPROVE_BID' | 'TOGGLE_BIDDING' | string;
  targetName: string;
  targetId?: string;
  adminEmail: string;
  adminName: string;
  details: string;
  previousStatus?: string;
  newStatus?: string;
}

export interface FonnteSettings {
  apiKey: string;
  targetNumbers: string;
  groupLink: string;
  countryCode: string;
  isEnabled: boolean;
  notifyOnNewAsset: boolean;
  notifyOnNewBid: boolean;
  notifyOnSurveyBooking: boolean;
  notifyOnAuctionWon: boolean;
  notifyOnUserRegister: boolean;
  notifyOnNplDeposit: boolean;
  notifyOnAssetUpdate: boolean;
  aiAutoResponderEnabled: boolean;
  aiCustomKnowledge: string;
  senderName: string;
  updatedAt?: string;
}

export const DEFAULT_FONNTE_SETTINGS: FonnteSettings = {
  apiKey: '9or6UWq4go6WXNCtSsLd',
  targetNumbers: 'https://chat.whatsapp.com/G0ptrOfAe7S5vZH2oGkmP8',
  groupLink: 'https://chat.whatsapp.com/G0ptrOfAe7S5vZH2oGkmP8',
  countryCode: '62',
  isEnabled: true,
  notifyOnNewAsset: true,
  notifyOnNewBid: true,
  notifyOnSurveyBooking: true,
  notifyOnAuctionWon: true,
  notifyOnUserRegister: true,
  notifyOnNplDeposit: true,
  notifyOnAssetUpdate: true,
  aiAutoResponderEnabled: true,
  aiCustomKnowledge: 'PT Pancaran Lelang Platinum adalah platform lelang armada logistik & truk terpercaya. Lokasi pool: Pool Utama Cakung, Jakarta Timur. Syarat ikut lelang: Memiliki akun terverifikasi dan menyetor deposit jaminan NPL sebesar Rp 5.000.000 per lot. Survei unit fisik dibuka Senin-Jumat pukul 09.00 - 16.00 WIB. Pelunasan pemenang maksimal 3 hari kerja setelah lelang ditutup.',
  senderName: 'Pancaran Lelang Official',
  updatedAt: '2026-01-01T00:00:00.000Z'
};


