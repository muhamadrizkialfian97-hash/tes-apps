import { FonnteSettings, DEFAULT_FONNTE_SETTINGS, Asset } from '../types';
import { db } from '../firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';

const FONNTE_STORAGE_KEY = 'fonnte_settings_config_v1';
const FONNTE_DOC_ID = 'fonnte_settings';

export interface FonnteGroup {
  id: string;
  name: string;
  member_count?: number;
}

export interface FonnteLogItem {
  id: string;
  timestamp: string;
  type: string;
  title: string;
  target: string;
  status: 'success' | 'failed';
  responseMessage?: string;
  preview: string;
}

const FONNTE_LOGS_STORAGE_KEY = 'fonnte_dispatch_logs_v1';
const SENT_EVENTS_STORAGE_KEY = 'fonnte_sent_events_registry_v1';

/**
 * Check if a specific event has already been sent to WhatsApp to prevent duplicates
 */
export function isEventAlreadySent(eventId: string): boolean {
  if (!eventId) return false;
  try {
    const raw = localStorage.getItem(SENT_EVENTS_STORAGE_KEY);
    const registry: string[] = raw ? JSON.parse(raw) : [];
    return registry.includes(eventId);
  } catch {
    return false;
  }
}

/**
 * Mark an event as sent to WhatsApp
 */
export function markEventAsSent(eventId: string) {
  if (!eventId) return;
  try {
    const raw = localStorage.getItem(SENT_EVENTS_STORAGE_KEY);
    const registry: string[] = raw ? JSON.parse(raw) : [];
    if (!registry.includes(eventId)) {
      const updated = [eventId, ...registry].slice(0, 500);
      localStorage.setItem(SENT_EVENTS_STORAGE_KEY, JSON.stringify(updated));
    }
  } catch (e) {
    console.error('Failed to save sent event registry:', e);
  }
}

/**
 * Get current Fonnte settings from Firestore or localStorage fallback
 */
export async function getFonnteSettings(): Promise<FonnteSettings> {
  try {
    const docRef = doc(db, 'config', FONNTE_DOC_ID);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      const data = docSnap.data() as FonnteSettings;
      const merged = { ...DEFAULT_FONNTE_SETTINGS, ...data };
      localStorage.setItem(FONNTE_STORAGE_KEY, JSON.stringify(merged));
      return merged;
    }
  } catch (err) {
    console.warn('[Fonnte] Firestore read error, using localStorage:', err);
  }

  const cached = localStorage.getItem(FONNTE_STORAGE_KEY);
  if (cached) {
    try {
      return { ...DEFAULT_FONNTE_SETTINGS, ...JSON.parse(cached) };
    } catch {
      // fallback
    }
  }
  return DEFAULT_FONNTE_SETTINGS;
}

/**
 * Save Fonnte settings to Firestore & localStorage
 */
export async function saveFonnteSettings(settings: FonnteSettings): Promise<boolean> {
  const dataToSave: FonnteSettings = {
    ...settings,
    updatedAt: new Date().toISOString()
  };

  localStorage.setItem(FONNTE_STORAGE_KEY, JSON.stringify(dataToSave));

  try {
    const docRef = doc(db, 'config', FONNTE_DOC_ID);
    await setDoc(docRef, dataToSave, { merge: true });
    return true;
  } catch (err) {
    console.warn('[Fonnte] Firestore write error (saved to localStorage):', err);
    return true;
  }
}

/**
 * Get recent Fonnte dispatch logs
 */
export function getFonnteLogs(): FonnteLogItem[] {
  try {
    const raw = localStorage.getItem(FONNTE_LOGS_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

/**
 * Save a dispatch log item
 */
export function addFonnteLog(log: FonnteLogItem) {
  try {
    const logs = getFonnteLogs();
    const updated = [log, ...logs].slice(0, 50); // keep last 50
    localStorage.setItem(FONNTE_LOGS_STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to save fonnte log:', e);
  }
}

/**
 * Fetch WhatsApp groups / communities from Fonnte
 */
export async function fetchFonnteGroups(apiKey?: string): Promise<{ success: boolean; groups: FonnteGroup[]; message?: string }> {
  try {
    const settings = await getFonnteSettings();
    const token = apiKey || settings.apiKey || DEFAULT_FONNTE_SETTINGS.apiKey;

    const res = await fetch('/api/fonnte/groups', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ apiKey: token })
    });

    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data)) {
        return { success: true, groups: data };
      } else if (data.data && Array.isArray(data.data)) {
        return { success: true, groups: data.data };
      }
      return { success: true, groups: [] };
    }

    // Direct fallback
    const directRes = await fetch('https://api.fonnte.com/get-whatsapp-group', {
      method: 'POST',
      headers: { 'Authorization': token }
    });
    const data = await directRes.json();
    if (Array.isArray(data)) {
      return { success: true, groups: data };
    } else if (data.data && Array.isArray(data.data)) {
      return { success: true, groups: data.data };
    }
    return { success: true, groups: [] };
  } catch (err: any) {
    console.warn('Failed to fetch groups from Fonnte:', err);
    return { success: false, groups: [], message: err.message || 'Gagal memuat grup WhatsApp' };
  }
}

/**
 * Join a WhatsApp group via invite link using Fonnte API
 */
export async function joinFonnteGroup(groupLink?: string, apiKey?: string): Promise<{ success: boolean; message: string; raw?: any }> {
  try {
    const settings = await getFonnteSettings();
    const token = apiKey || settings.apiKey || DEFAULT_FONNTE_SETTINGS.apiKey;
    const url = groupLink || settings.groupLink || DEFAULT_FONNTE_SETTINGS.groupLink || 'https://chat.whatsapp.com/G0ptrOfAe7S5vZH2oGkmP8';

    const res = await fetch('/api/fonnte/join-group', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ apiKey: token, link: url })
    });

    if (res.ok) {
      const data = await res.json();
      return {
        success: data.status === true,
        message: data.reason || data.detail || (data.status ? 'Berhasil bergabung ke grup WhatsApp' : 'Respon Fonnte: ' + JSON.stringify(data)),
        raw: data
      };
    }

    const directForm = new URLSearchParams();
    directForm.append('url', url);
    const directRes = await fetch('https://api.fonnte.com/join-group', {
      method: 'POST',
      headers: { 'Authorization': token },
      body: directForm
    });
    const directData = await directRes.json();
    return {
      success: directData.status === true,
      message: directData.reason || directData.detail || (directData.status ? 'Berhasil bergabung ke grup WhatsApp' : 'Respon Fonnte: ' + JSON.stringify(directData)),
      raw: directData
    };
  } catch (err: any) {
    return {
      success: false,
      message: err.message || 'Gagal mengirim permintaan bergabung ke grup'
    };
  }
}

/**
 * Check Fonnte device status
 */
export async function checkFonnteDevice(apiKey?: string): Promise<{ success: boolean; message: string; raw?: any }> {
  try {
    const settings = await getFonnteSettings();
    const token = apiKey || settings.apiKey || DEFAULT_FONNTE_SETTINGS.apiKey;

    const res = await fetch('/api/fonnte/device', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ apiKey: token })
    });

    if (res.ok) {
      const data = await res.json();
      return {
        success: data.status === true || !!data.device_status,
        message: data.reason || data.message || (data.status ? 'Device WhatsApp Terhubung' : 'Device Belum Terhubung'),
        raw: data
      };
    }

    // Direct fallback if server route is unreachable
    const directRes = await fetch('https://api.fonnte.com/device', {
      method: 'POST',
      headers: { 'Authorization': token }
    });
    const data = await directRes.json();
    return {
      success: data.status === true || !!data.device_status,
      message: data.reason || data.message || (data.status ? 'Device WhatsApp Terhubung' : 'Device Belum Terhubung'),
      raw: data
    };
  } catch (error: any) {
    return {
      success: false,
      message: error.message || 'Gagal menghubungi server Fonnte'
    };
  }
}

/**
 * Ask Gemini AI Auction Assistant for WhatsApp automatic replies
 */
export async function askAiAuctionAssistant(
  question: string, 
  assetContext?: any[], 
  customKnowledge?: string
): Promise<{ success: boolean; answer: string }> {
  try {
    const res = await fetch('/api/wa/ai-respond', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, assetContext, customKnowledge })
    });
    const data = await res.json();
    if (data.status && data.answer) {
      return { success: true, answer: data.answer };
    }
    return { success: false, answer: data.error || 'Gagal menghasilkan jawaban AI' };
  } catch (err: any) {
    return { success: false, answer: err.message || 'Gagal menghubungi server AI' };
  }
}

/**
 * Core function to send WhatsApp via Fonnte to personal number OR group/community (e.g. "Noted")
 */
export async function sendFonnteMessage(
  targetPhoneOrGroup: string,
  messageText: string,
  customApiKey?: string,
  customCountryCode?: string
): Promise<{ success: boolean; message: string; data?: any }> {
  if (!targetPhoneOrGroup || !messageText) {
    return { success: false, message: 'Nomor/Grup tujuan dan pesan wajib diisi' };
  }

  const settings = await getFonnteSettings();
  const token = customApiKey || settings.apiKey || DEFAULT_FONNTE_SETTINGS.apiKey;
  const countryCode = customCountryCode || settings.countryCode || '62';

  // Target can be phone number, group ID (with @g.us), or multiple targets separated by comma
  const rawTarget = targetPhoneOrGroup.trim();

  try {
    // 1. Try server proxy endpoint
    const response = await fetch('/api/fonnte/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        apiKey: token,
        target: rawTarget,
        message: messageText,
        countryCode: countryCode
      })
    });

    if (response.ok) {
      const resData = await response.json();
      return {
        success: resData.status === true,
        message: resData.reason || resData.detail || (resData.status ? 'Pesan WhatsApp Terkirim' : 'Gagal mengirim pesan'),
        data: resData
      };
    }

    // 2. Direct Fallback if server proxy returned error
    const formData = new URLSearchParams();
    formData.append('target', rawTarget);
    formData.append('message', messageText);
    formData.append('countryCode', countryCode);

    const directRes = await fetch('https://api.fonnte.com/send', {
      method: 'POST',
      headers: { 'Authorization': token },
      body: formData
    });

    const directData = await directRes.json();
    return {
      success: directData.status === true,
      message: directData.reason || directData.detail || (directData.status ? 'Pesan WhatsApp Terkirim' : 'Gagal mengirim pesan'),
      data: directData
    };
  } catch (error: any) {
    console.error('[Fonnte Error]', error);
    return {
      success: false,
      message: error.message || 'Terjadi kesalahan koneksi ke Fonnte'
    };
  }
}

/**
 * High-level automatic notification dispatcher
 * Formats and sends real-time notifications to personal WhatsApp or Grup "Noted"
 */
export async function sendFonnteNotification(
  type: string,
  title: string,
  message: string,
  extraDetails?: {
    eventId?: string;
    assetId?: string;
    assetName?: string;
    brand?: string;
    category?: string;
    year?: number | string;
    condition?: string;
    poolLocation?: string;
    userName?: string;
    userPhone?: string;
    userEmail?: string;
    price?: number;
    surveyDate?: string;
    surveyTime?: string;
    customFooter?: string;
  }
): Promise<boolean> {
  try {
    // Generate or check event ID to prevent duplicate blasts
    const eventKey = extraDetails?.eventId || `${type}_${extraDetails?.assetId || ''}_${title}`;
    if (eventKey && isEventAlreadySent(eventKey)) {
      console.log(`[Fonnte Deduplication] Event "${eventKey}" has already been sent to WhatsApp group. Skipping duplicate broadcast.`);
      return false;
    }

    const settings = await getFonnteSettings();
    if (!settings.isEnabled) {
      console.log('[Fonnte] WhatsApp notification is disabled in settings.');
      return false;
    }

    const lowerTitle = (title || '').toLowerCase();
    const lowerType = (type || '').toLowerCase();

    // Event filter check
    const isNewAsset = lowerTitle.includes('upload') || lowerTitle.includes('armada baru') || lowerTitle.includes('unit baru') || lowerTitle.includes('posting baru') || lowerType === 'upload';
    const isNewBid = lowerTitle.includes('penawaran') || lowerTitle.includes('bid') || lowerType === 'bid';
    const isSurvey = lowerTitle.includes('survei') || lowerTitle.includes('booking') || lowerTitle.includes('jadwal');
    const isAuctionWon = lowerTitle.includes('pemenang') || lowerTitle.includes('sold') || lowerTitle.includes('terjual');
    const isUserRegister = lowerTitle.includes('daftar') || lowerTitle.includes('registrasi') || lowerTitle.includes('user baru');
    const isNplDeposit = lowerTitle.includes('deposit') || lowerTitle.includes('npl') || lowerTitle.includes('refund');

    if (isNewAsset && !settings.notifyOnNewAsset) return false;
    if (isNewBid && !settings.notifyOnNewBid) return false;
    if (isSurvey && !settings.notifyOnSurveyBooking) return false;
    if (isAuctionWon && !settings.notifyOnAuctionWon) return false;
    if (isUserRegister && !settings.notifyOnUserRegister) return false;
    if (isNplDeposit && !settings.notifyOnNplDeposit) return false;

    const target = settings.targetNumbers || '';
    if (!target) {
      console.log('[Fonnte] No target phone number or group configured for WA notification.');
      return false;
    }

    const timeString = new Date().toLocaleString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      timeZoneName: 'short'
    });

    let formattedMessage = '';

    // Specialized Kata-Kata untuk UNIT DI-POSTING BARU
    if (isNewAsset) {
      const priceFormatted = extraDetails?.price 
        ? `Rp ${new Intl.NumberFormat('id-ID').format(extraDetails.price)}` 
        : 'Sesuai Katalog';

      formattedMessage = 
`📢 *PEMBERITAHUAN: UNIT LELANG BARU DI-POSTING!* 🚚
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏢 *PT PANCARAN LELANG PLATINUM*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Halo Rekan & Tim! Ada unit lelang baru yang baru saja diposting ke sistem katalog website:

📌 *INFORMASI DETAIL UNIT:*
• *Nama Unit:* ${extraDetails?.assetName || title || 'Armada Pancaran'}
${extraDetails?.brand || extraDetails?.category ? `• *Kategori / Brand:* ${extraDetails.category || 'Vehicle'} - ${extraDetails.brand || '-'}\n` : ''}${extraDetails?.assetId ? `• *No. Lot / ID:* ${extraDetails.assetId}\n` : ''}${extraDetails?.year ? `• *Tahun Pembuatan:* ${extraDetails.year}\n` : ''}${extraDetails?.condition ? `• *Kondisi:* ${extraDetails.condition}\n` : ''}${extraDetails?.poolLocation ? `• *Lokasi Pool / Gudang:* ${extraDetails.poolLocation}\n` : ''}
💰 *HARGA AWAL OPEN BID:*
👉 *${priceFormatted}*

📝 *Keterangan / Pesan Sistem:*
${message}

🌐 *Status:* Siap disurvei & dibuka untuk penawaran
🕒 *Waktu Posting:* ${timeString}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_Notifikasi Otomatis Real-Time Web Pancaran Lelang Platinum_`;
    } 
    // Specialized Kata-Kata untuk PENAWARAN / BIDDING BARU
    else if (isNewBid) {
      const priceFormatted = extraDetails?.price 
        ? `Rp ${new Intl.NumberFormat('id-ID').format(extraDetails.price)}` 
        : 'Sesuai Sistem';

      formattedMessage = 
`🔥 *PENAWARAN HARGA BARU MASUK!* 💰
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏢 *PT PANCARAN LELANG PLATINUM*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Telah masuk penawaran harga lelang baru:

🚗 *Unit:* ${extraDetails?.assetName || extraDetails?.assetId || 'Armada Lelang'}
💵 *Nominal Tawaran:* *${priceFormatted}*
👤 *Penawar:* ${extraDetails?.userName || 'Peserta Terverifikasi'}
${extraDetails?.userPhone ? `📱 *Kontak:* ${extraDetails.userPhone}\n` : ''}🕒 *Waktu:* ${timeString}

📝 *Catatan:*
${message}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_Notifikasi Real-Time Sistem Pancaran Lelang_`;
    }
    // Specialized Kata-Kata untuk BOOKING JADWAL SURVEI FISIK
    else if (isSurvey) {
      formattedMessage = 
`📅 *BOOKING JADWAL SURVEI FISIK UNIT!* 📋
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏢 *PT PANCARAN LELANG PLATINUM*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Peserta telah mengajukan jadwal kunjungan & inspeksi unit:

🚗 *Unit:* ${extraDetails?.assetName || extraDetails?.assetId || 'Armada Lelang'}
👤 *Peserta:* ${extraDetails?.userName || 'Peserta'}
${extraDetails?.userPhone ? `📱 *No. WhatsApp:* ${extraDetails.userPhone}\n` : ''}🗓️ *Tanggal Kunjungan:* ${extraDetails?.surveyDate || 'Sesuai Pengajuan'}
⏰ *Jam Kunjungan:* ${extraDetails?.surveyTime || '09:00'} WIB

📝 *Keterangan:*
${message}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_Notifikasi Real-Time Sistem Pancaran Lelang_`;
    }
    // Specialized Kata-Kata untuk PEMENANG LELANG / CLOSE BID
    else if (isAuctionWon) {
      const priceFormatted = extraDetails?.price 
        ? `Rp ${new Intl.NumberFormat('id-ID').format(extraDetails.price)}` 
        : 'Terkonfirmasi';

      formattedMessage = 
`🏆 *UNIT LELANG TERJUAL / SOLD OUT!* 🎉
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏢 *PT PANCARAN LELANG PLATINUM*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Unit lelang telah resmi ditutup dan mendapatkan pemenang:

🚗 *Unit:* ${extraDetails?.assetName || extraDetails?.assetId || 'Armada Lelang'}
🥇 *Pemenang:* ${extraDetails?.userName || 'Peserta Tertinggi'}
💰 *Harga Final Menang:* *${priceFormatted}*
🕒 *Waktu Penutupan:* ${timeString}

📝 *Detail:*
${message}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_Notifikasi Real-Time Sistem Pancaran Lelang_`;
    }
    // Default Template untuk Notifikasi Lainnya
    else {
      let headerEmoji = '🔔';
      if (isUserRegister) headerEmoji = '👤';
      else if (isNplDeposit) headerEmoji = '💳';

      formattedMessage = 
`${headerEmoji} *NOTIFIKASI SISTEM PANCARAN LELANG*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 *Judul:* ${title}
🕒 *Waktu:* ${timeString}

📝 *Detail Informasi:*
${message}
${extraDetails?.assetId ? `\n🏷️ *ID Unit:* ${extraDetails.assetId}` : ''}${extraDetails?.price ? `\n💵 *Nominal:* Rp ${new Intl.NumberFormat('id-ID').format(extraDetails.price)}` : ''}${extraDetails?.userName ? `\n👤 *Peserta / User:* ${extraDetails.userName}` : ''}${extraDetails?.userPhone ? `\n📱 *Kontak:* ${extraDetails.userPhone}` : ''}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_Notifikasi Real-Time Grup Noted / Pribadi - Pancaran Lelang_`;
    }

    const result = await sendFonnteMessage(target, formattedMessage, settings.apiKey, settings.countryCode);

    if (result.success && eventKey) {
      markEventAsSent(eventKey);
    }

    // Record to dispatch logs
    addFonnteLog({
      id: 'fonnte_' + Date.now(),
      timestamp: new Date().toISOString(),
      type: type || 'system',
      title: title,
      target: target,
      status: result.success ? 'success' : 'failed',
      responseMessage: result.message,
      preview: message.slice(0, 80) + (message.length > 80 ? '...' : '')
    });

    return result.success;
  } catch (error) {
    console.error('[Fonnte Notification Dispatch Error]', error);
    return false;
  }
}
